#!/bin/bash
# Universal Uninstaller for God of War (2018) Completionist Map Mod
# Steam Deck & Linux (SteamOS / Proton)
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "========================================================"
echo "  God of War (2018) - Completionist Map Mod Uninstaller "
echo "  (Steam Deck / Linux Proton)                           "
echo "========================================================"
echo ""

CANDIDATES=(
    "$1"
    "$HOME/.local/share/Steam/steamapps/common/GodOfWar"
    "$HOME/.steam/steam/steamapps/common/GodOfWar"
    "/run/media/mmcblk0p1/steamapps/common/GodOfWar"
)

for d in /run/media/*/*/steamapps/common/GodOfWar /run/media/*/*/GodOfWar; do
    if [ -d "$d" ]; then
        CANDIDATES+=("$d")
    fi
done

GAME_DIR=""
for c in "${CANDIDATES[@]}"; do
    if [ -n "$c" ] && [ -f "$c/GoW.exe" ]; then
        GAME_DIR="$c"
        break
    fi
done

if [ -z "$GAME_DIR" ]; then
    echo "ERROR: God of War installation folder could not be found automatically."
    echo "Usage: ./Uninstall-SteamDeck.sh \"/path/to/GodOfWar\""
    exit 1
fi

BACKUP_DIR="$GAME_DIR/completionist_backup"
if [ ! -d "$BACKUP_DIR" ]; then
    echo "ERROR: No backup found in: $BACKUP_DIR"
    exit 1
fi

echo "[*] Restoring stock files from backup..."
cp -rf "$BACKUP_DIR/"* "$GAME_DIR/"

echo "[*] Removing mod files..."
rm -f "$GAME_DIR/exec/patch/pc_le/completionist_v105_family_art.texpack"
rm -f "$GAME_DIR/exec/patch/pc_le/completionist_v105_family_art.texpack.toc"
rm -rf "$GAME_DIR/mods/completionist-map"

BOOT_FILE="$GAME_DIR/exec/boot-options.json"
if [ -f "$BOOT_FILE" ]; then
    python3 -c "
import json
p = '$BOOT_FILE'
try:
    with open(p, 'r', encoding='utf-8') as f:
        data = json.load(f)
    entry = '../../patch/pc_le/completionist_v105_family_art'
    packs = data.get('patch-texpacks', [])
    if entry in packs:
        packs.remove(entry)
        data['patch-texpacks'] = packs
        with open(p, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4)
        print('[+] Cleaned texpack entry from boot-options.json')
except Exception as e:
    pass
"
fi

rm -rf "$BACKUP_DIR"

echo ""
echo "========================================================"
echo "        UNINSTALLATION COMPLETED SUCCESSFULLY!          "
echo "========================================================"
