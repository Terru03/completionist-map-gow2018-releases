<#
.SYNOPSIS
    Universal 1-Click Installer for God of War (2018) Completionist Map Mod.
.DESCRIPTION
    Auto-detects God of War install folder across Steam, Epic Games, custom drives,
    or user prompt. Safely backs up stock game files before copying mod files.
#>
param(
    [string]$TargetDir = ""
)

$ErrorActionPreference = "Stop"

# Keep existing ReShade through D3D11. No preset or shader writes.
function Get-CompletionistCompatHash([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Test-CompletionistReShade([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    return (Get-Item -LiteralPath $Path).VersionInfo.ProductName -eq 'ReShade'
}

function Test-CompletionistDxgiOwnership([string]$Hash) {
    return $Hash -in @($completionistKnownPayloads.PSObject.Properties['dxgi.dll'].Value)
}

function Assert-CompletionistCompatPath([string]$Game, [string]$Path) {
    $root = [IO.Path]::GetFullPath($Game).TrimEnd('\')
    $full = [IO.Path]::GetFullPath($Path)
    if (-not $full.StartsWith($root + '\', [StringComparison]::OrdinalIgnoreCase)) {
        throw 'ReShade compatibility path outside game folder.'
    }
    $current = $full
    while ($current.Length -gt $root.Length) {
        $item = Get-Item -LiteralPath $current -Force -ErrorAction SilentlyContinue
        if ($item -and ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
            throw 'ReShade compatibility path uses a link; no files changed.'
        }
        $current = [IO.Path]::GetDirectoryName($current)
    }
}

function Assert-CompletionistReShade64([string]$Path) {
    $stream = [IO.File]::OpenRead($Path)
    $reader = New-Object IO.BinaryReader($stream)
    try {
        if ($stream.Length -lt 64 -or $reader.ReadUInt16() -ne 0x5A4D) { throw 'Invalid ReShade PE header.' }
        $stream.Position = 0x3C
        $offset = $reader.ReadInt32()
        if ($offset -lt 64 -or $offset -gt $stream.Length - 6) { throw 'Invalid ReShade PE offset.' }
        $stream.Position = $offset
        if ($reader.ReadUInt32() -ne 0x4550 -or $reader.ReadUInt16() -ne 0x8664) {
            throw 'God of War needs 64-bit ReShade. No game files changed.'
        }
    } finally { $reader.Dispose() }
}

function Read-CompletionistReShadeRecord([string]$Game) {
    $path = Join-Path $Game 'completionist_backup\reshade-compat.json'
    Assert-CompletionistCompatPath $Game $path
    if (-not (Test-Path -LiteralPath $path)) { return $null }
    $record = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
    if ($record.schema -ne 1 -or $record.sha256 -notmatch '\A[0-9a-f]{64}\z' -or
        $record.dxgi_sha256 -notmatch '\A[0-9a-f]{64}\z' -or
        -not (Test-CompletionistDxgiOwnership $record.dxgi_sha256)) {
        throw 'Invalid ReShade compatibility record; no files changed.'
    }
    if ($record.previous_alias_sha256 -and $record.previous_alias_sha256 -notmatch '\A[0-9a-f]{64}\z') {
        throw 'Invalid pending ReShade alias hash; no files changed.'
    }
    return $record
}

function Get-CompletionistReShadePlan([string]$Game, $PackageManifest) {
    $payload = $PackageManifest.files.PSObject.Properties['dxgi.dll']
    if (-not $payload) { return $null }
    $expected = $payload.Value.sha256
    if ($expected -notmatch '\A[0-9a-f]{64}\z') { throw 'Invalid Completionist DXGI hash.' }
    $rootDll = Join-Path $Game 'dxgi.dll'
    $alias = Join-Path $Game 'd3d11.dll'
    Assert-CompletionistCompatPath $Game $rootDll
    Assert-CompletionistCompatPath $Game $alias
    $record = Read-CompletionistReShadeRecord $Game
    $source = $null
    if (Test-CompletionistReShade $rootDll) {
        $source = $rootDll
    } else {
        $rootHash = if (Test-Path -LiteralPath $rootDll -PathType Leaf) { Get-CompletionistCompatHash $rootDll } else { $null }
        if ($rootHash -and $rootHash -ne $expected -and -not (Test-CompletionistDxgiOwnership $rootHash)) {
            throw 'Another mod owns dxgi.dll. No game files changed.'
        }
        if ($record -and (Test-CompletionistReShade $alias) -and
            (Get-CompletionistCompatHash $alias) -ne $record.sha256 -and
            (Get-CompletionistCompatHash $alias) -ne $record.previous_alias_sha256) {
            $source = $alias
        } elseif ($record) {
            $saved = Join-Path $Game ('completionist_backup\reshade-compat\' + $record.sha256 + '.dll')
            Assert-CompletionistCompatPath $Game $saved
            if (-not (Test-Path -LiteralPath $saved -PathType Leaf) -or
                (Get-CompletionistCompatHash $saved) -ne $record.sha256 -or
                -not (Test-CompletionistReShade $saved)) { throw 'ReShade recovery copy changed; no files changed.' }
            $source = $saved
        } elseif ($rootHash -eq $expected) {
            $saved = Join-Path $Game 'completionist_backup\dxgi.dll'
            Assert-CompletionistCompatPath $Game $saved
            if (Test-CompletionistReShade $saved) {
                $backupPath = Join-Path $Game 'completionist_backup\backup_manifest.json'
                Assert-CompletionistCompatPath $Game $backupPath
                $backup = Get-Content -LiteralPath $backupPath -Raw | ConvertFrom-Json
                $proof = $backup.files.PSObject.Properties['dxgi.dll']
                if (-not $proof -or $proof.Value -ne (Get-CompletionistCompatHash $saved)) {
                    throw 'ReShade backup hash mismatch; no files changed.'
                }
                $source = $saved
            }
        }
    }
    if (-not $source) { return $null }
    if (-not (Test-CompletionistDxgiOwnership $expected)) { throw 'Unsupported Completionist DXGI build for ReShade repair.' }
    Assert-CompletionistReShade64 $source
    $digest = Get-CompletionistCompatHash $source
    $replaceAliasHash = $null
    if ((Test-Path -LiteralPath $alias) -and (Get-CompletionistCompatHash $alias) -ne $digest) {
        $aliasHash = Get-CompletionistCompatHash $alias
        if ($record -and $aliasHash -in @($record.sha256, $record.previous_alias_sha256) -and (Test-CompletionistReShade $alias)) {
            $replaceAliasHash = $aliasHash
        } else { throw 'd3d11.dll already used by another DLL. No game files changed.' }
    }
    return [PSCustomObject]@{ Source=$source; Hash=$digest; DxgiHash=$expected; ReplaceAliasHash=$replaceAliasHash }
}

function Save-CompletionistReShade([string]$Game, $Plan) {
    if (-not $Plan) { return }
    $folder = Join-Path $Game 'completionist_backup\reshade-compat'
    $saved = Join-Path $folder ($Plan.Hash + '.dll')
    Assert-CompletionistCompatPath $Game $saved
    [IO.Directory]::CreateDirectory($folder) | Out-Null
    if (-not (Test-Path -LiteralPath $saved)) { [IO.File]::Copy($Plan.Source, $saved, $false) }
    if ((Get-CompletionistCompatHash $saved) -ne $Plan.Hash) { throw 'ReShade recovery copy mismatch.' }
    $recordPath = Join-Path $Game 'completionist_backup\reshade-compat.json'
    Assert-CompletionistCompatPath $Game $recordPath
    $record = @{ schema=1; sha256=$Plan.Hash; dxgi_sha256=$Plan.DxgiHash }
    if ($Plan.ReplaceAliasHash) { $record.previous_alias_sha256 = $Plan.ReplaceAliasHash }
    $record = $record | ConvertTo-Json
    Write-CompletionistText $recordPath $record
}

function Enable-CompletionistReShade([string]$Game, $Plan) {
    if (-not $Plan) { return }
    $saved = Join-Path $Game ('completionist_backup\reshade-compat\' + $Plan.Hash + '.dll')
    $alias = Join-Path $Game 'd3d11.dll'
    Assert-CompletionistCompatPath $Game $saved
    Assert-CompletionistCompatPath $Game $alias
    if ((Get-CompletionistCompatHash $saved) -ne $Plan.Hash) { throw 'ReShade recovery copy changed.' }
    if (-not (Test-CompletionistReShade $saved)) { throw 'Recovery copy is not ReShade.' }
    Assert-CompletionistReShade64 $saved
    if ($Plan.ReplaceAliasHash -and (Test-Path -LiteralPath $alias) -and
        (Get-CompletionistCompatHash $alias) -eq $Plan.ReplaceAliasHash) {
        Copy-CompletionistDxgi $saved $alias
    }
    if (-not (Test-Path -LiteralPath $alias)) { [IO.File]::Copy($saved, $alias, $false) }
    if ((Get-CompletionistCompatHash $alias) -ne $Plan.Hash) { throw 'd3d11.dll changed during install.' }
    if ($Plan.DxgiHash) {
        $recordPath = Join-Path $Game 'completionist_backup/reshade-compat.json'
        $record = @{ schema=1; sha256=$Plan.Hash; dxgi_sha256=$Plan.DxgiHash } | ConvertTo-Json
        Write-CompletionistText $recordPath $record
    }
    Write-Host '[+] ReShade preserved through d3d11.dll; preset and shaders kept.' -ForegroundColor Green
}

function Assert-CompletionistReShadeRemoval([string]$Game) {
    $record = Read-CompletionistReShadeRecord $Game
    if (-not $record) { return }
    $rootDll = Join-Path $Game 'dxgi.dll'
    $alias = Join-Path $Game 'd3d11.dll'
    Assert-CompletionistCompatPath $Game $rootDll
    Assert-CompletionistCompatPath $Game $alias
    $pendingAlias = $record.previous_alias_sha256 -and (Test-CompletionistReShade $alias) -and
        (Get-CompletionistCompatHash $alias) -eq $record.previous_alias_sha256
    if ((Test-CompletionistReShade $rootDll) -or
        ((Test-Path -LiteralPath $alias) -and -not $pendingAlias)) { return }
    $saved = Join-Path $Game ('completionist_backup/reshade-compat/' + $record.sha256 + '.dll')
    Assert-CompletionistCompatPath $Game $saved
    if (-not (Test-Path -LiteralPath $saved -PathType Leaf) -or
        (Get-CompletionistCompatHash $saved) -ne $record.sha256 -or -not (Test-CompletionistReShade $saved)) {
        throw 'ReShade recovery copy changed; no files changed.'
    }
    Assert-CompletionistReShade64 $saved
}

function Copy-CompletionistDxgi([string]$Source, [string]$Destination) {
    $temporary = $Destination + '.completionist-' + [Guid]::NewGuid().ToString('N') + '.tmp'
    try {
        [IO.File]::Copy($Source, $temporary, $false)
        if ((Get-CompletionistCompatHash $temporary) -ne (Get-CompletionistCompatHash $Source)) { throw 'DXGI copy mismatch.' }
        if (Test-Path -LiteralPath $Destination) { [IO.File]::Replace($temporary, $Destination, [NullString]::Value) }
        else { [IO.File]::Move($temporary, $Destination) }
    } finally {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force }
    }
}

function Test-CompletionistKeepReShade([string]$Game, [string]$BackupDll) {
    if (Test-CompletionistReShade (Join-Path $Game 'dxgi.dll')) { return $true }
    return (Test-CompletionistReShade $BackupDll) -and
        (Test-CompletionistReShade (Join-Path $Game 'd3d11.dll'))
}

function Remove-CompletionistDxgiAfterReShade([string]$Game) {
    $record = Read-CompletionistReShadeRecord $Game
    if (-not $record) { return $false }
    $rootDll = Join-Path $Game 'dxgi.dll'
    Assert-CompletionistCompatPath $Game $rootDll
    if ((Test-Path -LiteralPath $rootDll -PathType Leaf) -and
        (Get-CompletionistCompatHash $rootDll) -eq $record.dxgi_sha256) {
        Remove-Item -LiteralPath $rootDll -Force
    }
    $alias = Join-Path $Game 'd3d11.dll'
    Assert-CompletionistCompatPath $Game $alias
    if ($record.previous_alias_sha256 -and -not (Test-CompletionistReShade $rootDll) -and
        (Test-CompletionistReShade $alias) -and
        (Get-CompletionistCompatHash $alias) -eq $record.previous_alias_sha256) {
        Enable-CompletionistReShade $Game ([PSCustomObject]@{ Hash=$record.sha256; ReplaceAliasHash=$record.previous_alias_sha256 })
    }
    if (-not (Test-CompletionistReShade $rootDll) -and -not (Test-CompletionistReShade $alias)) {
        if (Test-Path -LiteralPath $alias) {
            Write-Host '[!] Changed d3d11.dll preserved; ReShade recovery backup kept.' -ForegroundColor Yellow
            return $true
        }
        Enable-CompletionistReShade $Game ([PSCustomObject]@{ Hash=$record.sha256 })
    }
    if ($record.previous_alias_sha256) {
        $activeCurrent = ((Test-CompletionistReShade $rootDll) -and (Get-CompletionistCompatHash $rootDll) -eq $record.sha256) -or
            ((Test-CompletionistReShade $alias) -and (Get-CompletionistCompatHash $alias) -eq $record.sha256)
        if (-not $activeCurrent) {
            Write-Host '[!] Pending ReShade update backup kept.' -ForegroundColor Yellow
            return $true
        }
    }
    Write-Host '[+] Existing ReShade and presets kept.' -ForegroundColor Green
    return $false
}

function Remove-CompletionistUnbackedPayloads([string]$Game, [string]$PackageRoot, $OriginalFiles) {
    $packagePath = Join-Path $PackageRoot 'manifest.json'
    if (-not (Test-Path -LiteralPath $packagePath -PathType Leaf)) { return }
    $package = Get-Content -LiteralPath $packagePath -Raw | ConvertFrom-Json
    $allowed = @(
        'dxgi.dll',
        'mods/loader_config.toml',
        'exec/dc/pc_le/mapcoords.dcb',
        'exec/dc/pc_le/mapmaster.dcb',
        'exec/dc/pc_le/wad_r_perm.dcb',
        'exec/dc/pc_le/wad_r_ui.dcb',
        'exec/patch/pc_le/completionist_v105_family_art.texpack',
        'exec/patch/pc_le/completionist_v105_family_art.texpack.toc',
        'exec/wad/pc_le/r_ui.wad',
        'mods/completionist-map/native/collectible-base-dxgi.dll',
        'mods/completionist-map/native/raven-native-bridge-manifest.json',
        'mods/lua/gameart/scripts/levels/gameplaymodules/interactive/triptychs/interact_triptych.lua',
        'mods/lua/gameart/scripts/levels/gameplaymodules/progression/interact_chest_runic.lua',
        'mods/lua/gameart/scripts/levels/gameplaymodules/progression/interact_chest_standard.lua',
        'mods/lua/gameart/scripts/levels/gameplaymodules/progression/interact_loot_artifact.lua',
        'mods/lua/gameart/scripts/levels/gameplaymodules/progression/interact_loot_dirtdig.lua',
        'mods/lua/gameart/scripts/levels/gameplaymodules/progression/interact_loot_pocketrift.lua',
        'mods/lua/gameart/scripts/levels/gameplaymodules/progression/precisionchallenge.lua',
        'mods/lua/gameart/scripts/levels/gameplaymodules/soninteracts/langcheckruneread.lua',
        'mods/lua/gameart/scripts/levels/gameplaymodules/soninteracts/sonlanguagepickup.lua',
        'mods/lua/gameart/ui/scripts/inworldmenu/mapmenu.lua'
    )
    foreach ($relative in $allowed) {
        if ($OriginalFiles.PSObject.Properties[$relative]) { continue }
        if ($relative -eq 'mods/loader_config.toml' -and (Test-Path -LiteralPath (Join-Path $Game 'version.dll'))) {
            continue
        }
        $entry = $package.files.PSObject.Properties[$relative]
        if (-not $entry -or $entry.Value.sha256 -notmatch '\A[0-9a-f]{64}\z') { continue }
        $target = Join-Path $Game $relative
        Assert-CompletionistCompatPath $Game $target
        if ((Test-Path -LiteralPath $target -PathType Leaf) -and
            (Get-CompletionistCompatHash $target) -eq $entry.Value.sha256) {
            Remove-Item -LiteralPath $target -Force
        }
    }
}

# Shared config stays. Unknown mod scripts stop install.
$completionistKnownPayloads = @'
{"dxgi.dll":["923afa1bc59751722f32351ffc17d337ef86beec4a89066dee6909d4e226357e","fe427a11d190dbd7c39377566da6d54487f209f2b5c1126d1656ff2a11321e1a"],"exec/dc/pc_le/mapcoords.dcb":["7644b280ee4bedc1af7a4d81d5e1aacfaaac91ec8795c8f2f4434b4fa0534772"],"exec/dc/pc_le/mapmaster.dcb":["88cd527582efe5d708d465e6593921e92164831b9b2d34bd36c5b47aa0ec920d"],"exec/dc/pc_le/wad_r_perm.dcb":["217048e876014869608f873ddb02550d9e29b3d3dc66427ad6a41c0649ec6841"],"exec/dc/pc_le/wad_r_ui.dcb":["9a22b36bb09167f967ab708471fab253b1292ed733dc1347a41f02e802c102c6"],"exec/patch/pc_le/completionist_v105_family_art.texpack":["eafeb31882ceff41dc50b1d6cd3057fb57f5e6a83585a9992b6044f606603485"],"exec/patch/pc_le/completionist_v105_family_art.texpack.toc":["31a97b87a27623a5b1b023113afc288b5e435a8ecca2a372d1da69e18f8f28f4"],"exec/wad/pc_le/r_ui.wad":["44866aaa861a62dd4d4aacad5dd39881728e055925d6113e26f2dfaa03143204"],"mods/completionist-map/native/collectible-base-dxgi.dll":["9043eac673ae15cd4f4b5c2f5bc96c64d17aa1fd613d588ce2547532fcb8f02c","2ce810e0f969d44bedb944db375a715c7eadd26e96830af924e5a8a50aaa668a"],"mods/completionist-map/native/raven-native-bridge-manifest.json":["9e011761beccf5f1d618e8ba80c6ede1c0a26384d40fe875b7218cefbff34139","4ea73ef34b461867c82b02cc5e66e39d6cf946467631f1c1fb7b63c3c4da2ca4"],"mods/lua/gameart/scripts/levels/gameplaymodules/interactive/triptychs/interact_triptych.lua":["9cc7a16407005a2fc16359c80fed4cd1f39eb8b8d3d96811e4a82df8a56ba627"],"mods/lua/gameart/scripts/levels/gameplaymodules/progression/interact_chest_runic.lua":["e9c77fbaa9ba8d678d0ade38f1016b83dd20ebda9d252189973490a1c73ff454"],"mods/lua/gameart/scripts/levels/gameplaymodules/progression/interact_chest_standard.lua":["0cc8b8ae7b8685b01e0449e7ba110cefeda19d00f9c2dba2987803752f38f3c7"],"mods/lua/gameart/scripts/levels/gameplaymodules/progression/interact_loot_artifact.lua":["30e69322ecdcf3ccd0a884e0d281ff3db28adb869c23e2ad3806da8f023d8bf3"],"mods/lua/gameart/scripts/levels/gameplaymodules/progression/interact_loot_dirtdig.lua":["56936cc8e6f0765980499e0b3752ca5976d73121813905c0625b5968a82fd9b0"],"mods/lua/gameart/scripts/levels/gameplaymodules/progression/interact_loot_pocketrift.lua":["c8593984f001a9817a10a522dbbcd2c2e145e767a130d319744d8a9293be3c91"],"mods/lua/gameart/scripts/levels/gameplaymodules/progression/precisionchallenge.lua":["b7039c3c558e82dd9cbd4053b2bf9baddfd34b9ad65f34d631556ad9a7378054","0fbc45ed07f9116fbb98906bf1c2468ed0b1c45d2652238c1f1a2b9a8f59ff82"],"mods/lua/gameart/scripts/levels/gameplaymodules/soninteracts/langcheckruneread.lua":["28a9dcb9877b4d0f76fa67aa99cb894e9209f8ba0341dd5713913af0521f273d","a1f05574ab6707d9973dd7fa0d623624bca2ad807400cfb38ed8731884419b54"],"mods/lua/gameart/scripts/levels/gameplaymodules/soninteracts/sonlanguagepickup.lua":["d9afbfb4d7f0445a6ae5665c317cce9b68fe21704e1c7062d0651e7c7b657872"],"mods/lua/gameart/ui/scripts/inworldmenu/mapmenu.lua":["89312da4a21d22bd651fe30ead5d45abddee6b318781fa9bd965315ada349787","a4ede488b7759a2635fe98b83d87c0bd6dd3c995a4cdbbde91c801c1aafadcf3"],"mods/loader_config.toml":["63bf253df21ebe24d6fe52e2baadaa2105c73bb7cf42ca466e5b410090018584"]}
'@ | ConvertFrom-Json

function Test-CompletionistKnownPayload([string]$Relative, [string]$Hash, $Package) {
    $entry = $Package.files.PSObject.Properties[$Relative]
    if ($entry -and $Hash -eq $entry.Value.sha256) { return $true }
    $known = $completionistKnownPayloads.PSObject.Properties[$Relative]
    return $known -and $Hash -in @($known.Value)
}

function Assert-CompletionistInstallPaths([string]$Game, $Package, [bool]$CheckConflicts = $true) {
    foreach ($relative in @($Package.files.PSObject.Properties.Name) + @('exec/boot-options.json', 'version.dll')) {
        if (-not $relative) { continue }
        $target = Join-Path $Game $relative
        Assert-CompletionistCompatPath $Game $target
        Assert-CompletionistCompatPath $Game (Join-Path $Game ('completionist_backup/' + $relative))
        if ($relative -eq 'mods/loader_config.toml') { continue }
        if ($CheckConflicts -and ($relative.StartsWith('mods/') -or $relative.StartsWith('exec/patch/')) -and
            (Test-Path -LiteralPath $target -PathType Leaf) -and
            -not (Test-CompletionistKnownPayload $relative (Get-CompletionistCompatHash $target) $Package)) {
            throw "File conflict: $relative belongs to another mod or was edited. No game files changed."
        }
    }
    Assert-CompletionistCompatPath $Game (Join-Path $Game 'completionist_backup/backup_manifest.json')
}

function Get-CompletionistLoaderConfig([string]$Game, $Package) {
    if (-not $Package.files.PSObject.Properties['mods/loader_config.toml']) { return $null }
    $path = Join-Path $Game 'mods/loader_config.toml'
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $null }
    $text = [IO.File]::ReadAllText($path, (New-Object Text.UTF8Encoding($false, $true)))
    # Complex TOML needs manual merge; never guess inside multiline values.
    if ($text.Contains('"""') -or $text.Contains("'''")) { throw 'Multiline loader config cannot be merged safely. No game files changed.' }
    if ($text -match '(?m)^[ \t]*(?:Lua|["\x27]Lua["\x27])[ \t]*(?:=|\.)' -or
        $text -match '(?m)^[ \t]*(?:\[[^\r\n]*\\|["\x27][^\r\n]*\\[^\r\n]*[=.])') {
        throw 'Complex Lua config cannot be merged safely. No game files changed.'
    }
    $newline = if ($text.Contains("`r`n")) { "`r`n" } else { "`n" }
    $tables = [regex]::Matches($text, '(?m)^[ \t]*\[([^\r\n]+)\][ \t]*(?:#[^\r\n]*)?\r?$')
    $lua = @($tables | Where-Object { $_.Groups[1].Value.Trim() -cmatch '\A(?:Lua|"Lua"|\x27Lua\x27)\z' })
    if ($lua.Count -gt 1) {
        throw 'Ambiguous Lua config table. No game files changed.'
    }
    if ($lua.Count -eq 0) { return $text.TrimEnd("`r", "`n") + $newline + $newline + '[Lua]' + $newline + 'LoadScripts = true' + $newline }
    $start = $lua[0].Index + $lua[0].Length
    $end = $text.Length
    foreach ($table in $tables) { if ($table.Index -gt $lua[0].Index) { $end = $table.Index; break } }
    $body = $text.Substring($start, $end - $start)
    $keys = [regex]::Matches($body, '(?m)^[ \t]*(?:LoadScripts|["\x27]LoadScripts["\x27])[ \t]*=')
    $setting = [regex]::Matches($body, '(?m)^([ \t]*(?:LoadScripts|["\x27]LoadScripts["\x27])[ \t]*=[ \t]*)(true|false)([ \t]*(?:#[^\r\n]*)?\r?)$')
    if ($keys.Count -gt 1 -or $keys.Count -ne $setting.Count) { throw 'Invalid LoadScripts setting. No game files changed.' }
    if ($setting.Count -eq 0) {
        if (-not $body.EndsWith("`n")) { $body += $newline }
        $body += 'LoadScripts = true' + $newline
    } elseif ($setting[0].Groups[2].Value -eq 'true') { return $null }
    else {
        $value = $setting[0].Groups[2]
        $body = $body.Remove($value.Index, $value.Length).Insert($value.Index, 'true')
    }
    return $text.Substring(0, $start) + $body + $text.Substring($end)
}

function Write-CompletionistText([string]$Path, [string]$Text) {
    $temporary = $Path + '.completionist-' + [Guid]::NewGuid().ToString('N') + '.tmp'
    try {
        [IO.File]::WriteAllText($temporary, $Text, (New-Object Text.UTF8Encoding($false)))
        if (Test-Path -LiteralPath $Path) { [IO.File]::Replace($temporary, $Path, [NullString]::Value) }
        else { [IO.File]::Move($temporary, $Path) }
    } finally {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force }
    }
}

function Assert-CompletionistRestore([string]$Game, $OriginalFiles) {
    if ($OriginalFiles -isnot [PSCustomObject] -or @($OriginalFiles.PSObject.Properties).Count -eq 0) {
        throw 'Invalid or empty backup file list; no game files changed.'
    }
    foreach ($relative in @($completionistKnownPayloads.PSObject.Properties.Name) + @('exec/boot-options.json')) {
        $source = Join-Path $Game ('completionist_backup/' + $relative)
        Assert-CompletionistCompatPath $Game $source
        if ((Test-Path -LiteralPath $source -PathType Leaf) -and -not $OriginalFiles.PSObject.Properties[$relative]) {
            throw "Backup record missing: $relative. No game files changed."
        }
    }
    foreach ($property in $OriginalFiles.PSObject.Properties) {
        $relative = $property.Name
        if ($relative -ne 'exec/boot-options.json' -and -not $completionistKnownPayloads.PSObject.Properties[$relative]) {
            throw 'Unknown backup path; no game files changed.'
        }
        $source = Join-Path $Game ('completionist_backup/' + $relative)
        Assert-CompletionistCompatPath $Game $source
        Assert-CompletionistCompatPath $Game (Join-Path $Game $relative)
        if ($property.Value -notmatch '\A[0-9a-f]{64}\z' -or
            -not (Test-Path -LiteralPath $source -PathType Leaf) -or
            (Get-CompletionistCompatHash $source) -ne $property.Value) {
            throw "Backup hash mismatch: $relative. No game files changed."
        }
    }
}

function Assert-CompletionistExistingBackup([string]$Game, $Package) {
    $path = Join-Path $Game 'completionist_backup/backup_manifest.json'
    Assert-CompletionistCompatPath $Game $path
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return }
    $original = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
    Assert-CompletionistRestore $Game $original.files
    foreach ($relative in $Package.files.PSObject.Properties.Name) {
        if (-not $relative.StartsWith('exec/')) { continue }
        $entry = $original.files.PSObject.Properties[$relative]
        $target = Join-Path $Game $relative
        if (-not $entry -or -not (Test-Path -LiteralPath $target -PathType Leaf)) { continue }
        $hash = Get-CompletionistCompatHash $target
        if ($hash -ne $entry.Value -and -not (Test-CompletionistKnownPayload $relative $hash $Package)) {
            throw "File conflict: $relative changed since install. No game files changed."
        }
    }
}

function Remove-CompletionistVerifiedBackup([string]$Game, $OriginalFiles) {
    $paths = @($OriginalFiles.PSObject.Properties.Name | ForEach-Object { Join-Path $Game ('completionist_backup/' + $_) })
    $record = Read-CompletionistReShadeRecord $Game
    if ($record) {
        $saved = Join-Path $Game ('completionist_backup/reshade-compat/' + $record.sha256 + '.dll')
        Assert-CompletionistCompatPath $Game $saved
        if ((Test-Path -LiteralPath $saved -PathType Leaf) -and (Get-CompletionistCompatHash $saved) -eq $record.sha256) {
            $paths += $saved
        }
        $paths += Join-Path $Game 'completionist_backup/reshade-compat.json'
    }
    $paths += Join-Path $Game 'completionist_backup/backup_manifest.json'
    $directories = @{}
    $root = Join-Path $Game 'completionist_backup'
    foreach ($path in $paths) {
        Assert-CompletionistCompatPath $Game $path
        if (Test-Path -LiteralPath $path -PathType Leaf) { Remove-Item -LiteralPath $path -Force }
        $parent = [IO.Path]::GetDirectoryName($path)
        while ($parent.Length -ge $root.Length) {
            $directories[$parent] = $true
            $parent = [IO.Path]::GetDirectoryName($parent)
        }
    }
    foreach ($directory in @($directories.Keys | Sort-Object Length -Descending)) {
        try { [IO.Directory]::Delete($directory, $false) } catch { }
    }
    if (Test-Path -LiteralPath $root) { Write-Host '[!] Extra recovery files kept in completionist_backup.' -ForegroundColor Yellow }
}

function Restore-CompletionistPayloads([string]$Game, $OriginalFiles, $Package) {
    $keep = $false
    foreach ($property in $OriginalFiles.PSObject.Properties) {
        $relative = $property.Name
        if ($relative -in @('exec/boot-options.json', 'mods/loader_config.toml')) { continue }
        $source = Join-Path $Game ('completionist_backup/' + $relative)
        $target = Join-Path $Game $relative
        if ($relative -eq 'dxgi.dll' -and (Test-CompletionistKeepReShade $Game $source)) { continue }
        if ((Test-Path -LiteralPath $target -PathType Leaf) -and
            -not (Test-CompletionistKnownPayload $relative (Get-CompletionistCompatHash $target) $Package)) {
            if ((Get-CompletionistCompatHash $target) -eq $property.Value) { continue }
            Write-Host "[!] Changed file kept: $relative. Original backup kept." -ForegroundColor Yellow
            $keep = $true
            continue
        }
        [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target)) | Out-Null
        Copy-CompletionistDxgi $source $target
    }
    return $keep
}

function Get-CompletionistCleanBoot([string]$Game) {
    $path = Join-Path $Game 'exec/boot-options.json'
    Assert-CompletionistCompatPath $Game $path
    $boot = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
    if ($boot -isnot [PSCustomObject]) { throw 'Invalid boot-options.json; no game files changed.' }
    $entry = '../../patch/pc_le/completionist_v105_family_art'
    $packs = @($boot.'patch-texpacks')
    if ($entry -notin $packs) { return $null }
    $boot.'patch-texpacks' = @($packs | Where-Object { $_ -ne $entry })
    return $boot | ConvertTo-Json -Depth 32
}


function Find-GodOfWar {
    # 1. TargetDir parameter
    if ($TargetDir -and (Test-Path (Join-Path $TargetDir "GoW.exe"))) {
        return (Resolve-Path $TargetDir).Path
    }
    # 2. Parent directory of script / current directory (if extracted directly into game folder)
    $scriptDir = Split-Path -Parent $PSScriptRoot
    if (Test-Path (Join-Path $scriptDir "GoW.exe")) {
        return $scriptDir
    }
    $currDir = (Get-Location).Path
    if (Test-Path (Join-Path $currDir "GoW.exe")) {
        return $currDir
    }
    # 3. Steam Registry (32-bit & 64-bit)
    $regPaths = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 1593500",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 1593500"
    )
    foreach ($reg in $regPaths) {
        if (Test-Path $reg) {
            $loc = (Get-ItemProperty $reg -ErrorAction SilentlyContinue).InstallLocation
            if ($loc -and (Test-Path (Join-Path $loc "GoW.exe"))) {
                return $loc
            }
        }
    }
    # 4. Steam libraryfolders.vdf parser
    $steamReg = Get-ItemProperty "HKCU:\SOFTWARE\Valve\Steam" -ErrorAction SilentlyContinue
    if ($steamReg -and $steamReg.SteamPath) {
        $vdf = Join-Path $steamReg.SteamPath "steamapps\libraryfolders.vdf"
        if (Test-Path $vdf) {
            $content = Get-Content $vdf -Raw -ErrorAction SilentlyContinue
            $matches = [regex]::Matches($content, '"path"\s+"([^"]+)"')
            foreach ($m in $matches) {
                $libPath = $m.Groups[1].Value.Replace('\\', '\')
                $testPath = Join-Path $libPath "steamapps\common\GodOfWar"
                if (Test-Path (Join-Path $testPath "GoW.exe")) {
                    return $testPath
                }
            }
        }
    }
    # 5. Epic Games Manifests
    $epicDir = "C:\ProgramData\Epic\EpicGamesLauncher\Data\Manifests"
    if (Test-Path $epicDir) {
        Get-ChildItem $epicDir -Filter "*.item" -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                $json = Get-Content $_.FullName -Raw | ConvertFrom-Json
                if ($json.DisplayName -match "God of War" -and (Test-Path (Join-Path $json.InstallLocation "GoW.exe"))) {
                    return $json.InstallLocation
                }
            } catch {}
        }
    }
    # 6. GOG Registry
    $gogRegs = @(
        "HKLM:\SOFTWARE\GOG.com\Games\1593500",
        "HKLM:\SOFTWARE\WOW6432Node\GOG.com\Games\1593500",
        "HKLM:\SOFTWARE\GOG.com\Games\God of War",
        "HKLM:\SOFTWARE\WOW6432Node\GOG.com\Games\God of War"
    )
    foreach ($reg in $gogRegs) {
        if (Test-Path $reg) {
            $loc = (Get-ItemProperty $reg -ErrorAction SilentlyContinue).PATH
            if ($loc -and (Test-Path (Join-Path $loc "GoW.exe"))) {
                return $loc
            }
        }
    }
    # 7. Common Library Paths across drives C: through H:
    $drives = Get-PSDrive -PSProvider FileSystem | Select-Object -ExpandProperty Root
    $subpaths = @(
        "Program Files (x86)\Steam\steamapps\common\GodOfWar",
        "Program Files\Steam\steamapps\common\GodOfWar",
        "SteamLibrary\steamapps\common\GodOfWar",
        "Steam\steamapps\common\GodOfWar",
        "Games\GodOfWar",
        "Epic Games\GodOfWar",
        "GOG Games\God of War",
        "GOG Galaxy\Games\God of War",
        "Games\God of War",
        "SteamLibrary\steamapps\common\God of War",
        "Program Files (x86)\GOG Galaxy\Games\God of War"
    )
    foreach ($d in $drives) {
        foreach ($sub in $subpaths) {
            $candidate = Join-Path $d $sub
            if (Test-Path (Join-Path $candidate "GoW.exe")) {
                return $candidate
            }
        }
    }
    # 8. Interactive Folder Browser fallback
    Write-Host "God of War installation directory not detected automatically." -ForegroundColor Yellow
    Write-Host "Please select your God of War game directory in the window (where GoW.exe is located)..." -ForegroundColor Cyan
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = "Select your God of War game folder (contains GoW.exe)"
    $dialog.ShowNewFolderButton = $false
    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        if (Test-Path (Join-Path $dialog.SelectedPath "GoW.exe")) {
            return $dialog.SelectedPath
        } else {
            Write-Host "ERROR: The selected folder does not contain GoW.exe!" -ForegroundColor Red
        }
    }
    return $null
}

Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "   God of War (2018) - Completionist Map Mod Installer  " -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host ""

# Check if GoW is running
$gowProc = Get-Process "GoW" -ErrorAction SilentlyContinue
if ($gowProc) {
    Write-Host "WARNING: God of War is currently running!" -ForegroundColor Red
    Write-Host "Please close the game before proceeding with installation." -ForegroundColor Yellow
    Write-Host "Press any key to retry after closing the game..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    $gowProc = Get-Process "GoW" -ErrorAction SilentlyContinue
    if ($gowProc) {
        Write-Host "God of War is still running. Aborting installation." -ForegroundColor Red
        exit 1
    }
}

$game = Find-GodOfWar
if (-not $game) {
    Write-Host "ERROR: God of War installation folder could not be found." -ForegroundColor Red
    Write-Host "Please place the installer folder directly inside your God of War game folder and run Install.bat again." -ForegroundColor Yellow
    exit 1
}

Write-Host "[+] Detected God of War at: $game" -ForegroundColor Green

# Verify write permission to God of War folder early (auto-elevate if needed)
$writeTestOk = $false
try {
    $testPerm = Join-Path $game ".__completionist_perm_test.tmp"
    [IO.File]::WriteAllText($testPerm, "perm_check")
    Remove-Item -LiteralPath $testPerm -Force -ErrorAction SilentlyContinue
    $writeTestOk = $true
} catch {
    $writeTestOk = $false
}

if (-not $writeTestOk) {
    $isAdmin = $false
    try {
        $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch {}

    if (-not $isAdmin) {
        Write-Host ""
        Write-Host "[!] Write access denied in God of War folder." -ForegroundColor Yellow
        Write-Host "[*] Requesting Windows Administrator elevation (UAC)..." -ForegroundColor Cyan
        try {
            $psi = New-Object System.Diagnostics.ProcessStartInfo
            $psi.FileName = "powershell.exe"
            $psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -TargetDir `"$game`""
            $psi.Verb = "runas"
            $elevatedProc = [System.Diagnostics.Process]::Start($psi)
            $elevatedProc.WaitForExit()
            exit $elevatedProc.ExitCode
        } catch {
            Write-Host "ERROR: Administrator elevation was denied or failed." -ForegroundColor Red
            Write-Host "If God of War is in 'Program Files', please right-click Install.bat and select 'Run as administrator'." -ForegroundColor Yellow
            exit 1
        }
    } else {
        Write-Host "ERROR: Write access denied in God of War folder even with Administrator rights." -ForegroundColor Red
        Write-Host "Please ensure the folder is not marked Read-Only or locked by another application." -ForegroundColor Yellow
        exit 1
    }
}

$sourceRoot = Split-Path -Parent $PSScriptRoot
$manifestPath = Join-Path $sourceRoot "manifest.json"
if (-not (Test-Path $manifestPath)) {
    Write-Host "ERROR: manifest.json missing from installer package." -ForegroundColor Red
    Write-Host "Please extract the full ZIP archive before running Install.bat." -ForegroundColor Yellow
    exit 1
}
$manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json

function Get-FileSha256([string]$filePath) {
    if (Get-Command Get-FileHash -ErrorAction SilentlyContinue) {
        return (Get-FileHash -LiteralPath $filePath -Algorithm SHA256).Hash.ToLowerInvariant()
    }
    $resolved = (Resolve-Path -LiteralPath $filePath).Path
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $fs = [System.IO.File]::OpenRead($resolved)
    try {
        $hash = $sha.ComputeHash($fs)
        return ([System.BitConverter]::ToString($hash) -replace '-','').ToLowerInvariant()
    } finally {
        $fs.Close()
        $sha.Dispose()
    }
}

# Check all inputs before game files change.
$exeHash = Get-FileSha256 (Join-Path $game "GoW.exe")
$supported = $manifest.supported_exe_sha256
if ($supported -and $supported -ne "*" -and $supported -ne "any") {
    $allowedHashes = @()
    if ($supported -is [System.Collections.IEnumerable] -and $supported -isnot [string]) {
        foreach ($h in $supported) { $allowedHashes += "$h".ToLowerInvariant() }
    } elseif ("$supported" -match '^[0-9a-f]{64}$') {
        $allowedHashes += "$supported".ToLowerInvariant()
    }
    if ($allowedHashes.Count -gt 0 -and $allowedHashes -notcontains $exeHash -and -not (Test-Path (Join-Path $game "allow_unofficial.txt")) -and -not $env:GOW_ALLOW_UNOFFICIAL) {
        Write-Host "ERROR: Unsupported GoW.exe. No game files changed." -ForegroundColor Red
        Write-Host "Supported: $($allowedHashes -join ', ')"
        Write-Host "Found SHA256: $exeHash"
        exit 1
    }
}
Write-Host "[+] Found GoW.exe (SHA256: $exeHash)" -ForegroundColor Green

# Prerequisite check: GoW Script Loader (version.dll) & Configuration
$scriptLoader = Join-Path $game "version.dll"
$prereqLoader = Join-Path $sourceRoot "prerequisites\version.dll"
$gameModsDir = Join-Path $game "mods"
$gameLoaderConfig = Join-Path $gameModsDir "loader_config.toml"
$pkgLoaderConfig = Join-Path $sourceRoot "mods\loader_config.toml"
if (-not (Test-Path -LiteralPath $pkgLoaderConfig)) {
    $pkgLoaderConfig = Join-Path $sourceRoot "prerequisites\loader_config.toml"
}
$pendingInstallLoader = $false

if (Test-Path -LiteralPath $scriptLoader) {
    Write-Host "[+] Found GoW Script Loader (version.dll)" -ForegroundColor Green
} elseif (Test-Path -LiteralPath $prereqLoader) {
    Write-Host "[*] GoW Script Loader (version.dll) not detected in game folder - will be installed automatically." -ForegroundColor Cyan
    $pendingInstallLoader = $true
} else {
    Write-Host ""
    Write-Host "========================================================" -ForegroundColor Yellow
    Write-Host "  WARNING: GoW Script Loader (version.dll) NOT DETECTED! " -ForegroundColor Yellow
    Write-Host "========================================================" -ForegroundColor Yellow
    Write-Host "God of War requires 'version.dll' (GoW Script Loader) to load" -ForegroundColor Yellow
    Write-Host "custom Lua scripts from mods/lua/." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "WITHOUT version.dll:" -ForegroundColor Yellow
    Write-Host "  * Map markers will show up, but will NOT disappear when items/chests are collected!" -ForegroundColor Yellow
    Write-Host "  * Category filters and show/hide marker toggle will not function." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Please download and install GoW Script Loader from Nexus Mods:" -ForegroundColor Cyan
    Write-Host "  https://www.nexusmods.com/godofwar/mods/15" -ForegroundColor Cyan
    Write-Host "Place 'version.dll' directly into your God of War game folder." -ForegroundColor Cyan
    Write-Host "========================================================" -ForegroundColor Yellow
    Write-Host ""
}

if (-not $manifest.files -or @($manifest.files.PSObject.Properties).Count -eq 0) {
    Write-Host "ERROR: Package file list empty." -ForegroundColor Red
    exit 1
}
foreach ($file in $manifest.files.PSObject.Properties) {
    $rel = $file.Name
    if ([IO.Path]::IsPathRooted($rel) -or $rel -match '(^|[\\/])\.\.([\\/]|$)|:') {
        Write-Host "ERROR: Invalid package path: $rel" -ForegroundColor Red
        exit 1
    }
    $src = Join-Path $sourceRoot $rel
    if (-not (Test-Path -LiteralPath $src -PathType Leaf)) {
        Write-Host "ERROR: Package file missing: $rel. No game files changed." -ForegroundColor Red
        exit 1
    }
    $expected = $file.Value.sha256
    $actual = Get-FileSha256 $src
    if ($expected -notmatch '^[0-9a-f]{64}$' -or $actual -ne $expected) {
        Write-Host "ERROR: Package hash mismatch: $rel. Extract fresh ZIP; no game files changed." -ForegroundColor Red
        exit 1
    }
}
Assert-CompletionistInstallPaths $game $manifest
$preparedLoaderConfig = Get-CompletionistLoaderConfig $game $manifest
$bootPath = Join-Path $game "exec\boot-options.json"
$preparedBoot = $null
try {
    $boot = Get-Content -LiteralPath $bootPath -Raw | ConvertFrom-Json
    if ($boot -isnot [PSCustomObject]) { throw "Expected JSON object." }
    $entry = "../../patch/pc_le/completionist_v105_family_art"
    $packs = @($boot.'patch-texpacks' | Where-Object { $_ })
    if ($entry -notin $packs) {
        $boot | Add-Member -MemberType NoteProperty -Name 'patch-texpacks' -Value @($packs + $entry) -Force
        $preparedBoot = $boot | ConvertTo-Json -Depth 32
    }
} catch {
    Write-Host "ERROR: Cannot read boot-options.json: $_. No game files changed." -ForegroundColor Red
    exit 1
}

$reshadePlan = Get-CompletionistReShadePlan $game $manifest
Assert-CompletionistExistingBackup $game $manifest

# Keep stock backup.
$backupDir = Join-Path $game "completionist_backup"
$backupManifest = Join-Path $backupDir "backup_manifest.json"
if (-not (Test-Path $backupDir)) {
    New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
}

$backedUp = @{}
if (Test-Path $backupManifest) {
    Write-Host "[i] Existing stock backup found in completionist_backup. Preserving original backup." -ForegroundColor Yellow
} else {
    Write-Host "[*] Creating safe backup of stock game files..." -ForegroundColor Cyan
    foreach ($rel in $manifest.files.PSObject.Properties.Name) {
        $target = Join-Path $game $rel
        if (Test-Path $target) {
            $dest = Join-Path $backupDir $rel
            $destParent = Split-Path -Parent $dest
            if (-not (Test-Path $destParent)) {
                New-Item -ItemType Directory -Force -Path $destParent | Out-Null
            }
            Copy-CompletionistDxgi $target $dest
            $backedUp[$rel] = Get-FileSha256 $target
        }
    }
    # Also backup boot-options.json
    $bootPath = Join-Path $game "exec\boot-options.json"
    if (Test-Path $bootPath) {
        $destBoot = Join-Path $backupDir "exec\boot-options.json"
        $destBootParent = Split-Path -Parent $destBoot
        if (-not (Test-Path $destBootParent)) { New-Item -ItemType Directory -Force -Path $destBootParent | Out-Null }
        Copy-CompletionistDxgi $bootPath $destBoot
        $backedUp["exec/boot-options.json"] = Get-FileSha256 $bootPath
    }

    $backupInfo = @{
        "created_at" = (Get-Date).ToString("o")
        "files" = $backedUp
    }
    $backupInfo | ConvertTo-Json -Depth 5 | Set-Content -Path $backupManifest -Encoding UTF8
    Write-Host "[+] Backed up $(($backedUp.Keys).Count) stock files to completionist_backup." -ForegroundColor Green
}

Save-CompletionistReShade $game $reshadePlan

# Copy mod files
Write-Host "[*] Installing Completionist Map mod files..." -ForegroundColor Cyan
$installCount = 0
foreach ($rel in $manifest.files.PSObject.Properties.Name) {
    $src = Join-Path $sourceRoot $rel
    if (-not (Test-Path $src)) {
        Write-Host "ERROR: Package file missing: $rel" -ForegroundColor Red
        exit 1
    }
    $dest = Join-Path $game $rel
    $destParent = Split-Path -Parent $dest
    if (-not (Test-Path $destParent)) {
        New-Item -ItemType Directory -Force -Path $destParent | Out-Null
    }
    if ($rel -eq 'mods/loader_config.toml' -and (Test-Path -LiteralPath $dest)) { continue }
    Copy-CompletionistDxgi $src $dest
    $installCount++
}

# Install bundled prerequisite if needed
if ($pendingInstallLoader -and (Test-Path -LiteralPath $prereqLoader)) {
    Copy-Item -LiteralPath $prereqLoader -Destination $scriptLoader -Force
    Write-Host "[+] Installed bundled GoW Script Loader (version.dll) to game folder." -ForegroundColor Green
}

Enable-CompletionistReShade $game $reshadePlan
if ($null -ne $preparedLoaderConfig) {
    Write-CompletionistText $gameLoaderConfig $preparedLoaderConfig
}

# Ensure GoW Script Loader configuration is present in mods directory
if (-not (Test-Path -LiteralPath $gameLoaderConfig) -and (Test-Path -LiteralPath $pkgLoaderConfig)) {
    if (-not (Test-Path -LiteralPath $gameModsDir)) {
        New-Item -ItemType Directory -Force -Path $gameModsDir | Out-Null
    }
    Copy-Item -LiteralPath $pkgLoaderConfig -Destination $gameLoaderConfig -Force
    Write-Host "[+] Installed GoW Script Loader configuration (mods\loader_config.toml)." -ForegroundColor Green
} elseif (Test-Path -LiteralPath $gameLoaderConfig) {
    Write-Host "[+] Verified GoW Script Loader configuration (mods\loader_config.toml)." -ForegroundColor Green
}

# Add art pack with no UTF-8 BOM.
if ($null -ne $preparedBoot) {
    Write-CompletionistText $bootPath $preparedBoot
    Write-Host "[+] Artwork patch texpack registered in boot-options.json" -ForegroundColor Green
}

Write-Host ""
Write-Host "========================================================" -ForegroundColor Green
Write-Host "           INSTALLATION COMPLETED SUCCESSFULLY!         " -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Green
Write-Host " Features active:" -ForegroundColor Cyan
Write-Host "  * 551 collectible marker records across 16 custom marker families"
Write-Host "  * GoW Script Loader (version.dll + loader_config.toml) verified & active" -ForegroundColor Green
Write-Host "  * Odin's Ravens with native authority & tracking"
Write-Host "  * Chest state persistence across restarts (wooden chests, etc.)"
Write-Host "  * Custom map markers & compass HUD icons with distance meters"
Write-Host "  * In-map [Down Arrow] toggle button (Hide / Show Markers)"
Write-Host "  * Original stock files backed up to: completionist_backup"
if (Test-Path -LiteralPath $scriptLoader) {
    Write-Host "  * GoW Script Loader (version.dll) verified / active" -ForegroundColor Green
}
Write-Host ""
Write-Host "You can now launch God of War!" -ForegroundColor Cyan
exit 0
