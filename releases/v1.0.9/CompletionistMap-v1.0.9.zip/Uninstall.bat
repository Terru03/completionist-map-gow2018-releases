@echo off
setlocal
cd /d "%~dp0"
echo ========================================================
echo   God of War (2018) - Completionist Map Mod Uninstaller
echo ========================================================
echo.
if not exist "%~dp0scripts\uninstall.ps1" (
    echo.
    echo ========================================================
    echo   [ERROR] Cannot find scripts\uninstall.ps1!
    echo ========================================================
    echo.
    echo It looks like you ran Uninstall.bat directly from inside
    echo the compressed ZIP archive.
    echo.
    echo Please EXTRACT the entire ZIP file to a folder first,
    echo then open that folder and run Uninstall.bat.
    echo.
    pause
    exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\uninstall.ps1" %*
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Uninstallation did not finish successfully (exit code %ERRORLEVEL%).
    pause
    exit /b %ERRORLEVEL%
)
echo.
pause
