@echo off
setlocal
cd /d "%~dp0"
echo ========================================================
echo   God of War (2018) - Completionist Map Mod Installer
echo ========================================================
echo.
if not exist "%~dp0scripts\install.ps1" (
    echo.
    echo ========================================================
    echo   [ERROR] Cannot find scripts\install.ps1!
    echo ========================================================
    echo.
    echo It looks like you ran Install.bat directly from inside
    echo the compressed ZIP archive.
    echo.
    echo Please EXTRACT the entire ZIP file to a folder first,
    echo then open that folder and run Install.bat.
    echo.
    pause
    exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install.ps1" %*
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Installation did not finish successfully (exit code %ERRORLEVEL%).
    pause
    exit /b %ERRORLEVEL%
)
echo.
pause
