#!/bin/bash
# Universal Installer for God of War (2018) Completionist Map Mod
# Steam Deck & Linux (SteamOS / Proton)
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "========================================================"
echo "  God of War (2018) - Completionist Map Mod Installer   "
echo "  (Steam Deck / Linux Proton)                           "
echo "========================================================"
echo ""

CANDIDATES=(
    "$1"
    "$HOME/.local/share/Steam/steamapps/common/GodOfWar"
    "$HOME/.steam/steam/steamapps/common/GodOfWar"
    "/run/media/mmcblk0p1/steamapps/common/GodOfWar"
)

for d in /run/media/*/*/steamapps/common/GodOfWar /run/media/*/*/GodOfWar; do
    if [ -d "$d" ]; then
        CANDIDATES+=("$d")
    fi
done

GAME_DIR=""
for c in "${CANDIDATES[@]}"; do
    if [ -n "$c" ] && [ -f "$c/GoW.exe" ]; then
        GAME_DIR="$c"
        break
    fi
done

if [ -z "$GAME_DIR" ]; then
    echo "ERROR: God of War installation folder could not be found automatically."
    echo "Usage: ./Install-SteamDeck.sh \"/path/to/GodOfWar\""
    exit 1
fi

echo "[+] Detected God of War at: $GAME_DIR"

BACKUP_DIR="$GAME_DIR/completionist_backup"
if [ ! -d "$BACKUP_DIR" ]; then
    echo "[*] Creating safe backup of stock files in: completionist_backup"
    mkdir -p "$BACKUP_DIR/exec/dc/pc_le"
    mkdir -p "$BACKUP_DIR/exec/wad/pc_le"
    for f in exec/dc/pc_le/mapcoords.dcb exec/dc/pc_le/mapmaster.dcb exec/dc/pc_le/wad_r_perm.dcb exec/dc/pc_le/wad_r_ui.dcb exec/wad/pc_le/r_ui.wad exec/boot-options.json; do
        if [ -f "$GAME_DIR/$f" ]; then
            mkdir -p "$(dirname "$BACKUP_DIR/$f")"
            cp "$GAME_DIR/$f" "$BACKUP_DIR/$f"
        fi
    done
fi

echo "[*] Installing mod files..."
cp -f "$SCRIPT_DIR/dxgi.dll" "$GAME_DIR/"
cp -rf "$SCRIPT_DIR/exec" "$GAME_DIR/"
cp -rf "$SCRIPT_DIR/mods" "$GAME_DIR/"

if [ ! -f "$GAME_DIR/version.dll" ] && [ -f "$SCRIPT_DIR/prerequisites/version.dll" ]; then
    echo "[*] Installing bundled GoW Script Loader (version.dll)..."
    cp -f "$SCRIPT_DIR/prerequisites/version.dll" "$GAME_DIR/version.dll"
    echo "[+] Installed GoW Script Loader (version.dll)"
elif [ -f "$GAME_DIR/version.dll" ]; then
    echo "[+] Found existing GoW Script Loader (version.dll)"
fi

if [ ! -f "$GAME_DIR/mods/loader_config.toml" ]; then
    mkdir -p "$GAME_DIR/mods"
    if [ -f "$SCRIPT_DIR/mods/loader_config.toml" ]; then
        cp -f "$SCRIPT_DIR/mods/loader_config.toml" "$GAME_DIR/mods/loader_config.toml"
        echo "[+] Installed GoW Script Loader configuration (mods/loader_config.toml)"
    elif [ -f "$SCRIPT_DIR/prerequisites/loader_config.toml" ]; then
        cp -f "$SCRIPT_DIR/prerequisites/loader_config.toml" "$GAME_DIR/mods/loader_config.toml"
        echo "[+] Installed GoW Script Loader configuration (mods/loader_config.toml)"
    fi
else
    echo "[+] Found GoW Script Loader configuration (mods/loader_config.toml)"
fi

BOOT_FILE="$GAME_DIR/exec/boot-options.json"
if [ -f "$BOOT_FILE" ]; then
    python3 -c "
import json
p = '$BOOT_FILE'
try:
    with open(p, 'r', encoding='utf-8') as f:
        data = json.load(f)
    entry = '../../patch/pc_le/completionist_v105_family_art'
    packs = data.get('patch-texpacks', [])
    if entry not in packs:
        packs.append(entry)
        data['patch-texpacks'] = packs
        with open(p, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4)
        print('[+] Registered artwork texpack in boot-options.json')
    else:
        print('[+] Artwork texpack already registered in boot-options.json')
except Exception as e:
    print('Warning: could not update boot-options.json:', e)
"
fi

echo ""
echo "========================================================"
echo "          INSTALLATION COMPLETED SUCCESSFULLY!          "
echo "========================================================"
echo ""
echo "CRITICAL FOR STEAM DECK / LINUX (PROTON):"
echo "In the Steam client, right click God of War -> Properties ->"
echo "in 'Launch Options', set:"
echo ""
echo '  WINEDLLOVERRIDES="dxgi,version=n,b" %command%'
echo ""
echo "This instructs Proton to load the mod's native DLLs."
echo "========================================================"
