local LD = require("design.LevelDesignLibrary")
local thisLevel, thisObj, player, son, LootObject, idleFX_Sparkle, regionSummaryQuest, frontInteractZone, interactionOnStart, interactionOnFinish, artifactType, uniqueResource, pickupType, typeSpecificData, state
local states = {
  ENABLED = 1,
  DISABLED = 2,
  ACQUIRED = 3
}
function OnScriptLoaded(level, obj)
  thisLevel = level
  thisObj = obj
  player = game.Player.FindPlayer()
  son = game.AI.FindSon()
  LootObject = thisObj.Parent.Parent:FindSingleGOByName("LootObject")
  idleFX_Sparkle = thisObj.Parent.Parent:FindSingleGOByName("ArtifactMaskFX")
  artifactType = obj:FindLuaTableAttribute("ArtifactType")
  pickupType = obj:FindLuaTableAttribute("PickupType")
  regionSummaryQuest = thisObj:FindLuaTableAttribute("regionSummaryQuest")
  frontInteractZone = LD.CreateInteractZone_LootPickup_360(LootObject.Child, "zeroJoint")
  frontInteractZone:SetTags("CarryActive")
  if artifactType == "Lambs Cress" then
    frontInteractZone:SetHintXZRange(5)
  end
  local startEnabled = obj:GetLuaTableAttribute("StartEnabled")
  interactionOnStart = obj:FindLuaTableAttribute("interactionOnStart")
  interactionOnFinish = obj:FindLuaTableAttribute("interactionOnFinish")
  uniqueResource = obj:FindLuaTableAttribute("ArtifactUniqueName")
  local useLOSTest = thisObj:GetLuaTableAttribute("UseLineOfSightTest")
  if useLOSTest and frontInteractZone then
    frontInteractZone:SetEnableLineOfSightTest(true)
  end
  if interactionOnStart ~= nil then
    interactionOnStart = LD.ExtractCallbacksForEvent(thisLevel, obj, interactionOnStart)
  end
  if interactionOnFinish ~= nil then
    interactionOnFinish = LD.ExtractCallbacksForEvent(thisLevel, obj, interactionOnFinish)
  end
  if startEnabled then
    state = states.ENABLED
  else
    state = states.DISABLED
  end
  typeSpecificData = {}
  game.SubObject.Sleep(obj)
  SoundInit()
end
function OnSaveCheckpoint(level, obj)
  return {state = state}
end
function OnRestoreCheckpoint(level, obj, tab)
  state = tab.state
end
function OnStart(level, obj)
  if state == states.ACQUIRED then
    Disable()
    HideAllFX()
    LootObject:Hide()
    return
  elseif state == states.ENABLED then
    Enable()
  else
    Disable()
  end
end
function OnUseWorld(level, obj)
  if frontInteractZone:PlayerCanInteract() then
    LD.SetFacingTowardObject(obj, player, {ignoreYAxis = true, invertFacing = true})
    player:RequestInteract(obj, {
      InteractZone = frontInteractZone,
      LerpObject = LootObject.Child
    })
  end
end
function OnInteractStart(level, obj, creature)
  if interactionOnStart ~= nil then
    LD.ExecuteCallbacksForEvent(thisLevel, thisObj, interactionOnStart, "Interaction Event Start")
  end
  local weaponMode = "Any"
  if player:GetCurrentWeapon() ~= "Axe" then
    weaponMode = "Bare"
  end
  if pickupType == "Wrap" then
    LD.PlaySingleSynchMove_KratosObject(thisObj, "synchJoint", "picking up artifact, type: " .. tostring(artifactType), "BRA_PickUpArtifactEnterWrap", "", frontInteractZone, true, weaponMode)
  elseif pickupType == "Palm" then
    LD.PlaySingleSynchMove_KratosObject(thisObj, "synchJoint", "picking up artifact, type: " .. tostring(artifactType), "BRA_PickUpArtifactEnterPalm", "", frontInteractZone, true, weaponMode)
  end
end
function OnInteractFinish()
  if interactionOnFinish ~= nil then
    LD.ExecuteCallbacksForEvent(thisLevel, thisObj, interactionOnFinish, "Interaction Event Finish")
  end
end
function PickUp(level, obj, creature)
  HideAllFX()
  PlaySoundPickup()
end
function HideAllFX()
  local glowFX = LootObject:FindGOsByName("PickUp_Glow*")
  if glowFX then
    for _, fx in pairs(glowFX) do
      LD.HideFX(fx)
    end
  end
  if idleFX_Sparkle then
    LD.HideFX(idleFX_Sparkle)
  end
end
function LuaHook_GiveLoot()
  if artifactType ~= "Lambs Cress" then
    IncrementCounter()
  end
end
function LuaHook_HideLoot()
  LootObject.Child:HideModel()
  LootObject.Child:HideAudio()
end
function SetTypeData()
  if artifactType == "Alfheim" then
    typeSpecificData.questState = "Quest_Artifacts_Alfheim_Parent"
    typeSpecificData.recipe = "Recipe_Artifacts_Alfheim"
    typeSpecificData.questProgress = "Quest_Artifacts_Alfheim"
    typeSpecificData.resource = "AlfheimArtifact"
  elseif artifactType == "Brooch" then
    typeSpecificData.questState = "Quest_Artifacts_Brooches_Parent"
    typeSpecificData.recipe = "Recipe_Artifacts_Brooches"
    typeSpecificData.questProgress = "Quest_Artifacts_Brooches"
    typeSpecificData.resource = "Brooch"
  elseif artifactType == "Cup" then
    typeSpecificData.questState = "Quest_Artifacts_OrnateCups_Parent"
    typeSpecificData.recipe = "Recipe_Artifacts_Cups"
    typeSpecificData.questProgress = "Quest_Artifacts_OrnateCups"
    typeSpecificData.resource = "OrnateCup"
  elseif artifactType == "Horn" then
    typeSpecificData.questState = "Quest_Artifacts_VikingHorns_Parent"
    typeSpecificData.recipe = "Recipe_Artifacts_Horns"
    typeSpecificData.questProgress = "Quest_Artifacts_VikingHorns"
    typeSpecificData.resource = "VikingHorn"
  elseif artifactType == "Mask" then
    typeSpecificData.questState = "Quest_Artifacts_NorseMasks_Parent"
    typeSpecificData.recipe = "Recipe_Artifacts_NorseMasks"
    typeSpecificData.questProgress = "Quest_Artifacts_NorseMasks"
    typeSpecificData.resource = "NorseMask"
  elseif artifactType == "Ship Head" then
    typeSpecificData.questState = "Quest_Artifacts_ShipHeads_Parent"
    typeSpecificData.recipe = "Recipe_Artifacts_ShipHeads"
    typeSpecificData.questProgress = "Quest_Artifacts_ShipHeads"
    typeSpecificData.resource = "ShipHead"
  elseif artifactType == "Toy" then
    typeSpecificData.questState = "Quest_Artifacts_LostToys_Parent"
    typeSpecificData.recipe = "Recipe_Artifacts_Toys"
    typeSpecificData.questProgress = "Quest_Artifacts_LostToys"
    typeSpecificData.resource = "LostToy"
  end
end
function IncrementCounter(level, obj)
  SetTypeData()
  local questState = game.QuestManager.GetQuestState(typeSpecificData.questState)
  local audioPlayed = false
  if questState == "Inactive" then
    game.QuestManager.StartQuest(typeSpecificData.questState)
    game.Wallets.AddRecipe("HERO", typeSpecificData.recipe)
    if son:IsAvailableInLevel() and game.Audio.CanBanterConversationPlay("Artifact_FirstCollected") then
      game.Audio.PlayBanterNonCritical("Artifact_FirstCollected")
      audioPlayed = true
    end
  end
  ActivateRegionSummaryQuest()
  game.QuestManager.IncrementQuestProgress(typeSpecificData.questProgress, 1)
  if CheckAllArtifactQuestStatus() == true then
    AwardTrophy()
  end
  game.Wallets.AddResource("HERO", typeSpecificData.resource, 1, LootObject:GetName(), "Artifact")
  game.Wallets.AddResource("HERO", uniqueResource, 1, LootObject:GetName(), "Artifact")
  state = states.ACQUIRED
  SoftSave()
  if audioPlayed == false then
    CheckQuestStatus(typeSpecificData.questState)
  end
  if game.QuestManager.GetQuestState("Quest_Artifacts_ShipHeads") == "Complete" then
    FixupShipHeadRegion()
  end
end
function CheckQuestStatus(questInfo)
  if son:IsAvailableInLevel() then
    local questState = game.QuestManager.GetQuestState(questInfo)
    if questState == "Complete" then
      game.Audio.PlayBanterNonCritical("Artifact_Complete")
    else
      game.Audio.PlayBanterNonCritical("Artifact_Subsequent")
    end
  end
end
function CheckAllArtifactQuestStatus()
  if game.QuestManager.GetQuestState("Quest_Artifacts_Alfheim") == "Complete" and game.QuestManager.GetQuestState("Quest_Artifacts_Brooches") == "Complete" and game.QuestManager.GetQuestState("Quest_Artifacts_OrnateCups") == "Complete" and game.QuestManager.GetQuestState("Quest_Artifacts_VikingHorns") == "Complete" and game.QuestManager.GetQuestState("Quest_Artifacts_NorseMasks") == "Complete" and game.QuestManager.GetQuestState("Quest_Artifacts_ShipHeads") == "Complete" and game.QuestManager.GetQuestState("Quest_Artifacts_LostToys") == "Complete" then
    return true
  end
  return false
end
function ActivateRegionSummaryQuest()
  if regionSummaryQuest ~= nil and regionSummaryQuest ~= "" then
    regionSummaryQuest = string.gsub(regionSummaryQuest, "%s+", "")
    LD.ActivateAndIncrementQuest(regionSummaryQuest)
  end
end
function AwardTrophy()
  print("Award Trophy: My Precious")
  game.UnlockTrophy(24)
end
function SoftSave(level, obj)
  print("soft save occurred")
  game.SubObject.SoftSave(thisObj)
end
function FixupShipHeadRegion()
  print("FIXING UP SHIP HEAD")
  LD.ActivateAndIncrementQuest("RegionSummary_CALS_Shiphead_Parent")
end
function Enable()
  if state ~= states.ACQUIRED then
    state = states.ENABLED
    frontInteractZone:Enable()
  end
end
function Disable()
  if state ~= states.ACQUIRED then
    state = states.DISABLED
  end
  frontInteractZone:Disable()
end
local soundEmitter
local soundEvents = {
  Alfheim_Idle = "SND_LOOT_Chalice_Idle_LP",
  Alfheim_Pickup = "SND_LOOT_Artifact_Alfheim_Pickup",
  Brooch_Idle = "SND_LOOT_Chalice_Idle_LP",
  Brooch_Pickup = "SND_LOOT_Artifact_Brooch_Pickup",
  Cup_Idle = "SND_LOOT_Chalice_Idle_LP",
  Cup_Pickup = "SND_LOOT_Artifact_Cup_Pickup",
  Horn_Idle = "SND_LOOT_Chalice_Idle_LP",
  Horn_Pickup = "SND_LOOT_Artifact_Horn_Pickup",
  Mask_Idle = "SND_LOOT_Chalice_Idle_LP",
  Mask_Pickup = "SND_LOOT_Artifact_Mask_Pickup",
  Ship_Head_Idle = "SND_LOOT_Chalice_Idle_LP",
  Ship_Head_Pickup = "SND_LOOT_Artifact_Ship_Head_Pickup",
  Toy_Idle = "SND_LOOT_Chalice_Idle_LP",
  Toy_Pickup = "SND_LOOT_Artifact_Toy_Pickup",
  LambsCress_Pickup = "SND_EVNT_Freya_Garden_Flower_Pull_Kratos",
  Default_Idle = "SND_LOOT_Shard_White_LP",
  Default_Pickup = "SND_CHR_Kratos_Foley_Item_Pickup_Generic"
}
function SoundInit()
  soundEmitter = LootObject.Child.SoundEmitters[1]
  PlaySoundIdleLoop()
end
function PlaySoundIdleLoop()
  if artifactType == "Alfheim" then
    LD.PlayRestartableSoundLoop(soundEmitter, soundEvents.Alfheim_Idle)
  elseif artifactType == "Brooch" then
    LD.PlayRestartableSoundLoop(soundEmitter, soundEvents.Brooch_Idle)
  elseif artifactType == "Cup" then
    LD.PlayRestartableSoundLoop(soundEmitter, soundEvents.Cup_Idle)
  elseif artifactType == "Horn" then
    LD.PlayRestartableSoundLoop(soundEmitter, soundEvents.Horn_Idle)
  elseif artifactType == "Mask" then
    LD.PlayRestartableSoundLoop(soundEmitter, soundEvents.Mask_Idle)
  elseif artifactType == "Ship Head" then
    LD.PlayRestartableSoundLoop(soundEmitter, soundEvents.Ship_Head_Idle)
  elseif artifactType == "Toy" then
    LD.PlayRestartableSoundLoop(soundEmitter, soundEvents.Toy_Idle)
  else
    LD.PlayRestartableSoundLoop(soundEmitter, soundEvents.Default_Idle)
  end
end
function PlaySoundPickup()
  if artifactType == "Alfheim" then
    LD.StopRestartableSoundLoop(soundEmitter, soundEvents.Alfheim_Idle)
    LD.PlaySound(soundEmitter, soundEvents.Alfheim_Pickup)
  elseif artifactType == "Brooch" then
    LD.StopRestartableSoundLoop(soundEmitter, soundEvents.Brooch_Idle)
    LD.PlaySound(soundEmitter, soundEvents.Brooch_Pickup)
  elseif artifactType == "Cup" then
    LD.StopRestartableSoundLoop(soundEmitter, soundEvents.Cup_Idle)
    LD.PlaySound(soundEmitter, soundEvents.Cup_Pickup)
  elseif artifactType == "Horn" then
    LD.StopRestartableSoundLoop(soundEmitter, soundEvents.Horn_Idle)
    LD.PlaySound(soundEmitter, soundEvents.Horn_Pickup)
  elseif artifactType == "Mask" then
    LD.StopRestartableSoundLoop(soundEmitter, soundEvents.Mask_Idle)
    LD.PlaySound(soundEmitter, soundEvents.Mask_Pickup)
  elseif artifactType == "Ship Head" then
    LD.StopRestartableSoundLoop(soundEmitter, soundEvents.Ship_Head_Idle)
    LD.PlaySound(soundEmitter, soundEvents.Ship_Head_Pickup)
  elseif artifactType == "Toy" then
    LD.StopRestartableSoundLoop(soundEmitter, soundEvents.Toy_Idle)
    LD.PlaySound(soundEmitter, soundEvents.Toy_Pickup)
  elseif artifactType == "Lambs Cress" then
    LD.PlaySound(player:FindSingleSoundEmitterByName("SNDLeftHand"), soundEvents.LambsCress_Pickup)
  else
    LD.StopRestartableSoundLoop(soundEmitter, soundEvents.Default_Idle)
    LD.PlaySound(soundEmitter, soundEvents.Default_Pickup)
  end
end

-- BEGIN COMPLETIONIST COLLECTIBLE OBSERVATION
do
  function GetState()
    return state
  end
  function IsAcquired()
    return state == states.ACQUIRED
  end
  function CompletionistCollectibleObserve()
    if type(state) ~= "number" or state < 1 or state > 3 or state ~= math.floor(state) then return nil end
    local collected = state == 3
    return "artefact", collected and "collected" or "remaining"
  end
  local function clearActiveCompassMarker()
    pcall(function()
      if type(game) == "table" and type(game.Compass) == "table" and type(game.Compass.FindMarkersByIconClass) == "function" then
        local markers = game.Compass.FindMarkersByIconClass({"SIDE"})
        if type(markers) == "table" then
          for _, id in ipairs(markers) do
            pcall(game.Compass.HideMarker, id)
          end
        end
      end
    end)
  end
  local function notify()
    clearActiveCompassMarker()
    if thisLevel == nil or type(thisLevel.Name) ~= "string" then return end
    engine.SendHook("COMPLETIONIST_COLLECTIBLE_DIRTY_V1", engine.GetUIWad(),
      "COLLECTIBLE_DIRTY_V1	" .. string.lower(thisLevel.Name))
  end
  local function pack(...) return {n=select('#',...), ...} end
  local unpackValues = unpack or table.unpack
  local function wrap(original)
    return function(...)
      local result = pack(original(...))
      pcall(notify)
      return unpackValues(result, 1, result.n)
    end
  end
  if type(LuaHook_GiveLoot) == "function" then LuaHook_GiveLoot = wrap(LuaHook_GiveLoot) end
  if type(IncrementCounter) == "function" then IncrementCounter = wrap(IncrementCounter) end
  if type(OnStart) == "function" then OnStart = wrap(OnStart) end
  if type(OnRestoreCheckpoint) == "function" then OnRestoreCheckpoint = wrap(OnRestoreCheckpoint) end
end
-- END COMPLETIONIST COLLECTIBLE OBSERVATION
-- BEGIN COMPLETIONIST PROXIMITY V1.1.0
-- Shows the game's native interact hint dot on this collectible out to the
-- map's [Up Arrow] range. Append-only: OnScriptLoaded runs unchanged first;
-- every call below is pcall-guarded.
do
  local probeRows = {
    {"xpl200_funeral", "artefact", "artefact_xpl200funeralwad52e9ebf8ef1b3343b5d025a73ad6fa91", 1, "artifactscript", "artifacthorn02"},
    {"xpl250_funeralinterior", "artefact", "artefact_xpl250funeralinteriorwad4813767722fa414b9a3d4972dc8874e7", 26, "artifactscript", "artifacthorn04"},
    {"riv475_freyahouseext", "artefact", "artefact_28b7fe1349cdc49da573c6a0657f0a9d", 27, "artifactscript", "artifactmask12"},
    {"for400_intersection", "artefact", "artefact_a0588a9442f0118bdce0cda751b8605d", 28, "artifactscript", "artifacttoy04", "artifacttoy04_new"},
    {"alfdgn110_main", "artefact", "artefact_48edaa8b407e24bed474bebea8ea3821", 37, "artifactscript", "artifactalfheim02", "artifactalfheim02_rn"},
    {"for650_bridge", "artefact", "artefact_8916f55c4511b74ba8601ba7ef3d86bb", 43, "artifactscript", "artifacttoy05"},
    {"xpl910_islandshipwreck", "artefact", "artefact_fda837834b361579d4a29194810c3d09", 71, "artifactscript", "artifactshiphead01", "artifactshiphead_inupperarena"},
    {"cal100_hub", "artefact", "artefact_4a3d314942f187f69ee5b78302e118fe", 78, "artifactscript", "artifactshiphead05"},
    {"hel300_mainbridge", "artefact", "artefact_hel300mainbridgewadb5b33ffb0d723f44a135047d5a839e32", 82, "artifactscript", "artifactbrooch05", "artifactbrooch05_refnode"},
    {"riv925_freyacave", "artefact", "artefact_fa511e0a422421b7acc01fa5829c4fe3", 83, "artifactscript", "artifactmask01"},
    {"hel300_mainbridge", "artefact", "artefact_hel300mainbridgewade4b6326ae64d514490a45593d471478f", 84, "artifactscript", "artifactbrooch04"},
    {"xpl200_funeral", "artefact", "artefact_xpl200funeralwad2768cb29f445634bb075f7a858cabcc3", 99, "artifactscript", "artifacthorn01"},
    {"alf370_moatscripting", "artefact", "artefact_5bf15dbc48613f5b548fd2a673d8f7bc", 113, "artifactscript", "artifactalfheim04"},
    {"riv400_forestintro", "artefact", "artefact_6fa420df406be3d033b7eea35a4d10fe", 115, "artifactscript", "artifactmask08"},
    {"xpl250_funeralinterior", "artefact", "artefact_xpl250funeralinteriorwad3f176e49e0a0cd4f8cf59ada5fe9c2d8", 122, "artifactscript", "artifacthorn06"},
    {"for560_wolfpit", "artefact", "artefact_ab662cc14c4a21327111dea1a34b96c3", 124, "artifactscript", "artifacttoy01"},
    {"peak140_caverndark", "artefact", "artefact_fae85e594ef79ee2e204719767dd5287", 133, "artifactscript", "artifactcup01"},
    {"peak720_summitascenthub", "artefact", "artefact_b52df62545c16741e6f2278f9e2ccc32", 153, "artifactscript", "artifactcup04"},
    {"xpl940_beachcave", "artefact", "artefact_7d8a35dc4d6aabf8065e1ead0c470fcc", 155, "artifactscript", "artifactshiphead06"},
    {"riv475_freyahouseext", "artefact", "artefact_cf7627ad486711d9eab3339782e5a147", 160, "artifactscript", "artifactmask11"},
    {"peak740_summitpeak", "artefact", "artefact_b18794364cc6b6a5c08596ab8699f35b", 187, "artifactscript", "artifactcup03"},
    {"alf325_trenchadarktwr", "artefact", "artefact_707ae0e24dc7bc9a56c19eb7ce17b351", 188, "artifactscript", "artifactalfheim06"},
    {"riv430_forestboartrack", "artefact", "artefact_468c195b480889e354742b876aef3a11", 189, "artifactscript", "artifactmask09", "artifactmask9"},
    {"alfdgn210_main", "artefact", "artefact_6e3739ea4ac8107c495a61af774a9b03", 195, "artifactscript", "artifactalfheim01"},
    {"xpl980_beachwaterfall", "artefact", "artefact_6cffc9884efa77b424baf987adfdba6a", 214, "artifactscript", "artifactshiphead07", "artifactshiphead_ontower"},
    {"xpl980_beachwaterfall", "artefact", "artefact_379728fc47e4a966be1fc9926011184b", 217, "artifactscript", "artifactshiphead03", "artifactshiphead_incubby"},
    {"for200_house", "artefact", "artefact_989065ff4bde64f5ec957da2759037cb", 219, "artifactscript", "artifacttoy02"},
    {"hel350_chiselarena", "artefact", "artefact_c7f91ac1447cff68599696bbbb58e7b7", 226, "artifactscript", "artifactbrooch01"},
    {"hel100_calderaheldressing", "artefact", "artefact_eb672a1647b1f7e64595e48f821670f5", 233, "artifactscript", "artifactbrooch02"},
    {"xpl200_funeral", "artefact", "artefact_xpl200funeralwadbb9465a7407c9849bf891e0205dac801", 251, "artifactscript", "artifacthorn05"},
    {"peak210_rollerroomlh", "artefact", "artefact_33f59ee746f63f40199e5f90cad3c236", 274, "artifactscript", "artifactcup02"},
    {"riv325_dangersexit", "artefact", "artefact_0da7cb9744da59cb80fe319d95cada55", 277, "artifactscript", "artifactmask06"},
    {"riv350_calderavista", "artefact", "artefact_c9b7e23040c21e2da5fe8ba4be8ad415", 278, "artifactscript", "artifactmask07"},
    {"riv200_dangersmain", "artefact", "artefact_0a43e4954d4fff46abb9ca8e34d875c0", 288, "artifactscript", "artifactmask05"},
    {"xpl970_beachtower", "artefact", "artefact_01a8ba24409b5fb49a1c18b43669fe44", 297, "artifactscript", "artifactshiphead02", "artifactshiphead02xx01xx"},
    {"xpl960_beachship", "artefact", "artefact_bd9a46a34b8fd4660be2129e27fa4004", 306, "artifactscript", "artifactshiphead09", "artifactshiphead_ontower"},
    {"cal100_hub", "artefact", "artefact_f7fbfc3f44991b3da37871879e6de737", 315, "artifactscript", "artifactshiphead08"},
    {"alf340_trenchbdark", "artefact", "artefact_0d53040849957335c6db68809206f5d1", 333, "artifactscript", "artifactalfheim03"},
    {"xpl950_beachmaze", "artefact", "artefact_5bb11ed5419b42caba813598d29ca473", 334, "artifactscript", "artifactshiphead04"},
    {"alf345_trenchbdarktwr", "artefact", "artefact_56c4354a4141de7afc7f2e8447ab8767", 349, "artifactscript", "artifactalfheim05"},
    {"peak780_summitexit", "artefact", "artefact_f5bd8953457f9662d074d798a111abfc", 353, "artifactscript", "artifactcup06"},
    {"peak200_chimneylow", "artefact", "artefact_6f83c0ef48eda412050135a827d51a7a", 362, "artifactscript", "artifactcup05"},
    {"riv200_dangersmain", "artefact", "artefact_85c29c2b420306564c28b5b09e22532c", 379, "artifactscript", "artifactmask04"},
    {"hel300_mainbridge", "artefact", "artefact_hel300mainbridgewad00c124ebae0bc24f8b64cc6305246b22", 382, "artifactscript", "artifactbrooch03"},
    {"xpl200_funeral", "artefact", "artefact_xpl200funeralwadb6e2b2a41a1b3e4c9ff1f8e5f877039a", 407, "artifactscript", "artifacthorn03"},
  }
  local probeFamily = nil
  local probeDefaultRange = 50
  local probeMember = nil
  local probeErrors = {}

  local function probeLog(text)
    print("[CompletionistProximity] " .. text)
  end

  local function probeError(key, err)
    if not probeErrors[key] then
      probeErrors[key] = true
      probeLog("error " .. key .. " " .. tostring(err))
    end
  end

  local function probeLower(value, prefix)
    if type(value) ~= "string" then return nil end
    value = string.lower(value)
    if string.sub(value, 1, #prefix) == prefix then value = string.sub(value, #prefix + 1) end
    return value
  end

  local function probeName(go)
    if go == nil then return nil end
    local ok, name = pcall(function() return go:GetName() end)
    if ok then return probeLower(name, "go") end
  end

  local function probeParent(go)
    if go == nil then return nil end
    local ok, parent = pcall(function() return go.Parent end)
    if ok then return parent end
  end

  local function probeFind(node, name)
    for _, query in ipairs({name, "go" .. name}) do
      local ok, found = pcall(function() return node:FindSingleGOByName(query) end)
      if ok and found ~= nil then return found end
    end
  end

  local function probeChain(node, row)
    local cursor = node
    for index = 5, #row do
      if cursor == nil or probeName(cursor) ~= row[index] then return false end
      cursor = probeParent(cursor)
    end
    return true
  end

  -- Exact catalogue identity: level plus the owner name path, starting at this
  -- script's object, one of its ancestors, or a named descendant of the object
  -- or its two nearest ancestors. Ambiguous or unmatched objects are left alone.
  local function probeIdentify(obj, levelName)
    local level = probeLower(levelName, "wad_")
    local node = obj
    for depth = 0, 6 do
      if node == nil then break end
      local found
      for _, row in ipairs(probeRows) do
        if row[1] == level then
          local matched = probeChain(node, row)
          if not matched and depth <= 2 then
            local child = probeFind(node, row[5])
            matched = child ~= nil and probeChain(child, row)
          end
          if matched then
            if found ~= nil and found ~= row then return nil, "ambiguous" end
            found = row
          end
        end
      end
      if found ~= nil then return found, depth end
      node = probeParent(node)
    end
    return nil, "unmatched"
  end

  -- The script's own hint distances, as its zone factory and code set them.
  local function probeOriginal()
    return (artifactType == "Lambs Cress" and 5 or 3), 2
  end

  -- Applied on every broadcast: the script may recreate its zone or reset its
  -- hint distance, and zones have no hint getter. Logged only on change.
  local function probeWiden(range)
    local member = probeMember
    local zone = frontInteractZone
    if zone == nil then
      probeError("zone", "interact zone missing")
      return
    end
    local xz, y = probeOriginal()
    if range > 0 then
      xz, y = math.max(xz, range), math.max(y, range)
    end
    local ok, err = pcall(function()
      zone:SetHintXZRange(xz)
      zone:SetHintYRange(y)
    end)
    if not ok then
      probeError("hint", err)
      return
    end
    if member.zone == zone and member.applied == range then return end
    member.zone, member.applied = zone, range
    probeLog("hint " .. member.id .. " family=" .. member.family .. " xz=" .. tostring(xz) ..
      " y=" .. tostring(y) .. " range=" .. tostring(range))
  end

  -- Hint-only zones the probe owns: no interact range, so no button prompt;
  -- enabled while the range is on and the collectible is not collected.
  local probeEntries = {}
  local probeJoints = {"zeroJoint", "promptJointFront", "promptJoint", "synchJoint", "promptJoint_Son", "linkJoint", "root", "Root", "JORoot", "jointRoot", "joint1", "ApproachPoint", "enabledCollision", "disabledCollision", "Pristine", "Broken1", "approachJoint", "gameJoint", "rewardJoint", "syncJoint", "lootObjLocation", "SpawnDirection", "JOPelvis1", "JOBell1"}
  -- This object's own token (a table address in its Lua state), so the map
  -- can grant art to one object even when two objects claim one catalogue row.
  local probeToken = string.match(tostring({}), "(%x+)$") or "0"
  local probeGranted = {}

  local function probeObserved()
    if type(CompletionistCollectibleObserve) ~= "function" then return nil end
    local ok, _, state = pcall(CompletionistCollectibleObserve)
    if ok then return state end
  end

  local function probeList(...)
    return {n = select("#", ...), ...}
  end

  local function probeChild(go)
    if go == nil then return nil end
    local ok, child = pcall(function() return go.Child end)
    if ok then return child end
  end

  local function probeSonHosts()
    local okSon, son = pcall(function() return thisObj:FindSingleGOByName("GenericSonInteract") end)
    if not okSon or son == nil then return thisObj end
    return probeChild(son), son, thisObj
  end

  -- The object, its descendants breadth first (ref-node Child and grouped
  -- Children), then its parent: joints sit on the meshes, not the roots.
  local function probeTree(root)
    local found, queue, head = {}, {root}, 1
    while queue[head] ~= nil and #found < 48 do
      local node = queue[head]
      head = head + 1
      found[#found + 1] = node
      local child = probeChild(node)
      if child ~= nil then queue[#queue + 1] = child end
      local ok, children = pcall(function() return node.Children end)
      if ok and type(children) == "table" then
        for _, item in ipairs(children) do queue[#queue + 1] = item end
      end
    end
    local parent = probeParent(root)
    if parent ~= nil then found[#found + 1] = parent end
    found.n = #found
    return found
  end

  -- Where the zone's joint is in the world, for the log.
  local function probeWhere(host, joint)
    local ok, position = pcall(function() return host:GetWorldJointPosition(host:GetJointIndex(joint)) end)
    if not ok or position == nil then
      ok, position = pcall(function() return host:GetWorldPosition() end)
    end
    if ok and position ~= nil then
      return string.format("%.1f,%.1f,%.1f", position.x, position.y, position.z)
    end
    return "?"
  end

  -- Joint names the engine reports for a host, when it has such calls; the
  -- static puzzle meshes list no joint names in the level data.
  local function probeJointNames(host)
    local names, info = {}, {}
    for _, method in ipairs({"GetJointCount", "GetNumJoints"}) do
      local ok, value = pcall(function() return host[method](host) end)
      if ok and value ~= nil then info[#info + 1] = method .. "=" .. tostring(value) end
    end
    for index = 0, 8 - 1 do
      local ok, value = pcall(function() return host:GetJointName(index) end)
      if ok and type(value) == "string" and value ~= "" then names[#names + 1] = value end
    end
    if #names > 0 then info[#info + 1] = "names=" .. table.concat(names, ",") end
    return names, table.concat(info, " ")
  end

  local function probeCreate(hosts, icon, range)
    local last, tried = "no host", {}
    for index = 1, hosts.n do
      local host = hosts[index]
      if host ~= nil then
        local joints = probeJoints
        local reported, info = probeJointNames(host)
        if #reported > 0 then
          joints = {}
          for _, joint in ipairs(probeJoints) do joints[#joints + 1] = joint end
          for _, joint in ipairs(reported) do joints[#joints + 1] = joint end
        end
        if #tried < 24 then
          tried[#tried + 1] = tostring(probeName(host)) .. (info ~= "" and ("{" .. info .. "}") or "")
        end
        for _, joint in ipairs(joints) do
          local ok, zone = pcall(function() return game.InteractZone.New(host, joint) end)
          if ok and zone ~= nil then
            local okSetup, err = pcall(function()
              zone:SetTemplateValues({
                name = "Completionist Hint",
                interactFrontAngleMax = 360,
                yRangeMax = 0,
                xzRange = 0,
                xzRangeMax = 0,
                hintXZRange = range,
                hintYRange = range,
                onScreenPercentMin = 1,
                onScreenPercentMax = 0.01,
                onScreenPercentWeight = 0,
                cameraFrontAngleMax = 360
              })
              zone:SetTags("NotInCombat")
              zone:SetPromptIconSet({
                normal = "WORLD_INTERACT_LOOT",
                unavailable = "WORLD_INTERACT_UNAVAILABLE_LOOT",
                locked = "WORLD_INTERACT_LOCKED_LOOT",
                hint = icon
              })
            end)
            if not okSetup then return nil, "setup " .. tostring(err) end
            -- Hints show only within this angle of the joint's facing; the
            -- game uses 360 for hints seen from every side (xpl950_beachmaze).
            local okAngle, angleErr = pcall(function() zone:SetHintAngle(360) end)
            if not okAngle then probeError("hint_angle", angleErr) end
            return zone, tostring(probeName(host)) .. "/" .. joint .. " pos=" .. probeWhere(host, joint)
          end
          last = tostring(zone)
        end
      end
    end
    return nil, last .. " tried=" .. table.concat(tried, ",")
  end

  -- art: reports this collectible to the map, which shows its family art as a
  -- compass marker; while it does, the token is granted and dots give way.
  -- dot: a white hint zone where no stock zone is widened.
  local function probeAdd(key, family, hosts, done, dot, token)
    probeEntries[#probeEntries + 1] = {key = key, family = family, kind = "art", hosts = hosts, done = done,
      token = token}
    if dot then
      probeEntries[#probeEntries + 1] = {key = key, family = family, kind = "dot", hosts = hosts, done = done,
        token = token, icon = "WORLD_INTERACT_HINT_LOOT"}
    end
  end

  local function probeBuild()
    probeAdd(probeMember.id, probeMember.family, function() return probeList(probeChild(LootObject), LootObject, thisObj) end,
      function() return probeMember.mapCollected == true or (probeObserved() == "collected") end, false, probeToken)
  end

  -- A zone that is no longer wanted is destroyed, not just disabled.
  local function probeDrop(entry)
    local zone = entry.zone
    entry.zone, entry.applied = nil, nil
    pcall(function() zone:Disable() end)
    local ok = pcall(function() zone:Destroy() end)
    probeLog("zone " .. entry.key .. " kind=" .. entry.kind .. " family=" .. entry.family ..
      " dropped destroyed=" .. tostring(ok))
  end

  local function probeEntry(entry, range)
    local okDone, done = pcall(entry.done)
    local show = range > 0 and not (okDone and done == true) and not probeGranted[entry.token]
    if entry.kind == "art" then
      if entry.zone ~= nil then probeDrop(entry) end
      return
    end
    if entry.zone == nil then
      if not show or (entry.failures or 0) >= 5 then return end
      local okHosts, hosts = pcall(entry.hosts)
      local zone, where = nil, tostring(hosts)
      if okHosts and type(hosts) == "table" then zone, where = probeCreate(hosts, entry.icon, range) end
      if zone == nil then
        entry.failures = (entry.failures or 0) + 1
        probeError("zone " .. entry.key .. " " .. entry.kind, where)
        return
      end
      entry.zone, entry.where = zone, where
    end
    local ok, err = pcall(function()
      if show then
        entry.zone:SetHintXZRange(range)
        entry.zone:SetHintYRange(range)
        entry.zone:Enable()
      else
        entry.zone:Disable()
      end
    end)
    if not ok then
      probeError("hint " .. entry.key .. " " .. entry.kind, err)
      return
    end
    local applied = show and range or 0
    if entry.applied == applied then return end
    entry.applied = applied
    probeLog("zone " .. entry.key .. " kind=" .. entry.kind .. " family=" .. entry.family .. " at=" ..
      tostring(entry.where) .. " shown=" .. tostring(show) .. " range=" .. tostring(range))
  end

  -- Rows the map store holds as collected (what hides their map pins) get no
  -- dots and the stock hint distance. Probe-owned zones wait for the map's
  -- first broadcast, so a collected row never flashes at load.
  local function probeApply(range)
    local member = probeMember
    if member == nil then return end
    if member.mapCollected then range = 0 end
    range = math.min(range, 25)
    if probeWiden ~= nil then probeWiden(probeGranted[probeToken] and 0 or range) end
    if not member.mapSeen then return end
    for _, entry in ipairs(probeEntries) do probeEntry(entry, range) end
  end

  -- Each collectible this object carries tells the map where it is and
  -- whether it is done; the map grants art from these reports.
  local function probeReport()
    local route = engine.GetUIWad()
    for _, entry in ipairs(probeEntries) do
      if entry.kind == "art" then
        local okDone, done = pcall(entry.done)
        local position
        local okHosts, hosts = pcall(entry.hosts)
        if okHosts and type(hosts) == "table" then
          for index = 1, hosts.n do
            if position == nil and hosts[index] ~= nil then
              local ok, value = pcall(function() return hosts[index]:GetWorldPosition() end)
              if ok and value ~= nil then position = value end
            end
          end
        end
        -- This object's own CompletionistCollectibleObserve answer, which the
        -- map cannot read itself (LuaObjectScript is nil from the UI state).
        local observed = "-"
        if entry.key == probeMember.id then
          local seen = probeObserved()
          if seen == "collected" then observed = "c" elseif seen == "remaining" then observed = "r" end
        end
        if position ~= nil then
          engine.SendHook("COMPLETIONIST_PROXIMITY23_REPORT", route, string.format("PROX23R|%s|%s|%s|%.1f|%.1f|%.1f|%d|%s",
            entry.token, entry.key, entry.family, position.x, position.y, position.z,
            (okDone and done == true) and 1 or 0, observed))
        end
      end
    end
  end

  local function probeRangeHook(...)
    for index = 1, select("#", ...) do
      local value = select(index, ...)
      if type(value) == "string" then
        local range, collected, art = string.match(value, "^PROX23|(%d+)|([%d,]*)|([%w,]*)$")
        if range ~= nil then
          local member = probeMember
          if member ~= nil and member.index ~= nil then
            local mapCollected = false
            for number in string.gmatch(collected, "%d+") do
              if tonumber(number) == member.index then mapCollected = true end
            end
            member.mapSeen, member.mapCollected = true, mapCollected
          end
          probeGranted = {}
          for token in string.gmatch(art, "%w+") do probeGranted[token] = true end
          local ok, err = pcall(probeApply, tonumber(range))
          if not ok then probeError("apply", err) end
          local okReport, reportErr = pcall(probeReport)
          if not okReport then probeError("report", reportErr) end
          return
        end
      end
    end
  end

  local function probeStart()
    if probeMember ~= nil then return end
    local row, detail
    if probeFamily ~= nil then
      row, detail = {nil, probeFamily, probeFamily .. ":" .. tostring(probeName(thisObj))}, "script"
    else
      row, detail = probeIdentify(thisObj, thisLevel and thisLevel.Name)
    end
    if row == nil then
      probeLog("unidentified reason=" .. tostring(detail) .. " level=" ..
        tostring(thisLevel and thisLevel.Name) .. " object=" .. tostring(probeName(thisObj)))
      return
    end
    probeMember = {id = row[3], family = row[2], index = row[4], mapSeen = row[4] == nil}
    local okBuild, buildErr = pcall(probeBuild)
    if not okBuild then probeError("build", buildErr) end
    local okThunk, thunk = pcall(require, "core.thunk")
    if okThunk and type(thunk) == "table" and type(thunk.Install) == "function" then
      local okInstall, err = pcall(thunk.Install, "COMPLETIONIST_PROXIMITY23_SHOW", probeRangeHook)
      if not okInstall then probeError("hook", err) end
    else
      probeError("thunk", thunk)
    end
    probeLog("identified id=" .. row[3] .. " family=" .. row[2] .. " depth=" .. tostring(detail))
    probeApply(probeDefaultRange)
  end

  local function probePack(...)
    return {n = select("#", ...), ...}
  end
  local probeOriginalLoaded = OnScriptLoaded
  if type(probeOriginalLoaded) == "function" then
    function OnScriptLoaded(...)
      local results = probePack(probeOriginalLoaded(...))
      local ok, err = pcall(probeStart)
      if not ok then probeError("start", err) end
      return unpack(results, 1, results.n)
    end
  end
end
-- END COMPLETIONIST PROXIMITY V1.1.0
