local LD = require("design.LevelDesignLibrary")
local thisObj, thisLevel
player = nil
local questParent, interactCompleteEvents
local collected = false
local interact
local markerRevealed = false
local overrideReward, isRevealPickup, journalUpdateID
local VariantTable = {
  "VIKING_FUNERAL_REVEAL",
  "MASON_DRAGON_REVEAL",
  "FALLEN_WARRIOR_REVEAL",
  "UB02_REVEAL",
  "UB03_REVEAL",
  "UB04_REVEAL",
  "UB05_REVEAL"
}
local MarkerReveals = {
  VIKING_FUNERAL_REVEAL = "CAL_VF_Entrance",
  MASON_DRAGON_REVEAL = "MTC_Fafnir_Return",
  FALLEN_WARRIOR_REVEAL = "SMLH_UFB_01_Obj01_BBB_Return",
  UB02_REVEAL = "SMLH_UFB_02_Obj02",
  UB03_REVEAL = "BWAT_UFB_03_Obj957_Return",
  UB04_REVEAL = "BC_UFB_04_Obj6356_Return",
  UB05_REVEAL = "BC_USB_05_Obj01_LightBeacon"
}
function OnScriptLoaded(level, obj)
  thisObj = obj
  thisLevel = level
  player = game.Player.FindPlayer()
  questParent = obj:FindLuaTableAttribute("QuestParent")
  if obj:FindLuaTableAttribute("Event_InteractComplete") ~= "" then
    interactCompleteEvents = LD.ExtractCallbacksForEvent(level, obj, obj:FindLuaTableAttribute("Event_InteractComplete"))
  end
  journalUpdateID = thisObj:FindLuaTableAttribute("journalUpdateID")
  local genericSonInteract = obj:FindSingleGOByName("GenericSonInteract")
  if genericSonInteract then
    LD.ForwardUserFunctionToObject(obj, genericSonInteract)
  end
  isRevealPickup = thisObj:FindLuaTableAttribute("IsRevealPickup")
  game.SubObject.Sleep(thisObj)
  SoundInit()
end
function OnStart(level, obj)
  if questParent ~= nil and questParent ~= "" then
    thisObj:SetCharacterConfig("blue")
  else
    thisObj:SetCharacterConfig("red")
  end
  interact = obj:FindSingleGOByName("GenericSonInteract")
  if isRevealPickup then
    local interactObj = interact.IsRefNode and interact.Child or interact
    local interactZone = game.InteractZone.New(interactObj, "synchJoint")
    interactZone:SetPromptIconSet({
      normal = "WORLD_INTERACT_SON_DYNAMIC",
      unavailable = "WORLD_INTERACT_UNAVAILABLE_LOOT",
      locked = "WORLD_INTERACT_LOCKED_LOOT",
      hint = "WORLD_INTERACT_HINT_LOOT"
    })
    interactZone:SetAsSonInteract()
    interact.LuaObjectScript.OverrideInteractZone(interactZone)
  end
  if collected == true then
    thisObj:Hide()
    interact.LuaObjectScript.Disable()
  end
  thisObj:JumpAnimationToFrame(0, {
    Animation = "envGlobPickupExamineScroll"
  })
  thisObj:PauseAnimation()
end
function LuaHook_FireBanter()
  if questParent ~= nil and questParent ~= "" then
    local tMap = {
      game.QuestManager.GetQuestState("Quest_TreasureMap01_Parent"),
      game.QuestManager.GetQuestState("Quest_TreasureMap_ThorStatue_Parent"),
      game.QuestManager.GetQuestState("Quest_TreasureMap_Shipwreck_Parent"),
      game.QuestManager.GetQuestState("Quest_TreasureMap_Oarsmen_Parent"),
      game.QuestManager.GetQuestState("Quest_TreasureMap_VF_Parent"),
      game.QuestManager.GetQuestState("Quest_TreasureMap_Stronghold_Parent"),
      game.QuestManager.GetQuestState("Quest_TreasureMap_ForestDungeon_Parent"),
      game.QuestManager.GetQuestState("Quest_TreasureMap_IslandClimb_Parent"),
      game.QuestManager.GetQuestState("Quest_TreasureMap_ValkyrieArena_Parent"),
      game.QuestManager.GetQuestState("Quest_TreasureMap_BlackBreath_Parent"),
      game.QuestManager.GetQuestState("Quest_TreasureMap_TurtleHouse_Parent"),
      game.QuestManager.GetQuestState("Quest_TreasureMap_IslandArch_Parent")
    }
    local mapQuest
    local allInactive = true
    for _, mapQuest in ipairs(tMap) do
      if mapQuest ~= "Inactive" then
        allInactive = false
      end
    end
    if allInactive == true then
      game.Audio.PlayBanterNonCritical("TreasureMapFirstFound", nil, nil, false)
    else
      game.Audio.PlayBanterNonCritical("Quest_TreasureMap02_Parent_Activate", nil, nil, false)
    end
  elseif journalUpdateID ~= nil and journalUpdateID ~= "" and not IsLibraryScroll() then
    if journalUpdateID ~= "Sindri02_FatherSon_Lore" then
      game.Audio.PlayBanterNonCritical("Scroll_Pickup")
    end
  elseif overrideReward and MarkerReveals[overrideReward] then
    game.Audio.PlayBanterNonCritical("Scroll_Pickup")
  end
end
function LuaHook_RevealMarker()
  if overrideReward and not markerRevealed then
    LD.SetMarkerState(MarkerReveals[overrideReward], 1)
    LD.UpdateMap(MarkerReveals[overrideReward], 2)
    game.Loot.RollCondition(overrideReward, "HERO")
    thisObj:HideParticles()
    markerRevealed = true
  end
end
function LuaHook_PickupScroll()
  PlaySoundOnPickup()
end
function LuaHook_SonReachedScroll()
  local glowFX = thisObj:FindGOsByName("PickUp_Glow*")
  if glowFX then
    for _, fx in pairs(glowFX) do
      LD.HideFX(fx)
    end
  end
end
function UpdateJournal()
  if journalUpdateID ~= nil and journalUpdateID ~= "" then
    journalUpdateID = string.gsub(journalUpdateID, "%s+", "")
    LD.UpdateJournal(journalUpdateID, 5)
  end
  SoftSave()
end
function IsLibraryScroll()
  if journalUpdateID and (journalUpdateID == "AsgardScroll_Lore" or journalUpdateID == "CAL_170_Lore_01" or journalUpdateID == "SerpentScroll_Lore") then
    return true
  else
    return false
  end
end
function AlignInteract()
  local oldForward = thisObj:GetWorldForward()
  local newForward = engine.Vector.New(oldForward.x, 0, oldForward.z):Normalized()
  local physicsLocation = thisObj:GetWorldJointPosition(thisObj:GetJointIndex("zeroJoint"))
  thisObj:HidePhysics()
  thisObj:SetWorldPosition(physicsLocation)
  thisObj:SetWorldFacing(newForward)
end
function OnInteractStart(level, obj, creature)
  interact.LuaObjectScript.OnInteractStart(level, obj, creature)
end
function OnInteractDone(level, obj, creature)
  interact.LuaObjectScript.OnInteractFinish(level, obj, creature)
end
function InteractComplete()
  LuaHook_RevealMarker()
  if questParent ~= "" then
    local questState = game.QuestManager.GetQuestState(questParent)
    if questState == "Inactive" then
      game.QuestManager.StartQuest(questParent)
    end
  else
    UpdateJournal()
    game.Wallets.AddResource("HERO", "EconomyXP", 100, nil, "Scroll")
  end
  if thisObj:FindLuaTableAttribute("Event_InteractComplete") ~= "" then
    LD.ExecuteCallbacksForEvent(thisLevel, thisObj, interactCompleteEvents, "Son Interact Complete")
  end
  if journalUpdateID == "Sindri02_FatherSon_Lore" then
    LD.ActivateQuest("Quest_SecretBusiness02_Parent")
  end
  collected = true
  interact.LuaObjectScript.Disable()
  thisObj:ShowPhysics()
  thisObj:Hide()
  SoftSave()
end
function OverrideInteract()
  return thisObj
end
function OnSaveCheckpoint(level)
  return {collected = collected}
end
function OnRestoreCheckpoint(level, obj, tab)
  collected = tab.collected
end
function SoftSave(level, obj)
  game.SubObject.SoftSave(thisObj)
end
function OverrideReward(level, go, newReward)
  if newReward ~= nil then
    overrideReward = newReward
  end
end
function LuaHook_SpawnLootObject(level, go, variant, spawnedObjectName)
  OverrideReward(level, go, VariantTable[variant])
end
local soundEmitter
local soundEvents = {
  IdleLoop = "SND_LOOT_Shard_Purple_Idle_LP",
  OnPickup = "SND_FOLY_Hand_Small_Grab_Strong"
}
function SoundInit()
  soundEmitter = thisObj.SoundEmitters[1]
  PlaySoundIdleLoop()
end
function PlaySoundIdleLoop()
  LD.PlaySound(soundEmitter, soundEvents.IdleLoop)
end
function StopSoundIdleLoop()
  LD.StopSound(soundEmitter, soundEvents.IdleLoop)
end
function PlaySoundOnPickup()
  LD.PlaySound(soundEmitter, soundEvents.OnPickup)
  StopSoundIdleLoop()
end

-- BEGIN COMPLETIONIST COLLECTIBLE OBSERVATION
do
  function IsCollected()
    return collected
  end
  function CompletionistCollectibleObserve()
    if type(collected) ~= "boolean" then return nil end
    local collected = collected
    return "pickup", collected and "collected" or "remaining"
  end
  local function clearActiveCompassMarker()
    pcall(function()
      if type(game) == "table" and type(game.Compass) == "table" and type(game.Compass.FindMarkersByIconClass) == "function" then
        local markers = game.Compass.FindMarkersByIconClass({"SIDE"})
        if type(markers) == "table" then
          for _, id in ipairs(markers) do
            pcall(game.Compass.HideMarker, id)
          end
        end
      end
    end)
  end
  local function notify()
    if collected then
      clearActiveCompassMarker()
    end
    if thisLevel == nil or type(thisLevel.Name) ~= "string" then return end
    engine.SendHook("COMPLETIONIST_COLLECTIBLE_DIRTY_V1", engine.GetUIWad(),
      "COLLECTIBLE_DIRTY_V1	" .. string.lower(thisLevel.Name))
  end
  local function pack(...) return {n=select('#',...), ...} end
  local unpackValues = unpack or table.unpack
  local function wrap(original)
    return function(...)
      local result = pack(original(...))
      pcall(notify)
      return unpackValues(result, 1, result.n)
    end
  end
  if type(InteractComplete) == "function" then InteractComplete = wrap(InteractComplete) end
  if type(UpdateJournal) == "function" then UpdateJournal = wrap(UpdateJournal) end
  if type(OnStart) == "function" then OnStart = wrap(OnStart) end
  if type(OnRestoreCheckpoint) == "function" then OnRestoreCheckpoint = wrap(OnRestoreCheckpoint) end
end
-- END COMPLETIONIST COLLECTIBLE OBSERVATION
-- BEGIN COMPLETIONIST PROXIMITY V1.1.0
-- Shows the game's native interact hint dot on this collectible out to the
-- map's [Up Arrow] range. Append-only: OnScriptLoaded runs unchanged first;
-- every call below is pcall-guarded.
do
  local probeRows = {
    {"xpl850_dungeonforest", "treasure_map", "treasure_map_b08d1fd606f2ac8a09bf8edc6d5a55b7", 2, "treasuremapinteract_blackbreath"},
    {"xpl910_islandshipwreck", "lore_scroll", "lore_scroll_e8415d73adfe99aa45c8e142856455da", 4, "treasuremapinteract"},
    {"for260_chiseldungeon", "lore_scroll", "lore_scroll_dc56801cbe1e7d3cbd54f9150cc78a3c", 23, "treasuremapinteract"},
    {"peak100_entrance", "lore_scroll", "lore_scroll_62cc5c222fbe7d849e83705cfe13638c", 29, "treasuremapinteract"},
    {"peak790_chimneytopreturn", "treasure_map", "treasure_map_f48eb59997ca3572363316461a106067", 53, "treasuremapinteract_valkarena"},
    {"xpl930_beachruins", "treasure_map", "treasure_map_adf20b36ad0f86b68901b8e49aeeb498", 90, "treasuremapinteract_forestdungeon"},
    {"peak780_summitexit", "lore_scroll", "lore_scroll_0a8de84c5e82fd19ccc618bce5ef6f84", 126, "treasuremapinteract_valkarena"},
    {"xpl970_beachtower", "treasure_map", "treasure_map_aef0891f1c3ee6d1f88f86b1601052f4", 132, "pasted__treasuremapinteract"},
    {"cal270_stonemasonlh", "treasure_map", "treasure_map_4011675d69434ff50662d79d43b08305", 158, "treasuremapinteract_island_climb"},
    {"xpl300_stronghold", "treasure_map", "treasure_map_82e41ccaf3093e62880d64a18227112c", 169, "treasuremapinteract_oarsmen"},
    {"xpl980_beachwaterfall", "treasure_map", "treasure_map_5d8b3d55a299888357a6893fcec99c05", 199, "treasuremapinteract_shipwreck"},
    {"riv925_freyacave", "treasure_map", "treasure_map_3cab9691f053fec1dc02301cf9c04021", 230, "treasuremapinteract_shipwreck"},
    {"xpl450_huldramines", "treasure_map", "treasure_map_ce589a091d984c3581097a8700aad61d", 259, "pasted__treasuremapinteract"},
    {"xpl960_beachship", "treasure_map", "treasure_map_4a07636dc59583c9bfe877849ab5a97f", 313, "treasuremapinteract_islandarch"},
    {"xpl400_huldramines", "treasure_map", "treasure_map_67ec3f2c214e4fd07a7eaf0b58cf213c", 328, "treasuremapinteract"},
    {"riv225_dangerscave", "lore_scroll", "lore_scroll_2242aadeda389dae8c5283057c5326ca", 332, "treasuremapinteract"},
    {"xpl940_beachcave", "treasure_map", "treasure_map_8b1707f94ad818100dd4a5afc67fc6c6", 355, "pasted__treasuremapinteract"},
  }
  local probeFamily = nil
  local probeDefaultRange = 50
  local probeMember = nil
  local probeErrors = {}

  local function probeLog(text)
    print("[CompletionistProximity] " .. text)
  end

  local function probeError(key, err)
    if not probeErrors[key] then
      probeErrors[key] = true
      probeLog("error " .. key .. " " .. tostring(err))
    end
  end

  local function probeLower(value, prefix)
    if type(value) ~= "string" then return nil end
    value = string.lower(value)
    if string.sub(value, 1, #prefix) == prefix then value = string.sub(value, #prefix + 1) end
    return value
  end

  local function probeName(go)
    if go == nil then return nil end
    local ok, name = pcall(function() return go:GetName() end)
    if ok then return probeLower(name, "go") end
  end

  local function probeParent(go)
    if go == nil then return nil end
    local ok, parent = pcall(function() return go.Parent end)
    if ok then return parent end
  end

  local function probeFind(node, name)
    for _, query in ipairs({name, "go" .. name}) do
      local ok, found = pcall(function() return node:FindSingleGOByName(query) end)
      if ok and found ~= nil then return found end
    end
  end

  local function probeChain(node, row)
    local cursor = node
    for index = 5, #row do
      if cursor == nil or probeName(cursor) ~= row[index] then return false end
      cursor = probeParent(cursor)
    end
    return true
  end

  -- Exact catalogue identity: level plus the owner name path, starting at this
  -- script's object, one of its ancestors, or a named descendant of the object
  -- or its two nearest ancestors. Ambiguous or unmatched objects are left alone.
  local function probeIdentify(obj, levelName)
    local level = probeLower(levelName, "wad_")
    local node = obj
    for depth = 0, 6 do
      if node == nil then break end
      local found
      for _, row in ipairs(probeRows) do
        if row[1] == level then
          local matched = probeChain(node, row)
          if not matched and depth <= 2 then
            local child = probeFind(node, row[5])
            matched = child ~= nil and probeChain(child, row)
          end
          if matched then
            if found ~= nil and found ~= row then return nil, "ambiguous" end
            found = row
          end
        end
      end
      if found ~= nil then return found, depth end
      node = probeParent(node)
    end
    return nil, "unmatched"
  end

  local probeWiden = nil

  -- Hint-only zones the probe owns: no interact range, so no button prompt;
  -- enabled while the range is on and the collectible is not collected.
  local probeEntries = {}
  local probeJoints = {"promptJoint_Son", "zeroJoint", "promptJointFront", "promptJoint", "synchJoint", "linkJoint", "root", "Root", "JORoot", "jointRoot", "joint1", "ApproachPoint", "enabledCollision", "disabledCollision", "Pristine", "Broken1", "approachJoint", "gameJoint", "rewardJoint", "syncJoint", "lootObjLocation", "SpawnDirection", "JOPelvis1", "JOBell1"}
  -- This object's own token (a table address in its Lua state), so the map
  -- can grant art to one object even when two objects claim one catalogue row.
  local probeToken = string.match(tostring({}), "(%x+)$") or "0"
  local probeGranted = {}

  local function probeObserved()
    if type(CompletionistCollectibleObserve) ~= "function" then return nil end
    local ok, _, state = pcall(CompletionistCollectibleObserve)
    if ok then return state end
  end

  local function probeList(...)
    return {n = select("#", ...), ...}
  end

  local function probeChild(go)
    if go == nil then return nil end
    local ok, child = pcall(function() return go.Child end)
    if ok then return child end
  end

  local function probeSonHosts()
    local okSon, son = pcall(function() return thisObj:FindSingleGOByName("GenericSonInteract") end)
    if not okSon or son == nil then return thisObj end
    return probeChild(son), son, thisObj
  end

  -- The object, its descendants breadth first (ref-node Child and grouped
  -- Children), then its parent: joints sit on the meshes, not the roots.
  local function probeTree(root)
    local found, queue, head = {}, {root}, 1
    while queue[head] ~= nil and #found < 48 do
      local node = queue[head]
      head = head + 1
      found[#found + 1] = node
      local child = probeChild(node)
      if child ~= nil then queue[#queue + 1] = child end
      local ok, children = pcall(function() return node.Children end)
      if ok and type(children) == "table" then
        for _, item in ipairs(children) do queue[#queue + 1] = item end
      end
    end
    local parent = probeParent(root)
    if parent ~= nil then found[#found + 1] = parent end
    found.n = #found
    return found
  end

  -- Where the zone's joint is in the world, for the log.
  local function probeWhere(host, joint)
    local ok, position = pcall(function() return host:GetWorldJointPosition(host:GetJointIndex(joint)) end)
    if not ok or position == nil then
      ok, position = pcall(function() return host:GetWorldPosition() end)
    end
    if ok and position ~= nil then
      return string.format("%.1f,%.1f,%.1f", position.x, position.y, position.z)
    end
    return "?"
  end

  -- Joint names the engine reports for a host, when it has such calls; the
  -- static puzzle meshes list no joint names in the level data.
  local function probeJointNames(host)
    local names, info = {}, {}
    for _, method in ipairs({"GetJointCount", "GetNumJoints"}) do
      local ok, value = pcall(function() return host[method](host) end)
      if ok and value ~= nil then info[#info + 1] = method .. "=" .. tostring(value) end
    end
    for index = 0, 8 - 1 do
      local ok, value = pcall(function() return host:GetJointName(index) end)
      if ok and type(value) == "string" and value ~= "" then names[#names + 1] = value end
    end
    if #names > 0 then info[#info + 1] = "names=" .. table.concat(names, ",") end
    return names, table.concat(info, " ")
  end

  local function probeCreate(hosts, icon, range)
    local last, tried = "no host", {}
    for index = 1, hosts.n do
      local host = hosts[index]
      if host ~= nil then
        local joints = probeJoints
        local reported, info = probeJointNames(host)
        if #reported > 0 then
          joints = {}
          for _, joint in ipairs(probeJoints) do joints[#joints + 1] = joint end
          for _, joint in ipairs(reported) do joints[#joints + 1] = joint end
        end
        if #tried < 24 then
          tried[#tried + 1] = tostring(probeName(host)) .. (info ~= "" and ("{" .. info .. "}") or "")
        end
        for _, joint in ipairs(joints) do
          local ok, zone = pcall(function() return game.InteractZone.New(host, joint) end)
          if ok and zone ~= nil then
            local okSetup, err = pcall(function()
              zone:SetTemplateValues({
                name = "Completionist Hint",
                interactFrontAngleMax = 360,
                yRangeMax = 0,
                xzRange = 0,
                xzRangeMax = 0,
                hintXZRange = range,
                hintYRange = range,
                onScreenPercentMin = 1,
                onScreenPercentMax = 0.01,
                onScreenPercentWeight = 0,
                cameraFrontAngleMax = 360
              })
              zone:SetTags("NotInCombat")
              zone:SetPromptIconSet({
                normal = "WORLD_INTERACT_LOOT",
                unavailable = "WORLD_INTERACT_UNAVAILABLE_LOOT",
                locked = "WORLD_INTERACT_LOCKED_LOOT",
                hint = icon
              })
            end)
            if not okSetup then return nil, "setup " .. tostring(err) end
            -- Hints show only within this angle of the joint's facing; the
            -- game uses 360 for hints seen from every side (xpl950_beachmaze).
            local okAngle, angleErr = pcall(function() zone:SetHintAngle(360) end)
            if not okAngle then probeError("hint_angle", angleErr) end
            return zone, tostring(probeName(host)) .. "/" .. joint .. " pos=" .. probeWhere(host, joint)
          end
          last = tostring(zone)
        end
      end
    end
    return nil, last .. " tried=" .. table.concat(tried, ",")
  end

  -- art: reports this collectible to the map, which shows its family art as a
  -- compass marker; while it does, the token is granted and dots give way.
  -- dot: a white hint zone where no stock zone is widened.
  local function probeAdd(key, family, hosts, done, dot, token)
    probeEntries[#probeEntries + 1] = {key = key, family = family, kind = "art", hosts = hosts, done = done,
      token = token}
    if dot then
      probeEntries[#probeEntries + 1] = {key = key, family = family, kind = "dot", hosts = hosts, done = done,
        token = token, icon = "WORLD_INTERACT_HINT_LOOT"}
    end
  end

  local function probeBuild()
    probeAdd(probeMember.id, probeMember.family, function() return probeList(probeSonHosts()) end,
      function() return probeMember.mapCollected == true or (probeObserved() == "collected") end, true, probeToken)
  end

  -- A zone that is no longer wanted is destroyed, not just disabled.
  local function probeDrop(entry)
    local zone = entry.zone
    entry.zone, entry.applied = nil, nil
    pcall(function() zone:Disable() end)
    local ok = pcall(function() zone:Destroy() end)
    probeLog("zone " .. entry.key .. " kind=" .. entry.kind .. " family=" .. entry.family ..
      " dropped destroyed=" .. tostring(ok))
  end

  local function probeEntry(entry, range)
    local okDone, done = pcall(entry.done)
    local show = range > 0 and not (okDone and done == true) and not probeGranted[entry.token]
    if entry.kind == "art" then
      if entry.zone ~= nil then probeDrop(entry) end
      return
    end
    if entry.zone == nil then
      if not show or (entry.failures or 0) >= 5 then return end
      local okHosts, hosts = pcall(entry.hosts)
      local zone, where = nil, tostring(hosts)
      if okHosts and type(hosts) == "table" then zone, where = probeCreate(hosts, entry.icon, range) end
      if zone == nil then
        entry.failures = (entry.failures or 0) + 1
        probeError("zone " .. entry.key .. " " .. entry.kind, where)
        return
      end
      entry.zone, entry.where = zone, where
    end
    local ok, err = pcall(function()
      if show then
        entry.zone:SetHintXZRange(range)
        entry.zone:SetHintYRange(range)
        entry.zone:Enable()
      else
        entry.zone:Disable()
      end
    end)
    if not ok then
      probeError("hint " .. entry.key .. " " .. entry.kind, err)
      return
    end
    local applied = show and range or 0
    if entry.applied == applied then return end
    entry.applied = applied
    probeLog("zone " .. entry.key .. " kind=" .. entry.kind .. " family=" .. entry.family .. " at=" ..
      tostring(entry.where) .. " shown=" .. tostring(show) .. " range=" .. tostring(range))
  end

  -- Rows the map store holds as collected (what hides their map pins) get no
  -- dots and the stock hint distance. Probe-owned zones wait for the map's
  -- first broadcast, so a collected row never flashes at load.
  local function probeApply(range)
    local member = probeMember
    if member == nil then return end
    if member.mapCollected then range = 0 end
    range = math.min(range, 25)
    if probeWiden ~= nil then probeWiden(probeGranted[probeToken] and 0 or range) end
    if not member.mapSeen then return end
    for _, entry in ipairs(probeEntries) do probeEntry(entry, range) end
  end

  -- Each collectible this object carries tells the map where it is and
  -- whether it is done; the map grants art from these reports.
  local function probeReport()
    local route = engine.GetUIWad()
    for _, entry in ipairs(probeEntries) do
      if entry.kind == "art" then
        local okDone, done = pcall(entry.done)
        local position
        local okHosts, hosts = pcall(entry.hosts)
        if okHosts and type(hosts) == "table" then
          for index = 1, hosts.n do
            if position == nil and hosts[index] ~= nil then
              local ok, value = pcall(function() return hosts[index]:GetWorldPosition() end)
              if ok and value ~= nil then position = value end
            end
          end
        end
        -- This object's own CompletionistCollectibleObserve answer, which the
        -- map cannot read itself (LuaObjectScript is nil from the UI state).
        local observed = "-"
        if entry.key == probeMember.id then
          local seen = probeObserved()
          if seen == "collected" then observed = "c" elseif seen == "remaining" then observed = "r" end
        end
        if position ~= nil then
          engine.SendHook("COMPLETIONIST_PROXIMITY23_REPORT", route, string.format("PROX23R|%s|%s|%s|%.1f|%.1f|%.1f|%d|%s",
            entry.token, entry.key, entry.family, position.x, position.y, position.z,
            (okDone and done == true) and 1 or 0, observed))
        end
      end
    end
  end

  local function probeRangeHook(...)
    for index = 1, select("#", ...) do
      local value = select(index, ...)
      if type(value) == "string" then
        local range, collected, art = string.match(value, "^PROX23|(%d+)|([%d,]*)|([%w,]*)$")
        if range ~= nil then
          local member = probeMember
          if member ~= nil and member.index ~= nil then
            local mapCollected = false
            for number in string.gmatch(collected, "%d+") do
              if tonumber(number) == member.index then mapCollected = true end
            end
            member.mapSeen, member.mapCollected = true, mapCollected
          end
          probeGranted = {}
          for token in string.gmatch(art, "%w+") do probeGranted[token] = true end
          local ok, err = pcall(probeApply, tonumber(range))
          if not ok then probeError("apply", err) end
          local okReport, reportErr = pcall(probeReport)
          if not okReport then probeError("report", reportErr) end
          return
        end
      end
    end
  end

  local function probeStart()
    if probeMember ~= nil then return end
    local row, detail
    if probeFamily ~= nil then
      row, detail = {nil, probeFamily, probeFamily .. ":" .. tostring(probeName(thisObj))}, "script"
    else
      row, detail = probeIdentify(thisObj, thisLevel and thisLevel.Name)
    end
    if row == nil then
      probeLog("unidentified reason=" .. tostring(detail) .. " level=" ..
        tostring(thisLevel and thisLevel.Name) .. " object=" .. tostring(probeName(thisObj)))
      return
    end
    probeMember = {id = row[3], family = row[2], index = row[4], mapSeen = row[4] == nil}
    local okBuild, buildErr = pcall(probeBuild)
    if not okBuild then probeError("build", buildErr) end
    local okThunk, thunk = pcall(require, "core.thunk")
    if okThunk and type(thunk) == "table" and type(thunk.Install) == "function" then
      local okInstall, err = pcall(thunk.Install, "COMPLETIONIST_PROXIMITY23_SHOW", probeRangeHook)
      if not okInstall then probeError("hook", err) end
    else
      probeError("thunk", thunk)
    end
    probeLog("identified id=" .. row[3] .. " family=" .. row[2] .. " depth=" .. tostring(detail))
    probeApply(probeDefaultRange)
  end

  local function probePack(...)
    return {n = select("#", ...), ...}
  end
  local probeOriginalLoaded = OnScriptLoaded
  if type(probeOriginalLoaded) == "function" then
    function OnScriptLoaded(...)
      local results = probePack(probeOriginalLoaded(...))
      local ok, err = pcall(probeStart)
      if not ok then probeError("start", err) end
      return unpack(results, 1, results.n)
    end
  end
end
-- END COMPLETIONIST PROXIMITY V1.1.0
