local LD = require("design.LevelDesignLibrary")
local player, thisObj, thisLevel, frontInteractZone, startEnabled, questName, LootObject, Sparkle, reward, onInteractEvent, rewardTier, rewardTierIndex, WADName
local rarity = "COMMON"
local useLOSTest, state
local states = {
  ENABLED = 1,
  DISABLED = 2,
  ACQUIRED = 3
}
function OnScriptLoaded(level, go)
  player = game.Player.FindPlayer()
  thisObj = go
  thisLevel = level
  frontInteractZone = LD.CreateInteractZone_Standard_360(go, "promptJointFront")
  LD.EnableInteractZoneGlint(frontInteractZone)
  startEnabled = go:GetLuaTableAttribute("StartEnabled")
  questName = go:GetLuaTableAttribute("QuestName")
  rewardTier = go:FindLuaTableAttribute("RewardTier") or 0
  rewardTierIndex = go:FindLuaTableAttribute("RewardTierIndex") or 0
  WADName = go:FindLuaTableAttribute("WADName") or "TB"
  useLOSTest = go:FindLuaTableAttribute("UseLineOfSightTest")
  if go:FindLuaTableAttribute("Reward") ~= nil then
    reward = go:GetLuaTableAttribute("Reward")
  end
  if go:FindLuaTableAttribute("onInteractEvent") ~= nil then
    onInteractEvent = LD.ExtractCallbacksForEvent(level, go, go:FindLuaTableAttribute("onInteractEvent"))
  end
  LootObject = go.Parent:FindSingleGOByName("LootObject")
  Sparkle = go.Parent:FindSingleGOByName("Sparkle_Icon")
  if startEnabled then
    state = states.ENABLED
  else
    state = states.DISABLED
  end
  game.SubObject.Sleep(go)
  SoundInit()
end
function OnFirstStart(level, go)
  LD.HideFX(LootObject.Child)
end
function OnStart(level, go)
  if questName ~= "" then
    local questState = game.QuestManager.GetQuestState(questName)
    if questState ~= "Complete" then
      game.QuestManager.RegisterListener(go, questName)
    end
    if questState == "Active" then
      state = states.ENABLED
    else
      state = states.DISABLED
    end
  end
  if state == states.ENABLED then
    Enable()
  else
    Disable()
  end
  if useLOSTest == true and state == states.ENABLED then
    frontInteractZone:SetEnableLineOfSightTest(true)
  else
    frontInteractZone:SetEnableLineOfSightTest(false)
  end
end
function OnUseWorld(level, go)
  if frontInteractZone:PlayerCanInteract() then
    LD.SetFacingTowardObject(go, player)
    player:RequestInteract(go, {
      InteractZone = frontInteractZone,
      LerpObject = LootObject.Child
    })
  end
end
function OnInteractStart(level, go, creature)
  state = states.ACQUIRED
  Disable()
  LD.ShowFX(LootObject)
  PlaySoundLootIdle()
  LD.PlaySingleSynchMove_KratosObject(go, "synchJoint", "dirt dig loot", "BRA_PickUpDirt", "", frontInteractZone, false, "Axe")
  CameraApproach()
  game.QuestManager.UnregisterListener(go, questName)
  if go:FindLuaTableAttribute("onInteractEvent") ~= nil then
    LD.ExecuteCallbacksForEvent(level, go, onInteractEvent, "onInteractEvent")
  end
end
function LuaHook_DirtFX(level, obj, creature)
  local spawnFX = game.FX.Spawn("DirtDig_FX", thisLevel, {GameObject = thisObj, AutoDelete = true})
end
function PickUp(level, obj, creature)
  PlaySoundLootPickup()
end
function AwardLoot(level, obj, creature)
  if reward ~= nil then
    if reward == "TyrOffering" then
      game.Wallets.AddResource("HERO", "TyrOffering", 1, "Quest", "Resource")
      if game.Wallets.GetResourceValue("HERO", reward) == 1 then
        if game.Audio.CanBanterConversationPlay("Son_New_Mat_Found") then
          game.Audio.PlayBanterNonCritical("Son_New_Mat_Found", function()
            LD.ActivateQuest("Quest_TyrArmor_Parent")
          end)
        else
          LD.ActivateQuest("Quest_TyrArmor_Parent")
        end
        return
      end
    elseif reward == "Perk_Quest_TyrTalisman" then
      game.Wallets.AddResource("HERO", "Perk_Quest_TyrTalisman", 1, "Quest", "Talisman")
    end
  end
  reward = "MISC_" .. rarity .. "_TIER"
  LD.RollContainerConditionLoot(reward, rewardTier, WADName, rewardTierIndex)
  UpdateQuest()
  LD.CallFunctionAfterDelay(SoftSave, 1)
end
function PutAway(level, obj, creature)
  LootObject:Hide()
end
function UpdateQuest(level, go)
  if questName ~= "" then
    local questState = game.QuestManager.GetQuestState(questName)
    if questState == "Active" then
      game.QuestManager.ProposeQuestState(questName, "Complete")
      game.Audio.PlayBanterNonCritical("treasure_map_found_treasure")
      TrophyCheck()
      if questName == "Quest_TreasureMap01" then
        local uiCalls = require("ui.uicalls")
        uiCalls.UI_Event_SendPlaytestFullscreenMessage("You\226\128\153ve reached a stopping point! Please click the Dead and Bloated survey.", 3, uiCalls.msgParam.ADVANCE_TAP)
      end
    end
  end
end
function TrophyCheck()
  if game.QuestManager.GetQuestState("Quest_TreasureMap01_Parent") == "Complete" and game.QuestManager.GetQuestState("Quest_TreasureMap_ThorStatue_Parent") == "Complete" and game.QuestManager.GetQuestState("Quest_TreasureMap_Shipwreck_Parent") == "Complete" and game.QuestManager.GetQuestState("Quest_TreasureMap_Oarsmen_Parent") == "Complete" and game.QuestManager.GetQuestState("Quest_TreasureMap_VF_Parent") == "Complete" and game.QuestManager.GetQuestState("Quest_TreasureMap_Stronghold_Parent") == "Complete" and game.QuestManager.GetQuestState("Quest_TreasureMap_ForestDungeon_Parent") == "Complete" and game.QuestManager.GetQuestState("Quest_TreasureMap_IslandClimb_Parent") == "Complete" and game.QuestManager.GetQuestState("Quest_TreasureMap_ValkyrieArena_Parent") == "Complete" and game.QuestManager.GetQuestState("Quest_TreasureMap_BlackBreath_Parent") == "Complete" then
    AwardTrophy()
  end
end
function AwardTrophy()
  print("Trophy Awarded: Treasure Hunter")
  game.UnlockTrophy(32)
end
function Handle_Quest_Activate(level, go, questName, parentQuestName)
  if questName ~= "" then
    Enable()
  end
end
function Enable()
  if state ~= states.ACQUIRED then
    state = states.ENABLED
    frontInteractZone:Enable()
    Sparkle:Show()
  end
end
function Disable()
  if state ~= states.ACQUIRED then
    state = states.DISABLED
  end
  Sparkle:Hide()
  LD.HideFX(LootObject.Child)
  frontInteractZone:Disable()
end
function CameraApproach()
  game.Camera.Recenter({
    TimeStart = 0,
    TimeDuration = 2,
    LockRecenter = 1,
    YawRange = -1,
    TriggerLeft = 0,
    TriggerRight = 0,
    ReturnLeft = 0,
    ReturnRight = 0,
    PitchRange = 0,
    ReturnUp = -8,
    ReturnDown = -8
  })
end
function SoftSave(level, go)
  game.SubObject.SoftSave(thisObj)
  print("soft save has occurred")
end
function OnSaveCheckpoint(level)
  return {state = state}
end
function OnRestoreCheckpoint(level, go, tab)
  state = tab.state
end
local soundEmitter
local soundEvents = {
  OnPickUp = "SND_CHR_Kratos_Foley_Item_Pickup_Generic",
  IdleLoop = "SND_LOOT_Shard_White_LP"
}
function SoundInit()
  soundEmitter = LootObject.Child.SoundEmitters[1]
end
function PlaySoundLootIdle()
  print()
  LD.PlaySound(soundEmitter, soundEvents.IdleLoop)
end
function PlaySoundLootPickup()
  LD.PlaySound(player:FindSingleSoundEmitterByName("SNDLeftHand"), soundEvents.OnPickUp)
end

-- BEGIN COMPLETIONIST COLLECTIBLE OBSERVATION
do
  function GetState()
    return state
  end
  function CompletionistCollectibleObserve()
    if type(state) ~= "number" or state < 1 or state > 3 or state ~= math.floor(state) then return nil end
    local collected = state == 3
    if collected then
      if type(questName) ~= "string" or questName == "" then return nil end
      collected = game.QuestManager.GetQuestState(questName) == "Complete"
    end
    return "dig", collected and "collected" or "remaining"
  end
  local function clearActiveCompassMarker()
    pcall(function()
      if type(game) == "table" and type(game.Compass) == "table" and type(game.Compass.FindMarkersByIconClass) == "function" then
        local markers = game.Compass.FindMarkersByIconClass({"SIDE"})
        if type(markers) == "table" then
          for _, id in ipairs(markers) do
            pcall(game.Compass.HideMarker, id)
          end
        end
      end
    end)
  end
  local function notify()
    if state == states.ACQUIRED then
      clearActiveCompassMarker()
    end
    if thisLevel == nil or type(thisLevel.Name) ~= "string" then return end
    engine.SendHook("COMPLETIONIST_COLLECTIBLE_DIRTY_V1", engine.GetUIWad(),
      "COLLECTIBLE_DIRTY_V1	" .. string.lower(thisLevel.Name))
  end
  local function pack(...) return {n=select('#',...), ...} end
  local unpackValues = unpack or table.unpack
  local function wrap(original)
    return function(...)
      local result = pack(original(...))
      pcall(notify)
      return unpackValues(result, 1, result.n)
    end
  end
  if type(UpdateQuest) == "function" then UpdateQuest = wrap(UpdateQuest) end
  if type(AwardLoot) == "function" then AwardLoot = wrap(AwardLoot) end
  if type(OnStart) == "function" then OnStart = wrap(OnStart) end
  if type(OnRestoreCheckpoint) == "function" then OnRestoreCheckpoint = wrap(OnRestoreCheckpoint) end
end
-- END COMPLETIONIST COLLECTIBLE OBSERVATION
-- BEGIN COMPLETIONIST PROXIMITY V1.1.0
-- Shows the game's native interact hint dot on this collectible out to the
-- map's [Up Arrow] range. Append-only: OnScriptLoaded runs unchanged first;
-- every call below is pcall-guarded.
do
  local probeRows = {
    {"xpl910_islandshipwreck", "treasure_dig", "treasure_dig_9680b8bc8eff19d4c84b439b0e5a841b", 39, "treasuredig_boatcpt_tier3_xpl910"},
    {"xpl900_islandarch", "treasure_dig", "treasure_dig_a46f12e366ccfd55f7a945383f1231d0", 51, "treasure_dig_common_tier3_xpl900_1"},
    {"foot500_top", "treasure_dig", "treasure_dig_5f6d01b68cdf70a9815dc6fa7c3a839f", 58, "misc_common_tier2_foot500_1"},
    {"xpl920_islandclimb", "treasure_dig", "treasure_dig_8c965bccff326f509c02f9321af9a223", 123, "misc_common_tier3_xpl920_1"},
    {"xpl625_masontraillh", "treasure_dig", "treasure_dig_70214d5859cc48c2bfddd06fb252a8ba", 134, "treasuredig_oarsmen_tier4_xpl625"},
    {"xpl200_funeral", "treasure_dig", "treasure_dig_33fd783f7b353537d922042c2a967396", 147, "treasuremap_dig_tier2_xpl200_1"},
    {"xpl300_stronghold", "treasure_dig", "treasure_dig_ebcc555c3dc8b13561d8afa2bd4c0ba0", 263, "treasuremap_dig_tier3_xpl300_1"},
    {"xpl850_dungeonforest", "treasure_dig", "treasure_dig_8d79870871fe184c47d369eabbd68f92", 305, "treasure_dig_common_tier2_xpl850_1"},
    {"xpl950_beachmaze", "treasure_dig", "treasure_dig_4a770cc6263ef7c83b7ea0e4130c6c59", 372, "lootdirtpatch"},
    {"xpl600_masontrail", "treasure_dig", "treasure_dig_1004498996e12e1bd865e937caf21f2d", 383, "treasure_dig_tier3_xpl600_1"},
    {"xpl970_beachtower", "treasure_dig", "treasure_dig_4ec60e59f32086918769282570d5b976", 394, "treasuredig_thor_tier3_cal200"},
    {"riv475_freyahouseext", "treasure_dig", "treasure_dig_c49a3435a3361bfb0f23ee7a0cecc202", 395, "treasuremap_dig_tier3_riv475_1"},
  }
  local probeFamily = nil
  local probeDefaultRange = 50
  local probeMember = nil
  local probeErrors = {}

  local function probeLog(text)
    print("[CompletionistProximity] " .. text)
  end

  local function probeError(key, err)
    if not probeErrors[key] then
      probeErrors[key] = true
      probeLog("error " .. key .. " " .. tostring(err))
    end
  end

  local function probeLower(value, prefix)
    if type(value) ~= "string" then return nil end
    value = string.lower(value)
    if string.sub(value, 1, #prefix) == prefix then value = string.sub(value, #prefix + 1) end
    return value
  end

  local function probeName(go)
    if go == nil then return nil end
    local ok, name = pcall(function() return go:GetName() end)
    if ok then return probeLower(name, "go") end
  end

  local function probeParent(go)
    if go == nil then return nil end
    local ok, parent = pcall(function() return go.Parent end)
    if ok then return parent end
  end

  local function probeFind(node, name)
    for _, query in ipairs({name, "go" .. name}) do
      local ok, found = pcall(function() return node:FindSingleGOByName(query) end)
      if ok and found ~= nil then return found end
    end
  end

  local function probeChain(node, row)
    local cursor = node
    for index = 5, #row do
      if cursor == nil or probeName(cursor) ~= row[index] then return false end
      cursor = probeParent(cursor)
    end
    return true
  end

  -- Exact catalogue identity: level plus the owner name path, starting at this
  -- script's object, one of its ancestors, or a named descendant of the object
  -- or its two nearest ancestors. Ambiguous or unmatched objects are left alone.
  local function probeIdentify(obj, levelName)
    local level = probeLower(levelName, "wad_")
    local node = obj
    for depth = 0, 6 do
      if node == nil then break end
      local found
      for _, row in ipairs(probeRows) do
        if row[1] == level then
          local matched = probeChain(node, row)
          if not matched and depth <= 2 then
            local child = probeFind(node, row[5])
            matched = child ~= nil and probeChain(child, row)
          end
          if matched then
            if found ~= nil and found ~= row then return nil, "ambiguous" end
            found = row
          end
        end
      end
      if found ~= nil then return found, depth end
      node = probeParent(node)
    end
    return nil, "unmatched"
  end

  -- The script's own hint distances, as its zone factory and code set them.
  local function probeOriginal()
    return 5, 2
  end

  -- Applied on every broadcast: the script may recreate its zone or reset its
  -- hint distance, and zones have no hint getter. Logged only on change.
  local function probeWiden(range)
    local member = probeMember
    local zone = frontInteractZone
    if zone == nil then
      probeError("zone", "interact zone missing")
      return
    end
    local xz, y = probeOriginal()
    if range > 0 then
      xz, y = math.max(xz, range), math.max(y, range)
    end
    local ok, err = pcall(function()
      zone:SetHintXZRange(xz)
      zone:SetHintYRange(y)
    end)
    if not ok then
      probeError("hint", err)
      return
    end
    if member.zone == zone and member.applied == range then return end
    member.zone, member.applied = zone, range
    probeLog("hint " .. member.id .. " family=" .. member.family .. " xz=" .. tostring(xz) ..
      " y=" .. tostring(y) .. " range=" .. tostring(range))
  end

  -- Hint-only zones the probe owns: no interact range, so no button prompt;
  -- enabled while the range is on and the collectible is not collected.
  local probeEntries = {}
  local probeJoints = {"promptJointFront", "zeroJoint", "promptJoint", "synchJoint", "promptJoint_Son", "linkJoint", "root", "Root", "JORoot", "jointRoot", "joint1", "ApproachPoint", "enabledCollision", "disabledCollision", "Pristine", "Broken1", "approachJoint", "gameJoint", "rewardJoint", "syncJoint", "lootObjLocation", "SpawnDirection", "JOPelvis1", "JOBell1"}
  -- This object's own token (a table address in its Lua state), so the map
  -- can grant art to one object even when two objects claim one catalogue row.
  local probeToken = string.match(tostring({}), "(%x+)$") or "0"
  local probeGranted = {}

  local function probeObserved()
    if type(CompletionistCollectibleObserve) ~= "function" then return nil end
    local ok, _, state = pcall(CompletionistCollectibleObserve)
    if ok then return state end
  end

  local function probeList(...)
    return {n = select("#", ...), ...}
  end

  local function probeChild(go)
    if go == nil then return nil end
    local ok, child = pcall(function() return go.Child end)
    if ok then return child end
  end

  local function probeSonHosts()
    local okSon, son = pcall(function() return thisObj:FindSingleGOByName("GenericSonInteract") end)
    if not okSon or son == nil then return thisObj end
    return probeChild(son), son, thisObj
  end

  -- The object, its descendants breadth first (ref-node Child and grouped
  -- Children), then its parent: joints sit on the meshes, not the roots.
  local function probeTree(root)
    local found, queue, head = {}, {root}, 1
    while queue[head] ~= nil and #found < 48 do
      local node = queue[head]
      head = head + 1
      found[#found + 1] = node
      local child = probeChild(node)
      if child ~= nil then queue[#queue + 1] = child end
      local ok, children = pcall(function() return node.Children end)
      if ok and type(children) == "table" then
        for _, item in ipairs(children) do queue[#queue + 1] = item end
      end
    end
    local parent = probeParent(root)
    if parent ~= nil then found[#found + 1] = parent end
    found.n = #found
    return found
  end

  -- Where the zone's joint is in the world, for the log.
  local function probeWhere(host, joint)
    local ok, position = pcall(function() return host:GetWorldJointPosition(host:GetJointIndex(joint)) end)
    if not ok or position == nil then
      ok, position = pcall(function() return host:GetWorldPosition() end)
    end
    if ok and position ~= nil then
      return string.format("%.1f,%.1f,%.1f", position.x, position.y, position.z)
    end
    return "?"
  end

  -- Joint names the engine reports for a host, when it has such calls; the
  -- static puzzle meshes list no joint names in the level data.
  local function probeJointNames(host)
    local names, info = {}, {}
    for _, method in ipairs({"GetJointCount", "GetNumJoints"}) do
      local ok, value = pcall(function() return host[method](host) end)
      if ok and value ~= nil then info[#info + 1] = method .. "=" .. tostring(value) end
    end
    for index = 0, 8 - 1 do
      local ok, value = pcall(function() return host:GetJointName(index) end)
      if ok and type(value) == "string" and value ~= "" then names[#names + 1] = value end
    end
    if #names > 0 then info[#info + 1] = "names=" .. table.concat(names, ",") end
    return names, table.concat(info, " ")
  end

  local function probeCreate(hosts, icon, range)
    local last, tried = "no host", {}
    for index = 1, hosts.n do
      local host = hosts[index]
      if host ~= nil then
        local joints = probeJoints
        local reported, info = probeJointNames(host)
        if #reported > 0 then
          joints = {}
          for _, joint in ipairs(probeJoints) do joints[#joints + 1] = joint end
          for _, joint in ipairs(reported) do joints[#joints + 1] = joint end
        end
        if #tried < 24 then
          tried[#tried + 1] = tostring(probeName(host)) .. (info ~= "" and ("{" .. info .. "}") or "")
        end
        for _, joint in ipairs(joints) do
          local ok, zone = pcall(function() return game.InteractZone.New(host, joint) end)
          if ok and zone ~= nil then
            local okSetup, err = pcall(function()
              zone:SetTemplateValues({
                name = "Completionist Hint",
                interactFrontAngleMax = 360,
                yRangeMax = 0,
                xzRange = 0,
                xzRangeMax = 0,
                hintXZRange = range,
                hintYRange = range,
                onScreenPercentMin = 1,
                onScreenPercentMax = 0.01,
                onScreenPercentWeight = 0,
                cameraFrontAngleMax = 360
              })
              zone:SetTags("NotInCombat")
              zone:SetPromptIconSet({
                normal = "WORLD_INTERACT_LOOT",
                unavailable = "WORLD_INTERACT_UNAVAILABLE_LOOT",
                locked = "WORLD_INTERACT_LOCKED_LOOT",
                hint = icon
              })
            end)
            if not okSetup then return nil, "setup " .. tostring(err) end
            -- Hints show only within this angle of the joint's facing; the
            -- game uses 360 for hints seen from every side (xpl950_beachmaze).
            local okAngle, angleErr = pcall(function() zone:SetHintAngle(360) end)
            if not okAngle then probeError("hint_angle", angleErr) end
            return zone, tostring(probeName(host)) .. "/" .. joint .. " pos=" .. probeWhere(host, joint)
          end
          last = tostring(zone)
        end
      end
    end
    return nil, last .. " tried=" .. table.concat(tried, ",")
  end

  -- art: reports this collectible to the map, which shows its family art as a
  -- compass marker; while it does, the token is granted and dots give way.
  -- dot: a white hint zone where no stock zone is widened.
  local function probeAdd(key, family, hosts, done, dot, token)
    probeEntries[#probeEntries + 1] = {key = key, family = family, kind = "art", hosts = hosts, done = done,
      token = token}
    if dot then
      probeEntries[#probeEntries + 1] = {key = key, family = family, kind = "dot", hosts = hosts, done = done,
        token = token, icon = "WORLD_INTERACT_HINT_LOOT"}
    end
  end

  local function probeBuild()
    probeAdd(probeMember.id, probeMember.family, function() return probeList(thisObj) end,
      function() return probeMember.mapCollected == true or (probeObserved() == "collected") end, false, probeToken)
  end

  -- A zone that is no longer wanted is destroyed, not just disabled.
  local function probeDrop(entry)
    local zone = entry.zone
    entry.zone, entry.applied = nil, nil
    pcall(function() zone:Disable() end)
    local ok = pcall(function() zone:Destroy() end)
    probeLog("zone " .. entry.key .. " kind=" .. entry.kind .. " family=" .. entry.family ..
      " dropped destroyed=" .. tostring(ok))
  end

  local function probeEntry(entry, range)
    local okDone, done = pcall(entry.done)
    local show = range > 0 and not (okDone and done == true) and not probeGranted[entry.token]
    if entry.kind == "art" then
      if entry.zone ~= nil then probeDrop(entry) end
      return
    end
    if entry.zone == nil then
      if not show or (entry.failures or 0) >= 5 then return end
      local okHosts, hosts = pcall(entry.hosts)
      local zone, where = nil, tostring(hosts)
      if okHosts and type(hosts) == "table" then zone, where = probeCreate(hosts, entry.icon, range) end
      if zone == nil then
        entry.failures = (entry.failures or 0) + 1
        probeError("zone " .. entry.key .. " " .. entry.kind, where)
        return
      end
      entry.zone, entry.where = zone, where
    end
    local ok, err = pcall(function()
      if show then
        entry.zone:SetHintXZRange(range)
        entry.zone:SetHintYRange(range)
        entry.zone:Enable()
      else
        entry.zone:Disable()
      end
    end)
    if not ok then
      probeError("hint " .. entry.key .. " " .. entry.kind, err)
      return
    end
    local applied = show and range or 0
    if entry.applied == applied then return end
    entry.applied = applied
    probeLog("zone " .. entry.key .. " kind=" .. entry.kind .. " family=" .. entry.family .. " at=" ..
      tostring(entry.where) .. " shown=" .. tostring(show) .. " range=" .. tostring(range))
  end

  -- Rows the map store holds as collected (what hides their map pins) get no
  -- dots and the stock hint distance. Probe-owned zones wait for the map's
  -- first broadcast, so a collected row never flashes at load.
  local function probeApply(range)
    local member = probeMember
    if member == nil then return end
    if member.mapCollected then range = 0 end
    range = math.min(range, 25)
    if probeWiden ~= nil then probeWiden(probeGranted[probeToken] and 0 or range) end
    if not member.mapSeen then return end
    for _, entry in ipairs(probeEntries) do probeEntry(entry, range) end
  end

  -- Each collectible this object carries tells the map where it is and
  -- whether it is done; the map grants art from these reports.
  local function probeReport()
    local route = engine.GetUIWad()
    for _, entry in ipairs(probeEntries) do
      if entry.kind == "art" then
        local okDone, done = pcall(entry.done)
        local position
        local okHosts, hosts = pcall(entry.hosts)
        if okHosts and type(hosts) == "table" then
          for index = 1, hosts.n do
            if position == nil and hosts[index] ~= nil then
              local ok, value = pcall(function() return hosts[index]:GetWorldPosition() end)
              if ok and value ~= nil then position = value end
            end
          end
        end
        -- This object's own CompletionistCollectibleObserve answer, which the
        -- map cannot read itself (LuaObjectScript is nil from the UI state).
        local observed = "-"
        if entry.key == probeMember.id then
          local seen = probeObserved()
          if seen == "collected" then observed = "c" elseif seen == "remaining" then observed = "r" end
        end
        if position ~= nil then
          engine.SendHook("COMPLETIONIST_PROXIMITY23_REPORT", route, string.format("PROX23R|%s|%s|%s|%.1f|%.1f|%.1f|%d|%s",
            entry.token, entry.key, entry.family, position.x, position.y, position.z,
            (okDone and done == true) and 1 or 0, observed))
        end
      end
    end
  end

  local function probeRangeHook(...)
    for index = 1, select("#", ...) do
      local value = select(index, ...)
      if type(value) == "string" then
        local range, collected, art = string.match(value, "^PROX23|(%d+)|([%d,]*)|([%w,]*)$")
        if range ~= nil then
          local member = probeMember
          if member ~= nil and member.index ~= nil then
            local mapCollected = false
            for number in string.gmatch(collected, "%d+") do
              if tonumber(number) == member.index then mapCollected = true end
            end
            member.mapSeen, member.mapCollected = true, mapCollected
          end
          probeGranted = {}
          for token in string.gmatch(art, "%w+") do probeGranted[token] = true end
          local ok, err = pcall(probeApply, tonumber(range))
          if not ok then probeError("apply", err) end
          local okReport, reportErr = pcall(probeReport)
          if not okReport then probeError("report", reportErr) end
          return
        end
      end
    end
  end

  local function probeStart()
    if probeMember ~= nil then return end
    local row, detail
    if probeFamily ~= nil then
      row, detail = {nil, probeFamily, probeFamily .. ":" .. tostring(probeName(thisObj))}, "script"
    else
      row, detail = probeIdentify(thisObj, thisLevel and thisLevel.Name)
    end
    if row == nil then
      probeLog("unidentified reason=" .. tostring(detail) .. " level=" ..
        tostring(thisLevel and thisLevel.Name) .. " object=" .. tostring(probeName(thisObj)))
      return
    end
    probeMember = {id = row[3], family = row[2], index = row[4], mapSeen = row[4] == nil}
    local okBuild, buildErr = pcall(probeBuild)
    if not okBuild then probeError("build", buildErr) end
    local okThunk, thunk = pcall(require, "core.thunk")
    if okThunk and type(thunk) == "table" and type(thunk.Install) == "function" then
      local okInstall, err = pcall(thunk.Install, "COMPLETIONIST_PROXIMITY23_SHOW", probeRangeHook)
      if not okInstall then probeError("hook", err) end
    else
      probeError("thunk", thunk)
    end
    probeLog("identified id=" .. row[3] .. " family=" .. row[2] .. " depth=" .. tostring(detail))
    probeApply(probeDefaultRange)
  end

  local function probePack(...)
    return {n = select("#", ...), ...}
  end
  local probeOriginalLoaded = OnScriptLoaded
  if type(probeOriginalLoaded) == "function" then
    function OnScriptLoaded(...)
      local results = probePack(probeOriginalLoaded(...))
      local ok, err = pcall(probeStart)
      if not ok then probeError("start", err) end
      return unpack(results, 1, results.n)
    end
  end
end
-- END COMPLETIONIST PROXIMITY V1.1.0
