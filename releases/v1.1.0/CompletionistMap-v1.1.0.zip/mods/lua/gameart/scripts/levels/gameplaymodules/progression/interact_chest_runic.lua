local LD = require("design.LevelDesignLibrary")
local color = require("core.color")
local TUT = require("game.GlobalTutorials")
local thisLevel, thisObj, keyType, frontInteractZone, chestScript, chestSealsBrokenEvent, interactFunction
local keysUsed = 0
local challengeComplete = false
local runeTable = {}
local onBrokenCallbacks = {}
local isRevealedByLight = false
local isLit = false
local hideRunes = false
local HintBanterEnabled = false
local isDim = false
local debug_runesOn = false
local state
local interactAvailable = true
local states = {
  ENABLED = 1,
  DISABLED = 2,
  LOCKED = 3,
  OPENED = 4
}
function OnScriptLoaded(level, go)
  thisLevel = level
  thisObj = go
  frontInteractZone = LD.CreateInteractZone_Standard_180(go, "promptJointFront")
  frontInteractZone:SetHintXZRange(3)
  frontInteractZone:SetPromptJoint("promptJointLoc")
  LD.OverrideInteractZoneTags(frontInteractZone, "NotWhileSonInteracting", true)
  game.Interact.DisableTags("RunicChest_CustomConditions")
  keyType = go:GetLuaTableAttribute("KeyType")
  isRevealedByLight = go:GetLuaTableAttribute("RevealedByLight")
  hideRunes = go:GetLuaTableAttribute("HideChestSymbols")
  HintBanterEnabled = go:GetLuaTableAttribute("HintBanterEnabled")
  SoundInit()
  chestSealsBrokenEvent = thisObj:FindLuaTableAttribute("chestSealsBrokenEvent")
  if chestSealsBrokenEvent ~= nil then
    chestSealsBrokenEvent = LD.ExtractCallbacksForEvent(thisLevel, thisObj, chestSealsBrokenEvent)
  end
  function onBrokenCallbacks.Key01Broken()
    OnKeyBroken(1)
  end
  function onBrokenCallbacks.Key02Broken()
    OnKeyBroken(2)
  end
  function onBrokenCallbacks.Key03Broken()
    OnKeyBroken(3)
  end
  runeTable[1] = {
    successRune = 17,
    runeVisual = nil,
    baseSuccess = {
      false,
      false,
      false
    },
    lastState = nil,
    runeKey = nil,
    onBreakableDestroyed = nil
  }
  runeTable[2] = {
    successRune = 21,
    runeVisual = nil,
    baseSuccess = {
      false,
      false,
      false
    },
    lastState = nil,
    runeKey = nil,
    onBreakableDestroyed = nil
  }
  runeTable[3] = {
    successRune = 13,
    runeVisual = nil,
    baseSuccess = {
      false,
      false,
      false
    },
    lastState = nil,
    runeKey = nil,
    onBreakableDestroyed = nil
  }
  for i = 1, 3 do
    if keyType == "MemoryChest" then
      runeTable[i].successRune = thisObj:GetLuaTableAttribute("SuccessRune_0" .. tostring(i))
    end
    runeTable[i].runeKey = level:FindSingleGameObject(thisObj:FindLuaTableAttribute("sealBreakable0" .. tostring(i)))
    runeTable[i].runeVisual = thisObj:FindSingleGOByName("keyRune0" .. tostring(i))
    runeTable[i].onBreakableDestroyed = thisObj:FindLuaTableAttribute("Event_Breakable0" .. tostring(i) .. "Destroyed")
    if runeTable[i].onBreakableDestroyed ~= nil then
      runeTable[i].onBreakableDestroyed = LD.ExtractCallbacksForEvent(thisLevel, thisObj, runeTable[i].onBreakableDestroyed)
    end
  end
  chestScript = thisObj:FindSingleGOByName("ChestScript_RN").Child.LuaObjectScript
  game.SubObject.Sleep(go)
end
function OnPreStart(level, obj)
  for i = 1, 3 do
    if runeTable[1].runeKey and runeTable[2].runeKey and runeTable[3].runeKey then
      if keyType == "Breakable" then
        if runeTable[i].runeKey.LuaObjectScript.OnBroken ~= nil then
          runeTable[i].runeKey.LuaObjectScript.OnBroken(onBrokenCallbacks["Key0" .. tostring(i) .. "Broken"])
        end
      elseif keyType == "Bell" then
        runeTable[i].runeKey.LuaObjectScript.RegisterStartRingingCallback(function()
          OnBellStartRinging(runeTable[i].runeVisual, i)
        end)
        runeTable[i].runeKey.LuaObjectScript.RegisterStopRingingCallback(function()
          OnBellCooldownElapsed(runeTable[i].runeVisual, i)
        end)
      elseif keyType == "MemoryChest" then
        runeTable[i].runeKey.LuaObjectScript.RegisterOnRotateCallback(OnRotateCallback)
      end
    end
    runeTable[i].runeVisual.LuaObjectScript.SelectRune(runeTable[i].successRune)
    runeTable[i].lastState = runeTable[i].runeVisual.LuaObjectScript.IsEnabled()
  end
end
function OnFirstStart(level, obj)
  for i = 1, 3 do
    if hideRunes or isRevealedByLight then
      runeTable[i].runeVisual.LuaObjectScript.HideRune()
    end
    if challengeComplete == false then
      runeTable[i].runeVisual.LuaObjectScript.Enable()
    end
  end
end
function OnStart(level, go)
  if state == states.ENABLED then
    Enable()
  elseif state == states.DISABLED then
    Disable()
  elseif state == states.LOCKED then
    Lock()
  elseif state == states.OPENED then
    Disable()
    return
  else
    chestScript.Disable()
    frontInteractZone:Enable()
  end
  if interactAvailable == false then
    DisableInteractBehaviors()
  else
    EnableInteractBehaviors()
  end
  if keyType == "MemoryChest" then
    OnRotateCallback()
  end
end
function OnSaveCheckpoint(level, go)
  return {
    state = state,
    keysUsed = keysUsed,
    challengeComplete = challengeComplete,
    interactAvailable = interactAvailable
  }
end
function OnRestoreCheckpoint(level, go, savedInfo)
  state = savedInfo.state
  keysUsed = savedInfo.keysUsed
  challengeComplete = savedInfo.challengeComplete
  interactAvailable = savedInfo.interactAvailable
end
function OnUseWorld(level, go)
  if frontInteractZone:PlayerCanInteract() then
    PerformKratosInteraction_Locked()
  end
end
function OnInteractStart(level, obj, creature)
  interactFunction()
end
function OnInteractAbort(level, obj, creature)
end
function OnInteractFinish(level, obj, creature)
  state = states.OPENED
end
function OnInteractDone()
end
function PerformKratosInteraction_Locked()
  Lock()
  LD.CallFunctionAfterDelay(function()
    TUT.RunicLock_Tutorial()
  end, 1)
  TripleChestLockedBanter()
  PlayLockMusic()
  PlayLockSound()
end
function Enable()
  if state ~= states.OPENED then
    state = states.ENABLED
    frontInteractZone:Disable()
    chestScript.Enable()
    chestScript.UnlockChest()
  end
end
function Reset()
  keysUsed = 0
  challengeComplete = false
  chestScript.Reset()
  state = nil
  chestScript.Disable()
  frontInteractZone:Enable()
  for i = 1, 3 do
    runeTable[i].runeVisual.LuaObjectScript.Enable()
  end
end
function Disable()
  state = states.DISABLED
  frontInteractZone:Disable()
  chestScript.Disable()
end
function Lock()
  state = states.LOCKED
  frontInteractZone:Disable()
  chestScript.Enable()
  chestScript.LockChest()
end
function GetInteractZone()
  return chestScript.GetInteractZone()
end
function GetFakeInteractZone()
  return frontInteractZone
end
function RunicSoftSave()
  game.SubObject.SoftSave(thisObj)
  if keyType == "MemoryChest" then
    for i = 1, 3 do
      if runeTable[i].runeKey then
        runeTable[i].runeKey.LuaObjectScript.SoftSave()
      end
    end
  end
end
function ResolveRunicSoftSave()
  for i = 1, 3 do
    if runeTable[i].runeKey then
      if keyType == "Breakable" then
        runeTable[i].runeKey:Destroy()
      elseif keyType == "Bell" then
        runeTable[i].runeKey.LuaObjectScript.SoftSaveCleanup()
      elseif keyType == "MemoryChest" then
        runeTable[i].runeKey.LuaObjectScript.ResolveSoftSave()
      end
    end
  end
end
function ForceStateDisabled()
  state = states.DISABLED
end
function HideChest()
  chestScript.HideChest()
  for i = 1, 3 do
    runeTable[i].runeVisual.LuaObjectScript.HideRune()
  end
end
function ShowChest()
  chestScript.ShowChest(state ~= states.ENABLED)
  if state == states.ENABLED then
    chestScript.Enable()
  elseif state == states.LOCKED then
    Lock()
  end
  for i = 1, 3 do
    runeTable[i].runeVisual.LuaObjectScript.ShowRune()
  end
end
function OverrideRuneNumber(i, runeNumber)
  runeTable[i].successRune = runeNumber
  runeTable[i].runeVisual.LuaObjectScript.SelectRune(runeNumber)
  runeTable[i].runeVisual.LuaObjectScript.ShowRune()
  runeTable[i].baseSuccess = {
    false,
    false,
    false
  }
  runeTable[i].lastState = runeTable[i].runeVisual.LuaObjectScript.IsEnabled()
end
function DisableInteractBehaviors()
  interactAvailable = false
  LD.OverrideInteractZoneTags(frontInteractZone, "RunicChest_CustomConditions", true)
  LD.OverrideInteractZoneTags(chestScript.GetInteractZone(), "RunicChest_CustomConditions", true)
end
function EnableInteractBehaviors()
  interactAvailable = true
  LD.OverrideInteractZoneTags(frontInteractZone, "RunicChest_CustomConditions", false)
  LD.OverrideInteractZoneTags(chestScript.GetInteractZone(), "RunicChest_CustomConditions", false)
end
function PlayRuneOnFX(runeID)
  local jointName = "key_FX_Location_0" .. tostring(runeID)
  game.FX.Spawn("FX_Rune_on", nil, {
    AutoDelete = true,
    GameObject = thisObj,
    Joint = jointName
  })
  if keyType ~= "MemoryChest" then
    chestScript.PlaySoundRuneAppear()
  end
end
function PlayRuneOffFX(runeID)
  local jointName = "key_FX_Location_0" .. tostring(runeID)
  game.FX.Spawn("FX_Rune_off", nil, {
    AutoDelete = true,
    GameObject = thisObj,
    Joint = jointName
  })
  if keyType ~= "MemoryChest" then
    chestScript.PlaySoundRuneDisappear()
  end
end
function OnKeyBroken(runeIndex)
  local i = runeIndex
  keysUsed = keysUsed + 1
  PlayRuneOffFX(runeIndex)
  runeTable[i].runeVisual.LuaObjectScript.Disable()
  if keyType == "Breakable" then
    TUT.RunicProgress_Tutorial(keysUsed)
    BreakableBrokenBanter(keysUsed)
  end
  CheckKeys()
  PlayProgressSound()
  PlaySealBrokenMusic()
  if runeTable[i].onBreakableDestroyed ~= nil then
    LD.ExecuteCallbacksForEvent(thisLevel, thisObj, runeTable[i].onBreakableDestroyed, "Brk 0" .. tostring(i) .. " Destroyed")
  end
  if game.Loot.AlertTripleChestBreakableBroken ~= nil then
    game.Loot.AlertTripleChestBreakableBroken(runeIndex)
  end
end
function CheckKeys()
  if keysUsed == 3 then
    challengeComplete = true
    Enable()
    if chestSealsBrokenEvent ~= nil then
      LD.ExecuteCallbacksForEvent(thisLevel, thisObj, chestSealsBrokenEvent, "chestSealsBrokenEvent")
    end
    if keyType == "Breakable" then
      game.Audio.PlaySound("SND_LOOT_Chest_Runic_Puzzle_Complete")
    end
    PlayUnlockMusic()
    PlayUnlockSound()
  end
end
function OnBellStartRinging(runeVisual, runeID)
  runeVisual.LuaObjectScript.Disable()
  keysUsed = keysUsed + 1
  PlayRuneOffFX(runeID)
  if keysUsed == 3 then
    challengeComplete = true
    Enable()
    BellsCompleteBanter()
    if chestSealsBrokenEvent ~= nil then
      LD.ExecuteCallbacksForEvent(thisLevel, thisObj, chestSealsBrokenEvent, "chestSealsBrokenEvent")
    end
    game.Audio.PlaySound("SND_LOOT_Chest_Runic_Puzzle_Complete")
    PlayUnlockSound()
    runeTable[1].runeKey.LuaObjectScript.ChallengeComplete()
    runeTable[2].runeKey.LuaObjectScript.ChallengeComplete()
    runeTable[3].runeKey.LuaObjectScript.ChallengeComplete()
  end
end
function OnBellCooldownElapsed(runeVisual, runeID)
  PlayRuneOnFX(runeID)
  if challengeComplete == false then
    keysUsed = keysUsed - 1
    runeVisual.LuaObjectScript.Enable({delay = 0.75})
  end
end
function OnRotateCallback()
  keysUsed = 0
  if (isRevealedByLight == false or isLit) and challengeComplete == false then
    for i = 1, 3 do
      runeTable[i].baseSuccess[1] = runeTable[i].successRune == runeTable[1].runeKey.LuaObjectScript.GetCurrentRune()
      runeTable[i].baseSuccess[2] = runeTable[i].successRune == runeTable[2].runeKey.LuaObjectScript.GetCurrentRune()
      runeTable[i].baseSuccess[3] = runeTable[i].successRune == runeTable[3].runeKey.LuaObjectScript.GetCurrentRune()
      if runeTable[i].baseSuccess[1] or runeTable[i].baseSuccess[2] or runeTable[i].baseSuccess[3] then
        runeTable[i].runeVisual.LuaObjectScript.Disable()
        keysUsed = keysUsed + 1
        if runeTable[i].lastState ~= runeTable[i].runeVisual.LuaObjectScript.IsEnabled() then
          runeTable[i].lastState = runeTable[i].runeVisual.LuaObjectScript.IsEnabled()
          PlayRuneOffFX(i)
        end
      else
        if runeTable[i].runeVisual.LuaObjectScript.IsEnabled() == false then
          runeTable[i].runeVisual.LuaObjectScript.Enable({delay = 0.75})
        end
        if runeTable[i].lastState ~= runeTable[i].runeVisual.LuaObjectScript.IsEnabled() then
          runeTable[i].lastState = runeTable[i].runeVisual.LuaObjectScript.IsEnabled()
          PlayRuneOnFX(i)
        end
      end
    end
    CheckFlipperRune()
  end
end
function CheckFlipperRune()
  if keysUsed == 3 then
    challengeComplete = true
    Enable()
    if chestSealsBrokenEvent ~= nil then
      LD.ExecuteCallbacksForEvent(thisLevel, thisObj, chestSealsBrokenEvent, "chestSealsBrokenEvent")
    end
  elseif state == states.LOCKED then
    Lock()
  end
end
function LightReveal()
  isLit = true
  for i = 1, 3 do
    runeTable[i].runeVisual.LuaObjectScript.ShowRune()
  end
  if keyType == "MemoryChest" then
    OnRotateCallback()
  end
end
function LightHide()
  isLit = false
  for i = 1, 3 do
    runeTable[i].runeVisual.LuaObjectScript.HideRune()
  end
  if keyType == "MemoryChest" then
    OnRotateCallback()
  end
end
function DimRunes()
  for i = 1, 3 do
    runeTable[i].runeVisual.LuaObjectScript.Dim()
  end
  isDim = true
end
function UndimRunes()
  for i = 1, 3 do
    runeTable[i].runeVisual.LuaObjectScript.Undim()
  end
  isDim = false
end
function DimRunesImmediate()
  for i = 1, 3 do
    runeTable[i].runeVisual.LuaObjectScript.Disable()
    runeTable[i].runeVisual.LuaObjectScript.Dim()
  end
  isDim = true
end
function temp_UnlockKey()
  if keysUsed < 3 then
    keysUsed = keysUsed + 1
  end
  if keysUsed == 1 then
    runeTable[1].runeVisual.LuaObjectScript.Enable()
  elseif keysUsed == 2 then
    runeTable[2].runeVisual.LuaObjectScript.Enable()
  elseif keysUsed == 3 then
    runeTable[3].runeVisual.LuaObjectScript.Enable()
    challengeComplete = true
    Enable()
    if chestSealsBrokenEvent ~= nil then
      LD.ExecuteCallbacksForEvent(thisLevel, thisObj, chestSealsBrokenEvent, "chestSealsBrokenEvent")
    end
  end
end
function temp_LockKey()
  if challengeComplete == false then
    if 0 < keysUsed then
      keysUsed = keysUsed - 1
    end
    if keysUsed == 0 then
      runeTable[1].runeVisual.LuaObjectScript.Disable()
    elseif keysUsed == 1 then
      runeTable[2].runeVisual.LuaObjectScript.Disable()
    elseif keysUsed == 2 then
      runeTable[3].runeVisual.LuaObjectScript.Disable()
    end
  end
end
function TripleChestLockedBanter()
  if HintBanterEnabled then
    game.Audio.PlayBanterNonCritical("ca_triple_chest_notice")
  end
end
function BreakableBrokenBanter(numBroken)
  if HintBanterEnabled then
    if numBroken == 1 then
      game.Audio.PlayBanterNonCritical("ca_triple_chest_1_down")
    elseif numBroken == 2 then
      game.Audio.PlayBanterNonCritical("ca_triple_chest_2_down")
    elseif numBroken == 3 then
      game.Audio.PlayBanterNonCritical("ca_triple_chest_3_down")
    end
  end
end
function BellsCompleteBanter()
  if HintBanterEnabled then
    game.Audio.PlayBanterNonCritical("ca_triple_chest_complete")
  end
end
local musicEvents = {
  OpenedMusic = "",
  LockMusic = "",
  UnlockMusic = "",
  SealBrokenMusic = ""
}
function MusicSetup(sounds)
  if sounds ~= nil then
    for k, v in pairs(musicEvents) do
      for i, j in pairs(sounds) do
        if i == k and j ~= nil and j ~= "" then
          musicEvents[k] = j
        end
      end
      LD.SoundDebug(tostring(k) .. ": " .. tostring(v))
    end
  end
end
function PlayMusic(music)
  if music ~= "" and music ~= nil then
    game.Audio.StartMusic(music)
  else
    print(tostring(music) .. " is either empty or nil")
  end
end
function PlayOpenedMusic()
  PlayMusic(musicEvents.OpenedMusic)
end
function PlayLockMusic()
  PlayMusic(musicEvents.LockMusic)
end
function PlayUnlockMusic()
  PlayMusic(musicEvents.UnlockMusic)
end
function PlaySealBrokenMusic()
  PlayMusic(musicEvents.SealBrokenMusic)
end
local soundEmitter, soundEmitterName, soundEventUnlock, soundEventProgress, soundEventLock
function SoundInit()
  soundEmitterName = thisObj:FindLuaTableAttribute("soundEmitterName")
  if soundEmitterName ~= nil and soundEmitterName ~= "" then
    soundEmitter = thisObj:FindSingleSoundEmitterByName(soundEmitterName)
  end
  musicEvents.LockMusic = thisObj:FindLuaTableAttribute("soundEventLockMusic")
  musicEvents.OpenedMusic = thisObj:FindLuaTableAttribute("soundEventOpenedMusic")
  musicEvents.SealBrokenMusic = thisObj:FindLuaTableAttribute("soundEventSealBrokenMusic")
  musicEvents.UnlockMusic = thisObj:FindLuaTableAttribute("soundEventUnlockMusic")
  soundEventUnlock = thisObj:FindLuaTableAttribute("soundEventUnlock")
  soundEventLock = thisObj:FindLuaTableAttribute("soundEventLock")
  soundEventProgress = thisObj:FindLuaTableAttribute("soundEventProgress")
end
function PlaySound(snd)
  if soundEmitter ~= nil then
    soundEmitter:Start(snd)
  else
    print(tostring(soundEmitter) .. " is nil")
  end
end
function StopSound(snd)
  if soundEmitter ~= nil then
    soundEmitter:Stop(snd)
  else
    print(tostring(soundEmitter) .. " is nil")
  end
end
function PlayUnlockSound()
  PlaySound(soundEventUnlock)
end
function PlayLockSound()
  PlaySound(soundEventLock)
end
function PlayProgressSound()
  PlaySound(soundEventProgress)
end
function Debug_ToggleRunes()
  debug_runesOn = not debug_runesOn
  if debug_runesOn then
    for i = 1, 3 do
      runeTable[i].runeVisual.LuaObjectScript.Enable()
    end
  else
    for i = 1, 3 do
      runeTable[i].runeVisual.LuaObjectScript.Disable()
    end
  end
end
function ShowDebugText()
  local debugText = "IsDim: " .. tostring(isDim)
  for i = 1, 3 do
    debugText = debugText .. [[

 SucessRune[]] .. tostring(i) .. "] = " .. tostring(runeTable[i].successRune) .. " Match: [ " .. tostring(runeTable[i].baseSuccess[1]) .. ", " .. tostring(runeTable[i].baseSuccess[2]) .. ", " .. tostring(runeTable[i].baseSuccess[3]) .. " ]"
  end
  debugText = debugText .. " KeysUsed " .. keysUsed
  engine.DrawTextInWorld(thisObj:GetWorldPosition(), debugText, color.white)
end

-- Observe stock runic chest. Only real locked use reveals its children.
do
  local attempted = false
  local hook = "COMPLETIONIST_NORNIR_EVENT_V1"

  local function identity()
    if thisLevel == nil or thisObj == nil or type(thisLevel.Name) ~= "string" then
      return nil
    end
    local refs = {}
    for index = 1, 3 do
      local ref = thisObj:FindLuaTableAttribute("sealBreakable0" .. tostring(index))
      if type(ref) ~= "string" or ref == "" or string.find(ref, "|", 1, true) then
        return nil
      end
      refs[index] = string.lower(ref)
    end
    table.sort(refs)
    return string.lower(thisLevel.Name) .. "|" .. table.concat(refs, "|")
  end

  local function publish(action, reference)
    local key = identity()
    if key == nil then return end
    local payload = "NORNIR_V1\t" .. action .. "\t" .. key .. "\t" ..
      string.lower(reference or "")
    local ok = pcall(function()
      engine.SendHook(hook, engine.GetUIWad(), payload)
    end)
    print("[CompletionistMapV105Nornir] event=" .. action ..
      " key=" .. key .. " delivered=" .. tostring(ok))
  end

  local stockLocked = PerformKratosInteraction_Locked
  function PerformKratosInteraction_Locked(...)
    local locked = interactAvailable == true and
      challengeComplete ~= true and state ~= states.OPENED
    local result = stockLocked(...)
    if locked then
      attempted = true
      publish("attempt")
    end
    return result
  end

  local stockBroken = OnKeyBroken
  function OnKeyBroken(index, ...)
    local result = stockBroken(index, ...)
    if keyType == "Breakable" and type(index) == "number" and
        index >= 1 and index <= 3 then
      local ref = thisObj:FindLuaTableAttribute("sealBreakable0" .. tostring(index))
      if type(ref) == "string" then publish("seal", ref) end
    end
    return result
  end

  local stockFinish = OnInteractFinish
  function OnInteractFinish(...)
    local result = stockFinish(...)
    if state == states.OPENED then publish("opened") end
    return result
  end

  local stockSave = OnSaveCheckpoint
  function OnSaveCheckpoint(...)
    local saved = stockSave(...)
    if type(saved) == "table" then
      saved.completionistPuzzleAttempted = attempted
    end
    return saved
  end

  local stockRestore = OnRestoreCheckpoint
  function OnRestoreCheckpoint(level, go, saved)
    local result = stockRestore(level, go, saved)
    attempted = type(saved) == "table" and
      saved.completionistPuzzleAttempted == true
    return result
  end

  local stockStart = OnStart
  function OnStart(...)
    local wasOpened = state == states.OPENED
    local result = stockStart(...)
    local rewardOpened = false
    if chestScript ~= nil then
      local ok, value = pcall(function() return chestScript.GetState() end)
      rewardOpened = ok and value == states.OPENED
    end
    if wasOpened or rewardOpened then
      publish("opened")
    elseif attempted then
      publish("attempt")
    end
    if keyType == "Breakable" and type(keysUsed) == "number" then
      local disabled = 0
      local known = true
      local resolved = {}
      for index = 1, 3 do
        local rune = runeTable[index]
        local ok, enabled = pcall(function()
          return rune.runeVisual.LuaObjectScript.IsEnabled()
        end)
        if not ok or type(enabled) ~= "boolean" then
          known = false
          break
        end
        if not enabled then
          disabled = disabled + 1
          resolved[#resolved + 1] = index
        end
      end
      if known and disabled == keysUsed then
        for _, index in ipairs(resolved) do
          local ref = thisObj:FindLuaTableAttribute(
            "sealBreakable0" .. tostring(index))
          if type(ref) == "string" then publish("seal", ref) end
        end
      end
    end
    return result
  end
end

-- Read live rune state. Check all three refs and parent count first.
do
  function CompletionistNornirObserveSeals()
    if keyType ~= "Breakable" or type(keysUsed) ~= "number" or
        keysUsed < 0 or keysUsed > 3 then return nil end
    local entries, broken = {}, 0
    for index = 1, 3 do
      local ref = thisObj:FindLuaTableAttribute(
        "sealBreakable0" .. tostring(index))
      local rune = runeTable[index]
      if type(ref) ~= "string" or ref == "" or
          string.find(ref, "|", 1, true) or rune == nil or
          rune.runeVisual == nil or
          thisObj:FindSingleGOByName("keyRune0" .. tostring(index)) ~=
          rune.runeVisual then return nil end
      local ok, enabled = pcall(function()
        return rune.runeVisual.LuaObjectScript.IsEnabled()
      end)
      if not ok or type(enabled) ~= "boolean" then return nil end
      entries[index] = {reference = string.lower(ref), broken = not enabled}
      if not enabled then broken = broken + 1 end
    end
    if broken ~= keysUsed then return nil end
    return entries
  end
end

-- Send all three rune flags after load and after each broken seal.
do
  local function publishSnapshot()
    if thisLevel == nil or thisObj == nil or
        type(thisLevel.Name) ~= "string" then return end
    local observed = CompletionistNornirObserveSeals()
    if type(observed) ~= "table" or #observed ~= 3 then return end
    local byRef, refs = {}, {}
    for _, entry in ipairs(observed) do
      local ref = entry.reference
      if type(ref) ~= "string" or ref == "" or
          string.find(ref, "|", 1, true) or
          byRef[ref] ~= nil or type(entry.broken) ~= "boolean" then return end
      byRef[ref] = entry.broken
      refs[#refs + 1] = ref
    end
    table.sort(refs)
    local bits = {}
    for index, ref in ipairs(refs) do
      bits[index] = byRef[ref] and "1" or "0"
    end
    local key = string.lower(thisLevel.Name) .. "|" ..
      table.concat(refs, "|")
    local payload = "NORNIR_V1\tsnapshot\t" .. key .. "\t" ..
      table.concat(bits)
    local ok = pcall(function()
      engine.SendHook("COMPLETIONIST_NORNIR_EVENT_V1",
        engine.GetUIWad(), payload)
    end)
    print("[CompletionistMapV105Nornir] event=snapshot key=" .. key ..
      " bits=" .. table.concat(bits) .. " delivered=" .. tostring(ok))
  end

  local start = OnStart
  function OnStart(...)
    local result = start(...)
    publishSnapshot()
    return result
  end

  local broken = OnKeyBroken
  function OnKeyBroken(...)
    local result = broken(...)
    publishSnapshot()
    return result
  end
end

-- BEGIN COMPLETIONIST PROXIMITY V1.1.0
-- Shows the game's native interact hint dot on this collectible out to the
-- map's [Up Arrow] range. Append-only: OnScriptLoaded runs unchanged first;
-- every call below is pcall-guarded.
do
  local probeRows = {

  }
  local probeFamily = "nornir_chest"
  local probeDefaultRange = 50
  local probeMember = nil
  local probeErrors = {}

  local function probeLog(text)
    print("[CompletionistProximity] " .. text)
  end

  local function probeError(key, err)
    if not probeErrors[key] then
      probeErrors[key] = true
      probeLog("error " .. key .. " " .. tostring(err))
    end
  end

  local function probeLower(value, prefix)
    if type(value) ~= "string" then return nil end
    value = string.lower(value)
    if string.sub(value, 1, #prefix) == prefix then value = string.sub(value, #prefix + 1) end
    return value
  end

  local function probeName(go)
    if go == nil then return nil end
    local ok, name = pcall(function() return go:GetName() end)
    if ok then return probeLower(name, "go") end
  end

  local function probeParent(go)
    if go == nil then return nil end
    local ok, parent = pcall(function() return go.Parent end)
    if ok then return parent end
  end

  local function probeFind(node, name)
    for _, query in ipairs({name, "go" .. name}) do
      local ok, found = pcall(function() return node:FindSingleGOByName(query) end)
      if ok and found ~= nil then return found end
    end
  end

  local function probeChain(node, row)
    local cursor = node
    for index = 5, #row do
      if cursor == nil or probeName(cursor) ~= row[index] then return false end
      cursor = probeParent(cursor)
    end
    return true
  end

  -- Exact catalogue identity: level plus the owner name path, starting at this
  -- script's object, one of its ancestors, or a named descendant of the object
  -- or its two nearest ancestors. Ambiguous or unmatched objects are left alone.
  local function probeIdentify(obj, levelName)
    local level = probeLower(levelName, "wad_")
    local node = obj
    for depth = 0, 6 do
      if node == nil then break end
      local found
      for _, row in ipairs(probeRows) do
        if row[1] == level then
          local matched = probeChain(node, row)
          if not matched and depth <= 2 then
            local child = probeFind(node, row[5])
            matched = child ~= nil and probeChain(child, row)
          end
          if matched then
            if found ~= nil and found ~= row then return nil, "ambiguous" end
            found = row
          end
        end
      end
      if found ~= nil then return found, depth end
      node = probeParent(node)
    end
    return nil, "unmatched"
  end

  -- The script's own hint distances, as its zone factory and code set them.
  local function probeOriginal()
    return 3, 2
  end

  -- Applied on every broadcast: the script may recreate its zone or reset its
  -- hint distance, and zones have no hint getter. Logged only on change.
  local function probeWiden(range)
    local member = probeMember
    local zone = frontInteractZone
    if zone == nil then
      probeError("zone", "interact zone missing")
      return
    end
    local xz, y = probeOriginal()
    if range > 0 then
      xz, y = math.max(xz, range), math.max(y, range)
    end
    local ok, err = pcall(function()
      zone:SetHintXZRange(xz)
      zone:SetHintYRange(y)
    end)
    if not ok then
      probeError("hint", err)
      return
    end
    if member.zone == zone and member.applied == range then return end
    member.zone, member.applied = zone, range
    probeLog("hint " .. member.id .. " family=" .. member.family .. " xz=" .. tostring(xz) ..
      " y=" .. tostring(y) .. " range=" .. tostring(range))
  end

  -- Hint-only zones the probe owns: no interact range, so no button prompt;
  -- enabled while the range is on and the collectible is not collected.
  local probeEntries = {}
  local probeJoints = {"promptJointFront", "zeroJoint", "promptJoint", "synchJoint", "promptJoint_Son", "linkJoint", "root", "Root", "JORoot", "jointRoot", "joint1", "ApproachPoint", "enabledCollision", "disabledCollision", "Pristine", "Broken1", "approachJoint", "gameJoint", "rewardJoint", "syncJoint", "lootObjLocation", "SpawnDirection", "JOPelvis1", "JOBell1"}
  -- This object's own token (a table address in its Lua state), so the map
  -- can grant art to one object even when two objects claim one catalogue row.
  local probeToken = string.match(tostring({}), "(%x+)$") or "0"
  local probeGranted = {}

  local function probeObserved()
    if type(CompletionistCollectibleObserve) ~= "function" then return nil end
    local ok, _, state = pcall(CompletionistCollectibleObserve)
    if ok then return state end
  end

  local function probeList(...)
    return {n = select("#", ...), ...}
  end

  local function probeChild(go)
    if go == nil then return nil end
    local ok, child = pcall(function() return go.Child end)
    if ok then return child end
  end

  local function probeSonHosts()
    local okSon, son = pcall(function() return thisObj:FindSingleGOByName("GenericSonInteract") end)
    if not okSon or son == nil then return thisObj end
    return probeChild(son), son, thisObj
  end

  -- The object, its descendants breadth first (ref-node Child and grouped
  -- Children), then its parent: joints sit on the meshes, not the roots.
  local function probeTree(root)
    local found, queue, head = {}, {root}, 1
    while queue[head] ~= nil and #found < 48 do
      local node = queue[head]
      head = head + 1
      found[#found + 1] = node
      local child = probeChild(node)
      if child ~= nil then queue[#queue + 1] = child end
      local ok, children = pcall(function() return node.Children end)
      if ok and type(children) == "table" then
        for _, item in ipairs(children) do queue[#queue + 1] = item end
      end
    end
    local parent = probeParent(root)
    if parent ~= nil then found[#found + 1] = parent end
    found.n = #found
    return found
  end

  -- Where the zone's joint is in the world, for the log.
  local function probeWhere(host, joint)
    local ok, position = pcall(function() return host:GetWorldJointPosition(host:GetJointIndex(joint)) end)
    if not ok or position == nil then
      ok, position = pcall(function() return host:GetWorldPosition() end)
    end
    if ok and position ~= nil then
      return string.format("%.1f,%.1f,%.1f", position.x, position.y, position.z)
    end
    return "?"
  end

  -- Joint names the engine reports for a host, when it has such calls; the
  -- static puzzle meshes list no joint names in the level data.
  local function probeJointNames(host)
    local names, info = {}, {}
    for _, method in ipairs({"GetJointCount", "GetNumJoints"}) do
      local ok, value = pcall(function() return host[method](host) end)
      if ok and value ~= nil then info[#info + 1] = method .. "=" .. tostring(value) end
    end
    for index = 0, 8 - 1 do
      local ok, value = pcall(function() return host:GetJointName(index) end)
      if ok and type(value) == "string" and value ~= "" then names[#names + 1] = value end
    end
    if #names > 0 then info[#info + 1] = "names=" .. table.concat(names, ",") end
    return names, table.concat(info, " ")
  end

  local function probeCreate(hosts, icon, range)
    local last, tried = "no host", {}
    for index = 1, hosts.n do
      local host = hosts[index]
      if host ~= nil then
        local joints = probeJoints
        local reported, info = probeJointNames(host)
        if #reported > 0 then
          joints = {}
          for _, joint in ipairs(probeJoints) do joints[#joints + 1] = joint end
          for _, joint in ipairs(reported) do joints[#joints + 1] = joint end
        end
        if #tried < 24 then
          tried[#tried + 1] = tostring(probeName(host)) .. (info ~= "" and ("{" .. info .. "}") or "")
        end
        for _, joint in ipairs(joints) do
          local ok, zone = pcall(function() return game.InteractZone.New(host, joint) end)
          if ok and zone ~= nil then
            local okSetup, err = pcall(function()
              zone:SetTemplateValues({
                name = "Completionist Hint",
                interactFrontAngleMax = 360,
                yRangeMax = 0,
                xzRange = 0,
                xzRangeMax = 0,
                hintXZRange = range,
                hintYRange = range,
                onScreenPercentMin = 1,
                onScreenPercentMax = 0.01,
                onScreenPercentWeight = 0,
                cameraFrontAngleMax = 360
              })
              zone:SetTags("NotInCombat")
              zone:SetPromptIconSet({
                normal = "WORLD_INTERACT_LOOT",
                unavailable = "WORLD_INTERACT_UNAVAILABLE_LOOT",
                locked = "WORLD_INTERACT_LOCKED_LOOT",
                hint = icon
              })
            end)
            if not okSetup then return nil, "setup " .. tostring(err) end
            -- Hints show only within this angle of the joint's facing; the
            -- game uses 360 for hints seen from every side (xpl950_beachmaze).
            local okAngle, angleErr = pcall(function() zone:SetHintAngle(360) end)
            if not okAngle then probeError("hint_angle", angleErr) end
            return zone, tostring(probeName(host)) .. "/" .. joint .. " pos=" .. probeWhere(host, joint)
          end
          last = tostring(zone)
        end
      end
    end
    return nil, last .. " tried=" .. table.concat(tried, ",")
  end

  -- art: reports this collectible to the map, which shows its family art as a
  -- compass marker; while it does, the token is granted and dots give way.
  -- dot: a white hint zone where no stock zone is widened.
  local function probeAdd(key, family, hosts, done, dot, token)
    probeEntries[#probeEntries + 1] = {key = key, family = family, kind = "art", hosts = hosts, done = done,
      token = token}
    if dot then
      probeEntries[#probeEntries + 1] = {key = key, family = family, kind = "dot", hosts = hosts, done = done,
        token = token, icon = "WORLD_INTERACT_HINT_LOOT"}
    end
  end

  local function probeBuild()
    probeAdd(probeMember.id, probeMember.family, function() return probeList(thisObj) end,
      function() return probeMember.mapCollected == true or (state == states.OPENED) end, false, probeToken)
    -- The chest's Nornir puzzle objects, found by the chest script at load.
    local keyFamily = ({Bell = "nornir_bell", Breakable = "nornir_seal", MemoryChest = "nornir_mechanism"})[keyType]
    if keyFamily ~= nil then
      for index = 1, 3 do
        probeAdd(probeMember.id .. ":key" .. index, keyFamily, function()
          local key = runeTable[index] and runeTable[index].runeKey
          return probeTree(key)
        end, function() return challengeComplete == true or state == states.OPENED end, true,
        probeToken .. "k" .. index)
      end
    end
  end

  -- A zone that is no longer wanted is destroyed, not just disabled.
  local function probeDrop(entry)
    local zone = entry.zone
    entry.zone, entry.applied = nil, nil
    pcall(function() zone:Disable() end)
    local ok = pcall(function() zone:Destroy() end)
    probeLog("zone " .. entry.key .. " kind=" .. entry.kind .. " family=" .. entry.family ..
      " dropped destroyed=" .. tostring(ok))
  end

  local function probeEntry(entry, range)
    local okDone, done = pcall(entry.done)
    local show = range > 0 and not (okDone and done == true) and not probeGranted[entry.token]
    if entry.kind == "art" then
      if entry.zone ~= nil then probeDrop(entry) end
      return
    end
    if entry.zone == nil then
      if not show or (entry.failures or 0) >= 5 then return end
      local okHosts, hosts = pcall(entry.hosts)
      local zone, where = nil, tostring(hosts)
      if okHosts and type(hosts) == "table" then zone, where = probeCreate(hosts, entry.icon, range) end
      if zone == nil then
        entry.failures = (entry.failures or 0) + 1
        probeError("zone " .. entry.key .. " " .. entry.kind, where)
        return
      end
      entry.zone, entry.where = zone, where
    end
    local ok, err = pcall(function()
      if show then
        entry.zone:SetHintXZRange(range)
        entry.zone:SetHintYRange(range)
        entry.zone:Enable()
      else
        entry.zone:Disable()
      end
    end)
    if not ok then
      probeError("hint " .. entry.key .. " " .. entry.kind, err)
      return
    end
    local applied = show and range or 0
    if entry.applied == applied then return end
    entry.applied = applied
    probeLog("zone " .. entry.key .. " kind=" .. entry.kind .. " family=" .. entry.family .. " at=" ..
      tostring(entry.where) .. " shown=" .. tostring(show) .. " range=" .. tostring(range))
  end

  -- Rows the map store holds as collected (what hides their map pins) get no
  -- dots and the stock hint distance. Probe-owned zones wait for the map's
  -- first broadcast, so a collected row never flashes at load.
  local function probeApply(range)
    local member = probeMember
    if member == nil then return end
    if member.mapCollected then range = 0 end
    range = math.min(range, 25)
    if probeWiden ~= nil then probeWiden(probeGranted[probeToken] and 0 or range) end
    if not member.mapSeen then return end
    for _, entry in ipairs(probeEntries) do probeEntry(entry, range) end
  end

  -- Each collectible this object carries tells the map where it is and
  -- whether it is done; the map grants art from these reports.
  local function probeReport()
    local route = engine.GetUIWad()
    for _, entry in ipairs(probeEntries) do
      if entry.kind == "art" then
        local okDone, done = pcall(entry.done)
        local position
        local okHosts, hosts = pcall(entry.hosts)
        if okHosts and type(hosts) == "table" then
          for index = 1, hosts.n do
            if position == nil and hosts[index] ~= nil then
              local ok, value = pcall(function() return hosts[index]:GetWorldPosition() end)
              if ok and value ~= nil then position = value end
            end
          end
        end
        -- This object's own CompletionistCollectibleObserve answer, which the
        -- map cannot read itself (LuaObjectScript is nil from the UI state).
        local observed = "-"
        if entry.key == probeMember.id then
          local seen = probeObserved()
          if seen == "collected" then observed = "c" elseif seen == "remaining" then observed = "r" end
        end
        if position ~= nil then
          engine.SendHook("COMPLETIONIST_PROXIMITY23_REPORT", route, string.format("PROX23R|%s|%s|%s|%.1f|%.1f|%.1f|%d|%s",
            entry.token, entry.key, entry.family, position.x, position.y, position.z,
            (okDone and done == true) and 1 or 0, observed))
        end
      end
    end
  end

  local function probeRangeHook(...)
    for index = 1, select("#", ...) do
      local value = select(index, ...)
      if type(value) == "string" then
        local range, collected, art = string.match(value, "^PROX23|(%d+)|([%d,]*)|([%w,]*)$")
        if range ~= nil then
          local member = probeMember
          if member ~= nil and member.index ~= nil then
            local mapCollected = false
            for number in string.gmatch(collected, "%d+") do
              if tonumber(number) == member.index then mapCollected = true end
            end
            member.mapSeen, member.mapCollected = true, mapCollected
          end
          probeGranted = {}
          for token in string.gmatch(art, "%w+") do probeGranted[token] = true end
          local ok, err = pcall(probeApply, tonumber(range))
          if not ok then probeError("apply", err) end
          local okReport, reportErr = pcall(probeReport)
          if not okReport then probeError("report", reportErr) end
          return
        end
      end
    end
  end

  local function probeStart()
    if probeMember ~= nil then return end
    local row, detail
    if probeFamily ~= nil then
      row, detail = {nil, probeFamily, probeFamily .. ":" .. tostring(probeName(thisObj))}, "script"
    else
      row, detail = probeIdentify(thisObj, thisLevel and thisLevel.Name)
    end
    if row == nil then
      probeLog("unidentified reason=" .. tostring(detail) .. " level=" ..
        tostring(thisLevel and thisLevel.Name) .. " object=" .. tostring(probeName(thisObj)))
      return
    end
    probeMember = {id = row[3], family = row[2], index = row[4], mapSeen = row[4] == nil}
    local okBuild, buildErr = pcall(probeBuild)
    if not okBuild then probeError("build", buildErr) end
    local okThunk, thunk = pcall(require, "core.thunk")
    if okThunk and type(thunk) == "table" and type(thunk.Install) == "function" then
      local okInstall, err = pcall(thunk.Install, "COMPLETIONIST_PROXIMITY23_SHOW", probeRangeHook)
      if not okInstall then probeError("hook", err) end
    else
      probeError("thunk", thunk)
    end
    probeLog("identified id=" .. row[3] .. " family=" .. row[2] .. " depth=" .. tostring(detail))
    probeApply(probeDefaultRange)
  end

  local function probePack(...)
    return {n = select("#", ...), ...}
  end
  local probeOriginalLoaded = OnScriptLoaded
  if type(probeOriginalLoaded) == "function" then
    function OnScriptLoaded(...)
      local results = probePack(probeOriginalLoaded(...))
      local ok, err = pcall(probeStart)
      if not ok then probeError("start", err) end
      return unpack(results, 1, results.n)
    end
  end
end
-- END COMPLETIONIST PROXIMITY V1.1.0
