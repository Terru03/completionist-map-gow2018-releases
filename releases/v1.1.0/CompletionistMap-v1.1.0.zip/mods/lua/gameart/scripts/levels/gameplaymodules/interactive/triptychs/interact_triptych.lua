local LD = require("design.LevelDesignLibrary")
local timers = require("level.timer")
local monitors = require("level.MonitorLibrary")
local mpicon = require("ui.mpicon")
local thisObj, thisLevel, player, sonRangeMonitor, frontInteractZone
local interactComplete = false
local tripTychBanterBranch
local interactActive = false
local mainBlockStarted, enabled, son, startsEnabled, triptychCompletedTimer
local triptychCompleted = false
local banterConvoPlayed
local interactWasAborted = false
local config
local banterFirstStart = "triptych_first_start"
local banterSubsequentStart = "triptych_sub_start"
local banterBreakout = "triptych_breakout"
local banterInteractBlock, journalUpdateID
local breakOutDistance = 20
local triptychFX
local started = false
local journal
function OnScriptLoaded(level, obj)
  thisObj = obj
  thisLevel = level
  triptychCompletedTimer = StartLevelTimer(30, ConvoDone)
  triptychCompletedTimer:Stop()
  player = game.Player.FindPlayer()
  son = game.AI.FindSon()
  triptychFX = obj:FindSingleGOByName("Tryptich_Light_Burst")
  frontInteractZone = LD.CreateInteractZone_Standard_180(obj, "promptJoint")
  LD.OverrideInteractZoneTags(frontInteractZone, "NotWhileSonInteracting", true)
  if frontInteractZone.SetRequiresCriticalBanterComplete then
    frontInteractZone:SetRequiresCriticalBanterComplete(true)
  end
  startsEnabled = obj:GetLuaTableAttribute("startsEnabled")
  banterInteractBlock = obj:GetLuaTableAttribute("banterInteractBlock")
  journalUpdateID = obj:GetLuaTableAttribute("journalUpdateID")
  config = obj:FindLuaTableAttribute("config")
  if startsEnabled then
    enabled = true
  else
    enabled = false
  end
  if config == "bergelmir" then
    thisObj:SetCharacterConfig("bergelmir")
  elseif config == "solargram" then
    thisObj:SetCharacterConfig("solargramAndManagarm")
  elseif config == "surtr" then
    thisObj:SetCharacterConfig("surtr")
  elseif config == "groa" then
    thisObj:SetCharacterConfig("groa")
  elseif config == "thamur" then
    thisObj:SetCharacterConfig("thamur")
    breakOutDistance = 6
  elseif config == "jormungandr" then
    thisObj:SetCharacterConfig("jormungandr")
  elseif config == "thrym" then
    thisObj:SetCharacterConfig("thrym")
  elseif config == "tyr" then
    thisObj:SetCharacterConfig("tyr")
    thisObj:StartAnimation({
      Animation = "envTriptychOpenIdle"
    })
  elseif config == "ymir" then
    thisObj:SetCharacterConfig("ymir")
  elseif config == "hrungnir" then
    thisObj:SetCharacterConfig("brawler")
  elseif config == "skadi" then
    thisObj:SetCharacterConfig("skadi")
  elseif config == "starkadr" then
    thisObj:SetCharacterConfig("starkadr")
  end
  journal = obj:FindSingleGOByName("sonJournal00")
  game.SubObject.Sleep(obj)
end
function OnStart(level, obj)
  if enabled and not triptychCompleted then
    if config == "thamur" and game.Wallets.GetResourceValue("HERO", "Tryptich_Thamur") > -1 then
      DisableTriptych()
      thisObj:StartAnimation({
        Animation = "envTriptychOpenIdle"
      })
    else
      EnableTriptych()
    end
  elseif triptychCompleted then
    DisableTriptych()
    thisObj:StartAnimation({
      Animation = "envTriptychOpenIdle"
    })
  else
    DisableTriptych()
  end
  SoundInit()
  if journal ~= nil then
    journal:Hide()
  end
  QuestFixUp()
end
function OnUseWorld(level, obj)
  if frontInteractZone:PlayerCanInteract() and son ~= nil and son:IsAvailableForSync() == true and not son:IsInteracting() then
    son:RequestInteract(obj, frontInteractZone)
    player:RequestInteract(obj, frontInteractZone)
  end
end
function OnInteractStart(level, obj, creature)
  if not started then
    sonRangeMonitor = monitors.CreateDistanceMonitor(player, obj)
    sonRangeMonitor:OnFartherThan(breakOutDistance, StartAbort)
    StartPlayerInteract()
    started = true
  end
end
function OnInteractAbort(level, obj, creature)
end
function OnInteractFinish(level, obj, creature)
end
function OnInteractDone(level, obj, creature)
  print("got interact done msg", creature:GetName())
  if creature:GetName() == "son00" then
    game.Interact.EnableTags("NotWhileLoreReadActive")
  end
end
function QuestFixUp()
  if triptychCompleted == true and journalUpdateID ~= nil and not game.Wallets.HasResource("HERO", journalUpdateID) then
    triptychCompleted = false
    thisObj:JumpAnimationToFrame(0, {
      Animation = "envTriptychOpen"
    })
    thisObj:PauseAnimation()
    EnableTriptych()
  end
end
function SpawnJournal()
  if journal ~= nil then
    journal:Show()
    journal:Unparent()
  end
end
function ResetJournal()
  if journal ~= nil then
    journal:Hide()
    thisObj:AddChild(journal)
  end
end
function StartPlayerInteract()
  thisObj:HideNavObstacle()
  LD.PlaySingleSynchMove_KratosObject(thisObj, "synchJoint", "Triptych Open", "BRA_TriptychEnter", "envTriptychOpen", frontInteractZone, true)
  frontInteractZone:Disable()
  triptychCompleted = true
  if son.OwnedPOI and son.OwnedPOI.Type == "ContextAction" then
    son.OwnedPOI:SendEvent("CA_Interrupt")
  end
  LD.ExtractAndExecuteCallbacksForEvent(thisLevel, thisObj, thisObj:FindLuaTableAttribute("Event_OnTriptychStarted"), "Triptych Started")
  print(thisObj, "GOT START FROM GENERIC SUB OBJECT.....")
end
function StartMainBanterBlock()
  if not mainBlockStarted then
    mainBlockStarted = true
    game.Audio.PlayBanter(banterInteractBlock, ConvoDone)
    triptychCompletedTimer:Start()
  end
end
function LuaHook_StartSonSync()
  PlayBanterStart()
  SpawnJournal()
  SyncSonAndJournal()
end
function SyncSonAndJournal()
  local aiPuppeteer = game.Puppeteer.NewForce(thisObj, "LD Lib - Sync And Play Branch", son)
  local slaveTable = {}
  if journal ~= nil then
    slaveTable = {
      {
        Slave = journal,
        Anim = "envTriptychEnter"
      }
    }
  end
  aiPuppeteer:Sync("BRA_TriptychEnter", false, slaveTable, "synchJoint")
  game.Interact.DisableTags("NotWhileLoreReadActive")
  timers.StartLevelTimer(0.1, function()
    local sonSyncJointIndex = thisObj:GetJointIndex("sonSyncJoint")
    if son ~= nil and sonSyncJointIndex ~= nil then
      son:Warp(thisObj:GetWorldJointPosition(sonSyncJointIndex), thisObj:GetWorldJointForward(sonSyncJointIndex))
    end
  end)
  aiPuppeteer:OnComplete(function()
    ResetJournal()
    if aiPuppeteer ~= nil then
      aiPuppeteer:Clear()
      aiPuppeteer = nil
    end
  end)
end
function ConvoDone()
  triptychCompletedTimer:Stop()
  if interactWasAborted == false then
    banterConvoPlayed = true
    LD.ExtractAndExecuteCallbacksForEvent(thisLevel, thisObj, thisObj:GetLuaTableAttribute("Event_OnTriptychCompleted"), "Triptych Completed Normally")
    SonAbortedInteract()
    UpdateJournal()
  end
end
function LuaHook_TurnOffFX()
  if triptychFX ~= nil then
    triptychFX:Hide()
  end
end
function LuaHook_OpenTriptych()
  PlaySoundOnTriptychOpen()
end
function UpdateJournal()
  journalUpdateID = string.gsub(journalUpdateID, "%s+", "")
  LD.UpdateJournal(journalUpdateID, 0)
  if journalUpdateID == "Tryptich_Jormungandr" and game.Level.GetVariable("CompletedCineNumber") >= 340 then
    game.Wallets.AddResource("HERO", "Tryptich_Jormungandr_PostBoat", 1)
  end
  if journalUpdateID == "Tryptich_Thamur" then
    game.Wallets.AddResource("HERO", "Tryptich_Thamur_PostBoat", 1)
  end
  if journalUpdateID ~= "Tryptich_Tyr" then
    TrophyUpdate()
    IncrementQuest()
  end
  game.SubObject.SoftSave(thisObj)
end
function TrophyUpdate()
  game.Wallets.AddResource("HERO", "TryptichMarker", 1)
  if game.Wallets.GetResourceValue("HERO", "TryptichMarker") == 12 then
    AwardTrophy()
  end
end
function AwardTrophy()
  game.UnlockTrophy(33)
end
function StartAbort()
  interactWasAborted = true
  triptychCompletedTimer:Stop()
  LD.ExtractAndExecuteCallbacksForEvent(thisLevel, thisObj, thisObj:GetLuaTableAttribute("Event_OnTriptychAbort"), "Triptych Aborted")
  SonAbortedInteract()
end
function SonAbortedInteract()
  sonRangeMonitor:Stop()
  son:TriggerMoveEvent("abortInteract")
  if not son:HasMarker("exitingInteract") and not son:PickupIsAcquired("InteractAbort") then
    son:PickupAcquire("InteractAbort")
  end
  if not banterConvoPlayed then
    game.Audio.PlayBanter(banterBreakout)
    UpdateJournal()
  end
end
function Abort()
  if started and interactWasAborted == false then
    StartAbort()
  end
end
function EnableTriptych()
  if triptychCompleted == false then
    enabled = true
    frontInteractZone:Enable()
    if triptychFX ~= nil then
      triptychFX:Show()
    end
  end
end
function DisableTriptych()
  enabled = false
  frontInteractZone:Disable()
  if triptychFX ~= nil then
    triptychFX:Hide()
  end
end
function PlayBanterStart()
  if LD.GetEntityVariable("GLO_UsedFirstTriptych") == false then
    game.Audio.PlayBanter(banterFirstStart, StartMainBanterBlock)
    LD.SetEntityVariable("GLO_UsedFirstTriptych", true)
  else
    game.Audio.PlayBanter(banterSubsequentStart, StartMainBanterBlock)
  end
end
function IncrementQuest()
  local questState = game.QuestManager.GetQuestState("Quest_Triptychs_Parent")
  if questState == "Inactive" then
    game.QuestManager.StartQuest("Quest_Triptychs_Parent")
  end
  game.QuestManager.IncrementQuestProgress("Quest_Triptychs_Objective", 1)
end
local triptychEmitter
local triptychOnOpenSoundEvent = "SND_MECH_Triptych_Open"
function SoundInit()
  triptychEmitter = thisObj:FindSingleSoundEmitterByName("SNDTriptych")
end
function PlaySoundOnTriptychOpen()
  LD.PlaySound(triptychEmitter, triptychOnOpenSoundEvent)
end
function OnSaveCheckpoint(level, obj)
  return {enabled = enabled, triptychCompleted = triptychCompleted}
end
function OnRestoreCheckpoint(level, obj, tab)
  enabled = tab.enabled
  triptychCompleted = tab.triptychCompleted
end

-- BEGIN COMPLETIONIST COLLECTIBLE OBSERVATION
do
  function IsTriptychCompleted()
    return triptychCompleted
  end
  function GetState()
    return triptychCompleted and 1 or 0
  end
  function CompletionistCollectibleObserve()
    if type(triptychCompleted) ~= "boolean" then return nil end
    local collected = triptychCompleted
    if collected then
      if type(journalUpdateID) ~= "string" or journalUpdateID == "" then return nil end
      collected = game.Wallets.HasResource("HERO", journalUpdateID) == true
    end
    return "shrine", collected and "collected" or "remaining"
  end
  local function clearActiveCompassMarker()
    pcall(function()
      if type(game) == "table" and type(game.Compass) == "table" and type(game.Compass.FindMarkersByIconClass) == "function" then
        local markers = game.Compass.FindMarkersByIconClass({"SIDE"})
        if type(markers) == "table" then
          for _, id in ipairs(markers) do
            pcall(game.Compass.HideMarker, id)
          end
        end
      end
    end)
  end
  local function notify()
    if triptychCompleted then
      clearActiveCompassMarker()
    end
    if thisLevel == nil or type(thisLevel.Name) ~= "string" then return end
    engine.SendHook("COMPLETIONIST_COLLECTIBLE_DIRTY_V1", engine.GetUIWad(),
      "COLLECTIBLE_DIRTY_V1	" .. string.lower(thisLevel.Name))
  end
  local function pack(...) return {n=select('#',...), ...} end
  local unpackValues = unpack or table.unpack
  local function wrap(original)
    return function(...)
      local result = pack(original(...))
      pcall(notify)
      return unpackValues(result, 1, result.n)
    end
  end
  if type(UpdateJournal) == "function" then UpdateJournal = wrap(UpdateJournal) end
  if type(OnStart) == "function" then OnStart = wrap(OnStart) end
  if type(OnRestoreCheckpoint) == "function" then OnRestoreCheckpoint = wrap(OnRestoreCheckpoint) end
end
-- END COMPLETIONIST COLLECTIBLE OBSERVATION
-- BEGIN COMPLETIONIST PROXIMITY V1.1.0
-- Shows the game's native interact hint dot on this collectible out to the
-- map's [Up Arrow] range. Append-only: OnScriptLoaded runs unchanged first;
-- every call below is pcall-guarded.
do
  local probeRows = {
    {"xpl250_funeralinterior", "jotnar_shrine", "jotnar_shrine_4f54c8b2f4d927800573fde8aece376f", 7, "triptych_skadi"},
    {"msp100_base", "jotnar_shrine", "jotnar_shrine_682f1626cae370f11b4df300ae79219d", 18, "triptych_surtr"},
    {"stn105_chiselsite", "jotnar_shrine", "jotnar_shrine_e49959e54f3f1da0632c3ac2a01d7ec7", 35, "triptych_thamur"},
    {"stn905_chiselsite", "jotnar_shrine", "jotnar_shrine_e49959e54f3f1da0632c3ac2a01d7ec7", 36, "triptych_thamur"},
    {"peak720_summitascenthub", "jotnar_shrine", "jotnar_shrine_5abb17c179c16ed72287fc2740a46f9a", 88, "tryptich"},
    {"alf370_moatscripting", "jotnar_shrine", "jotnar_shrine_6e55a7d7704af68ce4b82e5edecf81a7", 109, "triptych_groa"},
    {"cal590_runevaultelevator", "jotnar_shrine", "jotnar_shrine_23d6030ef079b748c4574a940bf2047b", 143, "triptych_tyr_base"},
    {"for660_templeinterior", "jotnar_shrine", "jotnar_shrine_7dadb7c3e8c5fdc6259b311fe6ac74ba", 167, "triptych_solargarm"},
    {"cal250_foothillslh", "jotnar_shrine", "jotnar_shrine_19c69abd2cdf4145b71903eabdaf87f8", 222, "triptych"},
    {"xpl150_httktemple", "jotnar_shrine", "jotnar_shrine_b124fa2d62938dc8fcf85d67432d8550", 311, "triptych_starkadr"},
    {"riv225_dangerscave", "jotnar_shrine", "jotnar_shrine_c0d7a4d17e152054e3e3c3e2571d98b8", 342, "triptychbasic"},
    {"xpl970_beachtower", "jotnar_shrine", "jotnar_shrine_b35ee9b618a76bfdf24596944d7b11b0", 356, "triptych_thrym"},
    {"cal170_library1", "jotnar_shrine", "jotnar_shrine_1af4f035065fe9603505c02d9b2e1462", 360, "triptych_tyr"},
    {"cal720_lowercenterroom", "jotnar_shrine", "jotnar_shrine_8a16de1ec11694c5752092bd06e16978", 406, "triptychbasic"},
  }
  local probeFamily = nil
  local probeDefaultRange = 50
  local probeMember = nil
  local probeErrors = {}

  local function probeLog(text)
    print("[CompletionistProximity] " .. text)
  end

  local function probeError(key, err)
    if not probeErrors[key] then
      probeErrors[key] = true
      probeLog("error " .. key .. " " .. tostring(err))
    end
  end

  local function probeLower(value, prefix)
    if type(value) ~= "string" then return nil end
    value = string.lower(value)
    if string.sub(value, 1, #prefix) == prefix then value = string.sub(value, #prefix + 1) end
    return value
  end

  local function probeName(go)
    if go == nil then return nil end
    local ok, name = pcall(function() return go:GetName() end)
    if ok then return probeLower(name, "go") end
  end

  local function probeParent(go)
    if go == nil then return nil end
    local ok, parent = pcall(function() return go.Parent end)
    if ok then return parent end
  end

  local function probeFind(node, name)
    for _, query in ipairs({name, "go" .. name}) do
      local ok, found = pcall(function() return node:FindSingleGOByName(query) end)
      if ok and found ~= nil then return found end
    end
  end

  local function probeChain(node, row)
    local cursor = node
    for index = 5, #row do
      if cursor == nil or probeName(cursor) ~= row[index] then return false end
      cursor = probeParent(cursor)
    end
    return true
  end

  -- Exact catalogue identity: level plus the owner name path, starting at this
  -- script's object, one of its ancestors, or a named descendant of the object
  -- or its two nearest ancestors. Ambiguous or unmatched objects are left alone.
  local function probeIdentify(obj, levelName)
    local level = probeLower(levelName, "wad_")
    local node = obj
    for depth = 0, 6 do
      if node == nil then break end
      local found
      for _, row in ipairs(probeRows) do
        if row[1] == level then
          local matched = probeChain(node, row)
          if not matched and depth <= 2 then
            local child = probeFind(node, row[5])
            matched = child ~= nil and probeChain(child, row)
          end
          if matched then
            if found ~= nil and found ~= row then return nil, "ambiguous" end
            found = row
          end
        end
      end
      if found ~= nil then return found, depth end
      node = probeParent(node)
    end
    return nil, "unmatched"
  end

  -- The script's own hint distances, as its zone factory and code set them.
  local function probeOriginal()
    return 5, 2
  end

  -- Applied on every broadcast: the script may recreate its zone or reset its
  -- hint distance, and zones have no hint getter. Logged only on change.
  local function probeWiden(range)
    local member = probeMember
    local zone = frontInteractZone
    if zone == nil then
      probeError("zone", "interact zone missing")
      return
    end
    local xz, y = probeOriginal()
    if range > 0 then
      xz, y = math.max(xz, range), math.max(y, range)
    end
    local ok, err = pcall(function()
      zone:SetHintXZRange(xz)
      zone:SetHintYRange(y)
    end)
    if not ok then
      probeError("hint", err)
      return
    end
    if member.zone == zone and member.applied == range then return end
    member.zone, member.applied = zone, range
    probeLog("hint " .. member.id .. " family=" .. member.family .. " xz=" .. tostring(xz) ..
      " y=" .. tostring(y) .. " range=" .. tostring(range))
  end

  -- Hint-only zones the probe owns: no interact range, so no button prompt;
  -- enabled while the range is on and the collectible is not collected.
  local probeEntries = {}
  local probeJoints = {"promptJoint", "zeroJoint", "promptJointFront", "synchJoint", "promptJoint_Son", "linkJoint", "root", "Root", "JORoot", "jointRoot", "joint1", "ApproachPoint", "enabledCollision", "disabledCollision", "Pristine", "Broken1", "approachJoint", "gameJoint", "rewardJoint", "syncJoint", "lootObjLocation", "SpawnDirection", "JOPelvis1", "JOBell1"}
  -- This object's own token (a table address in its Lua state), so the map
  -- can grant art to one object even when two objects claim one catalogue row.
  local probeToken = string.match(tostring({}), "(%x+)$") or "0"
  local probeGranted = {}

  local function probeObserved()
    if type(CompletionistCollectibleObserve) ~= "function" then return nil end
    local ok, _, state = pcall(CompletionistCollectibleObserve)
    if ok then return state end
  end

  local function probeList(...)
    return {n = select("#", ...), ...}
  end

  local function probeChild(go)
    if go == nil then return nil end
    local ok, child = pcall(function() return go.Child end)
    if ok then return child end
  end

  local function probeSonHosts()
    local okSon, son = pcall(function() return thisObj:FindSingleGOByName("GenericSonInteract") end)
    if not okSon or son == nil then return thisObj end
    return probeChild(son), son, thisObj
  end

  -- The object, its descendants breadth first (ref-node Child and grouped
  -- Children), then its parent: joints sit on the meshes, not the roots.
  local function probeTree(root)
    local found, queue, head = {}, {root}, 1
    while queue[head] ~= nil and #found < 48 do
      local node = queue[head]
      head = head + 1
      found[#found + 1] = node
      local child = probeChild(node)
      if child ~= nil then queue[#queue + 1] = child end
      local ok, children = pcall(function() return node.Children end)
      if ok and type(children) == "table" then
        for _, item in ipairs(children) do queue[#queue + 1] = item end
      end
    end
    local parent = probeParent(root)
    if parent ~= nil then found[#found + 1] = parent end
    found.n = #found
    return found
  end

  -- Where the zone's joint is in the world, for the log.
  local function probeWhere(host, joint)
    local ok, position = pcall(function() return host:GetWorldJointPosition(host:GetJointIndex(joint)) end)
    if not ok or position == nil then
      ok, position = pcall(function() return host:GetWorldPosition() end)
    end
    if ok and position ~= nil then
      return string.format("%.1f,%.1f,%.1f", position.x, position.y, position.z)
    end
    return "?"
  end

  -- Joint names the engine reports for a host, when it has such calls; the
  -- static puzzle meshes list no joint names in the level data.
  local function probeJointNames(host)
    local names, info = {}, {}
    for _, method in ipairs({"GetJointCount", "GetNumJoints"}) do
      local ok, value = pcall(function() return host[method](host) end)
      if ok and value ~= nil then info[#info + 1] = method .. "=" .. tostring(value) end
    end
    for index = 0, 8 - 1 do
      local ok, value = pcall(function() return host:GetJointName(index) end)
      if ok and type(value) == "string" and value ~= "" then names[#names + 1] = value end
    end
    if #names > 0 then info[#info + 1] = "names=" .. table.concat(names, ",") end
    return names, table.concat(info, " ")
  end

  local function probeCreate(hosts, icon, range)
    local last, tried = "no host", {}
    for index = 1, hosts.n do
      local host = hosts[index]
      if host ~= nil then
        local joints = probeJoints
        local reported, info = probeJointNames(host)
        if #reported > 0 then
          joints = {}
          for _, joint in ipairs(probeJoints) do joints[#joints + 1] = joint end
          for _, joint in ipairs(reported) do joints[#joints + 1] = joint end
        end
        if #tried < 24 then
          tried[#tried + 1] = tostring(probeName(host)) .. (info ~= "" and ("{" .. info .. "}") or "")
        end
        for _, joint in ipairs(joints) do
          local ok, zone = pcall(function() return game.InteractZone.New(host, joint) end)
          if ok and zone ~= nil then
            local okSetup, err = pcall(function()
              zone:SetTemplateValues({
                name = "Completionist Hint",
                interactFrontAngleMax = 360,
                yRangeMax = 0,
                xzRange = 0,
                xzRangeMax = 0,
                hintXZRange = range,
                hintYRange = range,
                onScreenPercentMin = 1,
                onScreenPercentMax = 0.01,
                onScreenPercentWeight = 0,
                cameraFrontAngleMax = 360
              })
              zone:SetTags("NotInCombat")
              zone:SetPromptIconSet({
                normal = "WORLD_INTERACT_LOOT",
                unavailable = "WORLD_INTERACT_UNAVAILABLE_LOOT",
                locked = "WORLD_INTERACT_LOCKED_LOOT",
                hint = icon
              })
            end)
            if not okSetup then return nil, "setup " .. tostring(err) end
            -- Hints show only within this angle of the joint's facing; the
            -- game uses 360 for hints seen from every side (xpl950_beachmaze).
            local okAngle, angleErr = pcall(function() zone:SetHintAngle(360) end)
            if not okAngle then probeError("hint_angle", angleErr) end
            return zone, tostring(probeName(host)) .. "/" .. joint .. " pos=" .. probeWhere(host, joint)
          end
          last = tostring(zone)
        end
      end
    end
    return nil, last .. " tried=" .. table.concat(tried, ",")
  end

  -- art: reports this collectible to the map, which shows its family art as a
  -- compass marker; while it does, the token is granted and dots give way.
  -- dot: a white hint zone where no stock zone is widened.
  local function probeAdd(key, family, hosts, done, dot, token)
    probeEntries[#probeEntries + 1] = {key = key, family = family, kind = "art", hosts = hosts, done = done,
      token = token}
    if dot then
      probeEntries[#probeEntries + 1] = {key = key, family = family, kind = "dot", hosts = hosts, done = done,
        token = token, icon = "WORLD_INTERACT_HINT_LOOT"}
    end
  end

  local function probeBuild()
    probeAdd(probeMember.id, probeMember.family, function() return probeList(thisObj) end,
      function() return probeMember.mapCollected == true or (probeObserved() == "collected") end, false, probeToken)
  end

  -- A zone that is no longer wanted is destroyed, not just disabled.
  local function probeDrop(entry)
    local zone = entry.zone
    entry.zone, entry.applied = nil, nil
    pcall(function() zone:Disable() end)
    local ok = pcall(function() zone:Destroy() end)
    probeLog("zone " .. entry.key .. " kind=" .. entry.kind .. " family=" .. entry.family ..
      " dropped destroyed=" .. tostring(ok))
  end

  local function probeEntry(entry, range)
    local okDone, done = pcall(entry.done)
    local show = range > 0 and not (okDone and done == true) and not probeGranted[entry.token]
    if entry.kind == "art" then
      if entry.zone ~= nil then probeDrop(entry) end
      return
    end
    if entry.zone == nil then
      if not show or (entry.failures or 0) >= 5 then return end
      local okHosts, hosts = pcall(entry.hosts)
      local zone, where = nil, tostring(hosts)
      if okHosts and type(hosts) == "table" then zone, where = probeCreate(hosts, entry.icon, range) end
      if zone == nil then
        entry.failures = (entry.failures or 0) + 1
        probeError("zone " .. entry.key .. " " .. entry.kind, where)
        return
      end
      entry.zone, entry.where = zone, where
    end
    local ok, err = pcall(function()
      if show then
        entry.zone:SetHintXZRange(range)
        entry.zone:SetHintYRange(range)
        entry.zone:Enable()
      else
        entry.zone:Disable()
      end
    end)
    if not ok then
      probeError("hint " .. entry.key .. " " .. entry.kind, err)
      return
    end
    local applied = show and range or 0
    if entry.applied == applied then return end
    entry.applied = applied
    probeLog("zone " .. entry.key .. " kind=" .. entry.kind .. " family=" .. entry.family .. " at=" ..
      tostring(entry.where) .. " shown=" .. tostring(show) .. " range=" .. tostring(range))
  end

  -- Rows the map store holds as collected (what hides their map pins) get no
  -- dots and the stock hint distance. Probe-owned zones wait for the map's
  -- first broadcast, so a collected row never flashes at load.
  local function probeApply(range)
    local member = probeMember
    if member == nil then return end
    if member.mapCollected then range = 0 end
    range = math.min(range, 25)
    if probeWiden ~= nil then probeWiden(probeGranted[probeToken] and 0 or range) end
    if not member.mapSeen then return end
    for _, entry in ipairs(probeEntries) do probeEntry(entry, range) end
  end

  -- Each collectible this object carries tells the map where it is and
  -- whether it is done; the map grants art from these reports.
  local function probeReport()
    local route = engine.GetUIWad()
    for _, entry in ipairs(probeEntries) do
      if entry.kind == "art" then
        local okDone, done = pcall(entry.done)
        local position
        local okHosts, hosts = pcall(entry.hosts)
        if okHosts and type(hosts) == "table" then
          for index = 1, hosts.n do
            if position == nil and hosts[index] ~= nil then
              local ok, value = pcall(function() return hosts[index]:GetWorldPosition() end)
              if ok and value ~= nil then position = value end
            end
          end
        end
        -- This object's own CompletionistCollectibleObserve answer, which the
        -- map cannot read itself (LuaObjectScript is nil from the UI state).
        local observed = "-"
        if entry.key == probeMember.id then
          local seen = probeObserved()
          if seen == "collected" then observed = "c" elseif seen == "remaining" then observed = "r" end
        end
        if position ~= nil then
          engine.SendHook("COMPLETIONIST_PROXIMITY23_REPORT", route, string.format("PROX23R|%s|%s|%s|%.1f|%.1f|%.1f|%d|%s",
            entry.token, entry.key, entry.family, position.x, position.y, position.z,
            (okDone and done == true) and 1 or 0, observed))
        end
      end
    end
  end

  local function probeRangeHook(...)
    for index = 1, select("#", ...) do
      local value = select(index, ...)
      if type(value) == "string" then
        local range, collected, art = string.match(value, "^PROX23|(%d+)|([%d,]*)|([%w,]*)$")
        if range ~= nil then
          local member = probeMember
          if member ~= nil and member.index ~= nil then
            local mapCollected = false
            for number in string.gmatch(collected, "%d+") do
              if tonumber(number) == member.index then mapCollected = true end
            end
            member.mapSeen, member.mapCollected = true, mapCollected
          end
          probeGranted = {}
          for token in string.gmatch(art, "%w+") do probeGranted[token] = true end
          local ok, err = pcall(probeApply, tonumber(range))
          if not ok then probeError("apply", err) end
          local okReport, reportErr = pcall(probeReport)
          if not okReport then probeError("report", reportErr) end
          return
        end
      end
    end
  end

  local function probeStart()
    if probeMember ~= nil then return end
    local row, detail
    if probeFamily ~= nil then
      row, detail = {nil, probeFamily, probeFamily .. ":" .. tostring(probeName(thisObj))}, "script"
    else
      row, detail = probeIdentify(thisObj, thisLevel and thisLevel.Name)
    end
    if row == nil then
      probeLog("unidentified reason=" .. tostring(detail) .. " level=" ..
        tostring(thisLevel and thisLevel.Name) .. " object=" .. tostring(probeName(thisObj)))
      return
    end
    probeMember = {id = row[3], family = row[2], index = row[4], mapSeen = row[4] == nil}
    local okBuild, buildErr = pcall(probeBuild)
    if not okBuild then probeError("build", buildErr) end
    local okThunk, thunk = pcall(require, "core.thunk")
    if okThunk and type(thunk) == "table" and type(thunk.Install) == "function" then
      local okInstall, err = pcall(thunk.Install, "COMPLETIONIST_PROXIMITY23_SHOW", probeRangeHook)
      if not okInstall then probeError("hook", err) end
    else
      probeError("thunk", thunk)
    end
    probeLog("identified id=" .. row[3] .. " family=" .. row[2] .. " depth=" .. tostring(detail))
    probeApply(probeDefaultRange)
  end

  local function probePack(...)
    return {n = select("#", ...), ...}
  end
  local probeOriginalLoaded = OnScriptLoaded
  if type(probeOriginalLoaded) == "function" then
    function OnScriptLoaded(...)
      local results = probePack(probeOriginalLoaded(...))
      local ok, err = pcall(probeStart)
      if not ok then probeError("start", err) end
      return unpack(results, 1, results.n)
    end
  end
end
-- END COMPLETIONIST PROXIMITY V1.1.0
