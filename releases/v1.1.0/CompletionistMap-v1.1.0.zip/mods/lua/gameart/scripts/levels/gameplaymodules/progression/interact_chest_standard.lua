local LD = require("design.LevelDesignLibrary")
local uiCalls, TUT, thisObj, thisLevel, player, son, onOpenedEvent, interactionOnFinish, interactZone, openFX, idleFX, parentObj, useLOSTest, chestType, rewardTier, rewardTierIndex, WADName, lootObjectName, reward, interactionName, branchName, animName, lootObject
local completion_percentage = 0.5
local typeSpecificData, typeSpecificCallbacks, trapChest, onInteractStartCallbacks, onInteractFinishCallbacks
local checkpointOnOpened = false
local checkpointOnOpened_Override
local checkpointRequirementDisabled = false
local state
local states = {
  ENABLED = 1,
  DISABLED = 2,
  LOCKED = 3,
  OPENED = 4
}
local uiCalls_LoadLibrary = function()
  if uiCalls == nil then
    uiCalls = require("ui.uicalls")
  end
end
local TUT_LoadLibrary = function()
  if TUT == nil then
    TUT = require("game.GlobalTutorials")
  end
end
function OnScriptLoaded(level, obj)
  thisObj = obj
  thisLevel = level
  player = game.Player.FindPlayer()
  son = game.AI.FindSon()
  parentObj = thisObj.Parent.Parent
  interactZone = LD.CreateInteractZone_Standard_180(parentObj, "promptJointFront")
  interactZone:SetHintXZRange(3)
  interactZone:SetPromptJoint("promptJointLoc")
  idleFX = parentObj:FindSingleGOByName("AmbientFX").Child
  lootObject = parentObj:FindSingleGOByName("lootObject")
  if lootObject then
    lootObject = lootObject.Child
  end
  onOpenedEvent = thisObj:FindLuaTableAttribute("onOpenedEvent")
  if onOpenedEvent ~= nil then
    onOpenedEvent = LD.ExtractCallbacksForEvent(thisLevel, thisObj, onOpenedEvent)
  end
  interactionOnFinish = thisObj:FindLuaTableAttribute("interactionOnFinish")
  if interactionOnFinish ~= nil then
    interactionOnFinish = LD.ExtractCallbacksForEvent(thisLevel, thisObj, interactionOnFinish)
  end
  chestType = thisObj:GetLuaTableAttribute("ChestType")
  rewardTier = thisObj:GetLuaTableAttribute("RewardTier")
  rewardTierIndex = thisObj:GetLuaTableAttribute("RewardTierIndex")
  WADName = thisObj:FindLuaTableAttribute("WADName")
  lootObjectName = thisObj:GetLuaTableAttribute("LootObject")
  checkpointOnOpened = thisObj:GetLuaTableAttribute("CheckpointOnOpened")
  checkpointOnOpened_Override = thisObj:GetLuaTableAttribute("CheckpointOnOpened_Override")
  if checkpointOnOpened_Override ~= nil and checkpointOnOpened_Override ~= "" then
    checkpointOnOpened_Override = GameObjects[checkpointOnOpened_Override]
  else
    checkpointOnOpened_Override = nil
  end
  useLOSTest = thisObj:GetLuaTableAttribute("UseLineOfSightTest")
  local startEnabled = thisObj:GetLuaTableAttribute("StartEnabled")
  local startLocked = thisObj:GetLuaTableAttribute("StartLocked")
  if useLOSTest and interactZone then
    interactZone:SetEnableLineOfSightTest(true)
  end
  if startEnabled then
    state = states.ENABLED
  else
    state = states.DISABLED
  end
  if startLocked then
    state = states.LOCKED
  end
  typeSpecificData = {}
  typeSpecificCallbacks = {}
  SoundInit()
  game.SubObject.Sleep(obj)
  local levelName = level.Name
  if string.find(levelName, "Nid") == nil and string.find(levelName, "Msp") == nil then
    idleFX:SetInhibitSave()
    parentObj:SetInhibitSave()
    thisObj:SetInhibitSave()
    if chestType == "Common" then
      parentObj:FindSingleGOByName("animatedLid"):SetInhibitSave()
    end
  end
end
function OnFirstStart(level, obj)
  if lootObject then
    lootObject:HideModel()
    LD.HideFX(lootObject)
  end
end
function OnStart(level, obj)
  if (onOpenedEvent or interactionOnFinish) and not checkpointOnOpened and not checkpointRequirementDisabled then
    engine.Warning("Chest Error - " .. LD.GetParentTrace(thisObj) .. " has a callback, but isn't set to save a checkpoint. Check the 'CheckpointOnOpened' option in the toolbox to ensure the chest saves correctly")
  end
  SetTypeData()
  if state == states.ENABLED then
    Enable()
  elseif state == states.DISABLED then
    Disable()
  elseif state == states.LOCKED then
    LockChest()
  elseif state == states.OPENED then
    TypeSpecific_SoftSaveRestore()
  end
end
function TypeSpecific_SoftSaveRestore()
  idleFX:Hide()
  Disable()
  if animName ~= nil and animName ~= "" then
    parentObj:StartAnim(animName)
    parentObj:JumpAnimToFrame(parentObj.AnimLengthFrames)
  end
  if chestType == "Common" then
    local breakableLid = parentObj:FindSingleGOByName("animatedLid")
    if breakableLid then
      breakableLid:JumpAnimToFrame(breakableLid.AnimLengthFrames)
    end
  elseif chestType == "Dispell" then
    typeSpecificData.DispellObject:StartAnim("envMaskDispelBreak")
    typeSpecificData.DispellObject:JumpAnimToFrame(typeSpecificData.DispellObject.AnimLengthFrames)
    typeSpecificData.DispellObject:FindSingleGOByName("Mesh"):Hide()
    typeSpecificData.DispellObject:FindSingleGOByName("FX"):Hide()
  elseif chestType == "Runic_Axe" or chestType == "Runic_Blades" then
    thisObj.Parent.Parent.LuaObjectScript.Disable()
    thisObj.Parent.Parent.LuaObjectScript.DimRunesImmediate()
    thisObj.Parent.Parent.LuaObjectScript.ResolveRunicSoftSave()
  end
end
function SetTypeData()
  interactionName = chestType .. " chest opening"
  reward = "CHEST_" .. string.upper(chestType) .. "_TIER"
  if chestType == "Common" then
    branchName = "BRA_EnvContainerCommonChestLeft_M"
    animName = "breaking_topAnim"
    local breakableLid = parentObj:FindSingleGOByName("animatedLid")
    if breakableLid then
      typeSpecificData.breakableObject = breakableLid
      LD.HideFX(breakableLid)
    end
    function typeSpecificCallbacks.OnOpened()
      CommonChestBroken()
    end
  elseif chestType == "Coffin" then
    if parentObj then
      trapChest = parentObj:FindLuaTableAttribute("TrapChest_BanditSpawn")
    end
    if trapChest then
      branchName = "BRA_EnvContainerCoffinTrap_M"
      animName = "envContainerCoffinTrap"
    else
      branchName = "BRA_EnvContainerCoffin_M"
      animName = "envContainerCoffin"
    end
    reward = "COFFIN_TIER"
    openFX = "Coffin_Open_Effect_Root"
  elseif chestType == "Legendary" then
    branchName = "BRA_EnvContainerLegendaryChest_M"
    animName = "envContainerLegendary"
    openFX = "Chest_Legendary_Open_Effect_Root"
  elseif chestType == "Runic_Axe" or chestType == "Runic_Blades" then
    completion_percentage = 0
    branchName = "BRA_EnvContainerRunicChest_UnlockedShort_M"
    animName = "envTripleChestUnlocked"
    reward = "CHEST_RUNIC_TIER"
    openFX = "Chest_Locked_Open_Effect_Root"
  elseif chestType == "Dispell" then
    completion_percentage = 0
    interactZone:SetTags("NotWhileSonInteracting")
    interactZone:SetRequiresSonUnoccupied(true)
    branchName = "BRA_EnvContainerDispellChest_M"
    animName = "envLegendaryChestUnlockedShortKratos"
    openFX = "Chest_Legendary_Open_Effect_Root"
    typeSpecificData.DispellObject = parentObj:FindSingleGOByName("sondispell_chest").Child
    if typeSpecificData.DispellObject then
      typeSpecificData.DispellObject:StartAnim("maskLoopFloating")
      typeSpecificData.DispellObject:PlayAnimCycle()
    end
    if state ~= states.OPENED then
      if typeSpecificData.DispellObject and not typeSpecificData.FX_Idle then
        typeSpecificData.FX_Idle = typeSpecificData.DispellObject:FindSingleGOByName("idleFX")
        typeSpecificData.FX_Death = typeSpecificData.DispellObject:FindSingleGOByName("deathFX")
      end
      typeSpecificData.FX_Idle:SetWorldPosition(typeSpecificData.DispellObject:FindSingleGOByName("Mesh"):GetWorldPosition())
      typeSpecificData.FX_Mesh = typeSpecificData.DispellObject:FindSingleGOByName("fx_mesh")
      typeSpecificData.FX_Mesh:JumpAnimToFrame(0)
      typeSpecificData.FX_Mesh:PlayAnimToFrame(650)
      typeSpecificData.FX_Mesh:OnAnimationDone(thisObj, "OnFXMeshDone", {Force = true})
      typeSpecificData.FX_Inner = typeSpecificData.DispellObject:FindSingleGOByName("fx_meshInner")
      typeSpecificData.FX_Inner:JumpAnimToFrame(0)
      typeSpecificData.FX_Inner:PlayAnimToFrame(650)
      typeSpecificData.FX_Inner:OnAnimationDone(thisObj, "OnFXMeshInnerDone", {Force = true})
    end
    function typeSpecificCallbacks.CustomHook()
      if typeSpecificData.FX_Idle then
        LD.HideFX(typeSpecificData.FX_Idle)
      end
      if typeSpecificData.FX_Death then
        typeSpecificData.FX_Death:SetWorldPosition(typeSpecificData.DispellObject:FindSingleGOByName("Mesh"):GetWorldPosition())
        LD.ShowFX(typeSpecificData.FX_Death)
      end
      typeSpecificData.FX_Mesh:ClearAllAnimCallbacks()
      typeSpecificData.FX_Mesh:JumpAnimToFrame(650)
      typeSpecificData.FX_Mesh:PlayAnimToFrame(700)
      typeSpecificData.FX_Inner:ClearAllAnimCallbacks()
      typeSpecificData.FX_Inner:JumpAnimToFrame(650)
      typeSpecificData.FX_Inner:PlayAnimToFrame(700)
    end
    function typeSpecificCallbacks.OnOpened()
      typeSpecificData.PreAwardMuspCount = game.Wallets.GetResourceValue("HERO", "MuspelheimCipherPiece")
      typeSpecificData.PreAwardNifCount = game.Wallets.GetResourceValue("HERO", "NiflheimCipherPiece")
    end
    function typeSpecificCallbacks.AwardLoot()
      local IncrementQuest = function(parent, child, pieces)
        local questState = game.QuestManager.GetQuestState(parent)
        if questState == "Inactive" then
          game.QuestManager.StartQuest(parent)
        end
        local _, progress = game.QuestManager.GetQuestProgressAndGoal(child)
        game.QuestManager.IncrementQuestProgress(child, pieces - progress)
      end
      if game.Wallets.GetResourceValue("HERO", "MuspelheimCipherPiece") > typeSpecificData.PreAwardMuspCount then
        IncrementQuest("Quest_SonLanguage_Muspelheim_Parent", "Quest_SonLanguage_Muspelheim", game.Wallets.GetResourceValue("HERO", "MuspelheimCipherPiece"))
        if game.Wallets.GetResourceValue("HERO", "MuspelheimCipherPiece") == 4 then
          game.Audio.PlayBanterNonCritical("Musp_Disc_Complete")
        else
          game.Audio.PlayBanterNonCritical("Musp_Disc", nil, nil, false)
        end
        TrophyCheck()
      end
      if game.Wallets.GetResourceValue("HERO", "NiflheimCipherPiece") > typeSpecificData.PreAwardNifCount then
        IncrementQuest("Quest_SonLanguage_Niflheim_Parent", "Quest_SonLanguage_Niflheim", game.Wallets.GetResourceValue("HERO", "NiflheimCipherPiece"))
        local _, progress = game.QuestManager.GetQuestProgressAndGoal("Quest_SonLanguage_Niflheim")
        if game.Wallets.GetResourceValue("HERO", "NiflheimCipherPiece") == 4 then
          game.Audio.PlayBanterNonCritical("Nif_Disc_Complete")
        else
          game.Audio.PlayBanterNonCritical("Nif_Disc")
        end
        TrophyCheck()
      end
    end
  elseif chestType == "Custom_HammerQuest" then
    branchName = "BRA_EnvContainerCustomHammerQuest"
    animName = "envContainerLegendary"
    reward = ""
    openFX = "Chest_Legendary_Open_Effect_Root"
  elseif chestType == "Custom_MimirsEye" then
    branchName = "BRA_MimirsEye"
    animName = "poiMimirEye010Scene"
    reward = ""
    openFX = "Chest_Legendary_Open_Effect_Root"
  end
end
function TrophyCheck()
  if game.QuestManager.GetQuestState("Quest_SonLanguage_Muspelheim") == "Complete" and game.QuestManager.GetQuestState("Quest_SonLanguage_Niflheim") == "Complete" then
    AwardTrophy()
  end
  if game.Wallets.GetResourceValue("HERO", "MuspelheimCipherPiece") == 4 and game.Wallets.GetResourceValue("HERO", "NiflheimCipherPiece") == 4 then
    AwardTrophy()
  end
end
function OnUseWorld(level, obj)
  if interactZone:PlayerCanInteract() then
    player:RequestInteract(thisObj, {InteractZone = interactZone, LerpObject = lootObject})
  end
end
function ForceInteract()
  player:RequestInteract(thisObj, {InteractZone = interactZone, LerpObject = lootObject})
end
function GetInteractZone()
  if interactZone then
    return interactZone
  end
  return nil
end
function OnInteractStart(level, obj, creature)
  if chestType == "Dispell" then
    local syncTable = {
      {player, branchName},
      {son, branchName},
      {
        typeSpecificData.DispellObject,
        "envLegendaryChestUnlockedShortKratos"
      }
    }
    LD.PlayApproach_GroupSync(parentObj, syncTable, animName, true, "synchJoint", {completion_percentage = completion_percentage})
  elseif chestType == "Coffin" and trapChest then
    game.Audio.SetBanterFact("CreatureSpawnCooldown", true, 30)
    game.Audio.SetBanterFact("FightStartCD", true, 10)
    local banditSpawner = parentObj:FindSingleGOByName("banditCoffinSpawn")
    local bandit = banditSpawner.LuaObjectScript.GetLastEnemy()
    if bandit == nil then
      bandit = banditSpawner.LuaObjectScript.SpawnEnemy()
      bandit:SetAIDeathCallback(thisObj, "TrapChestSoftSave")
    end
    local slaveTable = {
      {player, branchName},
      {bandit, branchName}
    }
    LD.PlayApproach_GroupSync(parentObj, slaveTable, "envContainerCoffinTrap", true, "synchJoint", {completion_percentage = completion_percentage})
  else
    local weaponMode
    if chestType == "Common" and player:GetCurrentWeapon() == "Axe" then
      weaponMode = "Axe"
    end
    LD.PlaySingleSynchMove_KratosObject(parentObj, "synchJoint", interactionName, branchName, animName, interactZone, true, weaponMode, {completion_percentage = completion_percentage})
  end
  if chestType == "Common" then
    game.Camera.Recenter({
      TimeStart = 0,
      TimeDuration = 2,
      LockRecenter = 0,
      YawRange = 0,
      TriggerLeft = 0,
      TriggerRight = 0,
      ReturnLeft = 0,
      ReturnRight = 0,
      PitchRange = 0,
      ReturnUp = -8,
      ReturnDown = -8
    })
  else
    game.Camera.Recenter({
      TimeStart = 0,
      TimeDuration = 2,
      LockRecenter = 1,
      YawRange = 0,
      TriggerLeft = 0,
      TriggerRight = 0,
      ReturnLeft = 0,
      ReturnRight = 0,
      PitchRange = 0,
      ReturnUp = -8,
      ReturnDown = -8
    })
  end
  if game.Loot.AlertChestOpened then
    game.Loot.AlertChestOpened()
  end
  FireOnInteractStartCallbacks()
end
function TrapChestSoftSave()
  game.SubObject.SoftSave(thisObj)
end
function OnInteractAbort(level, obj, creature)
end
function OnInteractFinish(level, obj, creature)
  StopSoundChestIdle()
end
function CustomHook()
  if typeSpecificCallbacks.CustomHook then
    typeSpecificCallbacks.CustomHook()
  end
end
function OnInteractDone()
  uiCalls_LoadLibrary()
  uiCalls.UI_Global_Menu_Clear_Exclusive_Access("GlobalInWorldMenu")
end
function LuaHook_HideIdleFX()
  idleFX:Hide()
  if chestType == "Dispell" then
    StopSoundChestIdle()
  end
end
function OnOpened()
  Disable()
  if lootObject and not trapChest then
    lootObject:ShowModel()
    LD.ShowFX(lootObject)
  end
  SpawnOpenFX()
  state = states.OPENED
  if onOpenedEvent ~= nil then
    LD.ExecuteCallbacksForEvent(thisLevel, thisObj, onOpenedEvent, "onOpenedEvent")
  end
  if typeSpecificCallbacks.OnOpened then
    typeSpecificCallbacks.OnOpened()
  end
  if chestType == "Legendary" then
    local found, currentRegion = game.Map.FindPlayerRegion()
    local comparisonString = LD.RegionInfo_GetName(currentRegion)
    if found and comparisonString ~= "TyrsVault" and comparisonString ~= "TheHallofTyr" then
      UpdateRegionSummary(currentRegion, "LegendaryChest")
    elseif found and comparisonString == "TyrsVault" then
      LD.ActivateAndIncrementQuest("RegionSummary_LegendaryChest_Parent_TyrsVault")
    elseif found and comparisonString == "TheHallofTyr" then
      LD.ActivateAndIncrementQuest("RegionSummary_LegendaryChest_Parent_TheHallofTyr")
    else
      print("RegionSummary Check: no region found for player")
    end
  end
  if chestType == "Runic_Axe" or chestType == "Runic_Blades" then
    local found, currentRegion = game.Map.FindPlayerRegion()
    local comparisonString = LD.RegionInfo_GetName(currentRegion)
    if found and comparisonString ~= "TyrsVault" then
      UpdateRegionSummary(currentRegion, "RunicChest")
    elseif found and comparisonString == "TyrsVault" then
      LD.ActivateAndIncrementQuest("RegionSummary_RunicChest_Parent_TyrsVault")
    else
      print("RegionSummary Check: no region found for player")
    end
    if game.Loot.AlertTripleChestOpened ~= nil then
      game.Loot.AlertTripleChestOpened()
    end
  end
  if chestType == "Coffin" and not trapChest then
    game.Audio.PlayBanterNonCritical("ca_first_coffin", nil, nil, false)
  end
  if not trapChest then
    PlayLootIdleSound()
  end
end
function UpdateRegionSummary(regionID, categoryName)
  local regionStringName = LD.RegionInfo_GetName(regionID)
  local regionSummaryInfo = game.Map.GetRegionSummaryInfo(regionID)
  for _, summaryInfo in ipairs(regionSummaryInfo) do
    local categoryID = summaryInfo.CategoryStr
    if categoryID ~= nil then
      if categoryID == categoryName then
        local regionQuest = tostring("RegionSummary_" .. categoryName .. "_Parent_" .. regionStringName)
        print("DOING LEGENDARY QUEST....", regionQuest)
        LD.ActivateAndIncrementQuest(regionQuest)
      end
    else
      print("string value not present")
    end
  end
end
function PickUp()
  if lootObject then
    LD.HideFX(lootObject)
  end
  if typeSpecificCallbacks.PickUp then
    typeSpecificCallbacks.PickUp()
  end
  PlayLootPickupSound()
end
function AwardLoot()
  uiCalls_LoadLibrary()
  uiCalls.UI_Global_Menu_Set_Exclusive_Access("GlobalInWorldMenu")
  local resourceTestTable = PreAwardResourceTest()
  if lootObjectName == "Custom_MimirsEye" then
    if typeSpecificCallbacks.AwardLoot then
      typeSpecificCallbacks.AwardLoot()
    end
    PostAwardResourceTest(resourceTestTable)
    return
  end
  if lootObjectName == "Custom_HammerQuest" then
    game.Wallets.AddResource("HERO", "AndvarisHammer", 1, "Quest")
    return
  end
  LD.RollContainerConditionLoot(reward, rewardTier, WADName, rewardTierIndex)
  if typeSpecificCallbacks.AwardLoot then
    typeSpecificCallbacks.AwardLoot()
  end
  PostAwardResourceTest(resourceTestTable)
end
function PutAway()
  uiCalls_LoadLibrary()
  uiCalls.UI_Global_Menu_Clear_Exclusive_Access("GlobalInWorldMenu")
  if typeSpecificCallbacks.PutAway then
    typeSpecificCallbacks.PutAway()
  end
  CheckTutorialHint()
  if lootObject then
    StopLootIdleSound()
    lootObject:HideAudio()
    LD.HideFX(lootObject)
    lootObject:HideModel()
  end
  FireOnInteractFinishCallbacks()
  if interactionOnFinish ~= nil then
    LD.ExecuteCallbacksForEvent(thisLevel, thisObj, interactionOnFinish, "Interaction Event Finish")
  end
  if checkpointOnOpened then
    if checkpointOnOpened_Override ~= nil then
      if checkpointOnOpened_Override.IsRefNode then
        checkpointOnOpened_Override = checkpointOnOpened_Override.Child
      end
      game.World.StoreCheckpoint({OverrideObject = checkpointOnOpened_Override})
    else
      game.World.StoreCheckpoint()
    end
  else
    if game.SubObject.SoftSave then
      game.SubObject.SoftSave(thisObj)
    end
    if chestType == "Runic_Axe" or chestType == "Runic_Blades" then
      thisObj.Parent.Parent.LuaObjectScript.RunicSoftSave()
    end
  end
end
function DisableCheckpointRequirement()
  checkpointRequirementDisabled = true
end
function OnSaveCheckpoint(level, obj)
  return {state = state}
end
function OnRestoreCheckpoint(level, obj, savedInfo)
  state = savedInfo.state
end
function AwardTrophy()
  print("Trophy Awarded: Trilingual")
  game.UnlockTrophy(14)
end
function Enable()
  if state ~= states.OPENED then
    state = states.ENABLED
    interactZone:Enable()
    LD.ShowFX(idleFX)
    PlaySoundChestIdle()
  end
end
function Disable()
  if state ~= states.OPENED then
    state = states.DISABLED
  end
  interactZone:Disable()
  LD.HideFX(idleFX)
end
function LockChest()
  state = states.LOCKED
  interactZone:Lock()
  LD.HideFX(idleFX)
  StopSoundChestIdle()
end
function UnlockChest()
  state = states.ENABLED
  interactZone:Unlock()
  LD.ShowFX(idleFX)
  PlaySoundChestIdle()
end
function ForceStateDisabled()
  state = states.DISABLED
end
function Reset()
  state = states.ENABLED
  interactZone:Unlock()
  interactZone:Enable()
  LD.ShowFX(idleFX)
  ResetLootObjectLocation()
  LD.HideFX(lootObject)
  if chestType == "Common" then
    local breakableLid = parentObj:FindSingleGOByName("animatedLid")
    if breakableLid then
      breakableLid:JumpAnimToFrame(0)
      breakableLid:PauseAnim()
      LD.HideFX(breakableLid)
    end
  end
  if animName ~= nil and animName ~= "" then
    parentObj:StartAnim(animName)
  end
  parentObj:JumpAnimToFrame(0)
  parentObj:PauseAnim()
end
function HideChest()
  Disable()
  parentObj:HideModel()
  parentObj:HideCollision()
  parentObj:HideNavObstacle()
  idleFX:Hide()
  lootObject:HideModel()
  LD.HideFX(lootObject)
  if chestType == "Common" then
    local breakableLid = parentObj:FindSingleGOByName("animatedLid")
    if breakableLid then
      breakableLid:HideModel()
      breakableLid:HideCollision()
    end
  end
end
function ShowChest(hideIdleFx)
  parentObj:ShowModel()
  parentObj:ShowCollision()
  parentObj:ShowNavObstacle()
  ResetLootObjectLocation()
  LD.HideFX(lootObject)
  if state ~= states.OPENED and not hideIdleFx then
    idleFX:Show()
  end
  if chestType == "Common" then
    local breakableLid = parentObj:FindSingleGOByName("animatedLid")
    if breakableLid then
      breakableLid:ShowModel()
      breakableLid:ShowCollision()
    end
  end
end
function ResetLootObjectLocation()
  local lootObjJoint = parentObj:FindJointIndex("lootObjLocation")
  if lootObjJoint then
    lootObject:SetWorldPosition(parentObj:GetWorldJointPosition(lootObjJoint))
    lootObject:SetWorldFacing(parentObj:GetWorldJointForward(lootObjJoint))
  end
end
function IsOpen()
  return state == states.OPENED
end
function GetState()
  return state
end
function GetPossibleStates()
  return states
end
function CheckTutorialHint()
  if reward == "StartingTrinketReward" then
    local showHint = LD.GetEntityVariable("TUT_ShowTrinketTutorialHint")
    if showHint == true then
      TUT_LoadLibrary()
      TUT.ArmorTrinkets_Tutorial()
      LD.SetEntityVariable("TUT_ShowTrinketTutorialHint", false)
    end
  elseif reward == "StartingWristArmorReward" then
    local showHint = LD.GetEntityVariable("TUT_ShowWristArmorTutorialHint")
    if showHint == true then
      TUT_LoadLibrary()
      TUT.WristArmor_Tutorial()
      LD.SetEntityVariable("TUT_ShowWristArmorTutorialHint", false)
    end
  elseif reward == "StartingWaistArmorReward" then
    local showHint = LD.GetEntityVariable("TUT_ShowWaistArmorTutorialHint")
    if showHint == true then
      TUT_LoadLibrary()
      TUT.WaistArmor_Tutorial()
      LD.SetEntityVariable("TUT_ShowWaistArmorTutorialHint", false)
    end
  elseif reward == "XP_Reward_VerySmall" or reward == "XP_Reward_Small" or reward == "XP_Reward_Medium" or reward == "XP_Reward_Large" or reward == "XP_Reward_VeryLarge" then
    local showHint = LD.GetEntityVariable("TUT_ShowXPTutorialHint")
    if showHint == true then
      TUT_LoadLibrary()
      TUT.WaistArmor_Tutorial()
      LD.SetEntityVariable("TUT_ShowXPTutorialHint", false)
    end
  elseif reward == "FrostSpecialAxeFlurryChopReward" then
    local showHint = LD.GetEntityVariable("TUT_ShowWeaponGemTutorialHint")
    if showHint == true then
      LD.SetEntityVariable("TUT_ShowWeaponGemTutorialHint", false)
    end
  else
    local showHint = LD.GetEntityVariable("TUT_ShowResourceTutorialHint")
    if showHint == true then
      TUT_LoadLibrary()
      TUT.CollectResources_Tutorial()
      LD.SetEntityVariable("TUT_ShowResourceTutorialHint", false)
    end
  end
end
function CommonChestBroken()
  if typeSpecificData.breakableObject then
    typeSpecificData.breakableObject:PlayAnimToEnd()
    LD.ShowFX(typeSpecificData.breakableObject)
  end
  LD.HideFX(idleFX)
  SpawnOpenFX()
  PlaySoundBreakCommonChest()
end
function SpawnOpenFX()
  if openFX then
    game.FX.Spawn(openFX, nil, {
      AutoDelete = true,
      GameObject = parentObj,
      Joint = "synchJoint"
    })
  end
end
function OnFXMeshDone()
  typeSpecificData.FX_Mesh:JumpAnimToFrame(50)
  typeSpecificData.FX_Mesh:PlayAnimToFrame(650)
  typeSpecificData.FX_Mesh:OnAnimDone(thisObj, "OnFXMeshDone")
end
function OnFXMeshInnerDone()
  typeSpecificData.FX_Inner:JumpAnimToFrame(50)
  typeSpecificData.FX_Inner:PlayAnimToFrame(650)
  typeSpecificData.FX_Inner:OnAnimDone(thisObj, "OnFXMeshInnerDone")
end
function PreAwardResourceTest()
  local result = {}
  result.NifTankArmor_Chest_Pattern = game.Wallets.GetResourceValue("HERO", "NifTankArmor_Chest_Pattern")
  result.MaxHealthUpgradePiece = game.Wallets.GetResourceValue("HERO", "MaxHealthUpgradePiece")
  result.MaxRageUpgradePiece = game.Wallets.GetResourceValue("HERO", "MaxRageUpgradePiece")
  result.MaxHealthUpgrade = game.Wallets.GetResourceValue("HERO", "MaxHealthUpgrade")
  result.MaxRageUpgrade = game.Wallets.GetResourceValue("HERO", "MaxRageUpgrade")
  return result
end
function PostAwardResourceTest(resourceTestTable)
  local nifArmorPattern_Chest = game.Wallets.GetResourceValue("HERO", "NifTankArmor_Chest_Pattern") > resourceTestTable.NifTankArmor_Chest_Pattern
  local MaxHealthUpgradePiece = game.Wallets.GetResourceValue("HERO", "MaxHealthUpgradePiece") > resourceTestTable.MaxHealthUpgradePiece
  local MaxRageUpgradePiece = game.Wallets.GetResourceValue("HERO", "MaxRageUpgradePiece") > resourceTestTable.MaxRageUpgradePiece
  local MaxHealthUpgrade = game.Wallets.GetResourceValue("HERO", "MaxHealthUpgrade") > resourceTestTable.MaxHealthUpgrade
  local MaxRageUpgrade = game.Wallets.GetResourceValue("HERO", "MaxRageUpgrade") > resourceTestTable.MaxRageUpgrade
  if nifArmorPattern_Chest then
    game.Audio.PlayBanter("Niflheim_Armor_Quest")
    LD.ActivateQuest("Quest_NiflheimArmorChest_Parent")
    LD.CompleteQuest("Quest_NiflheimArmorChest_01")
    game.SubObject.SoftSave(thisObj)
  end
  if MaxHealthUpgradePiece or MaxHealthUpgrade then
    player:MeterSetValue("Health", player:MeterGetMax("Health"))
  end
  if MaxRageUpgradePiece or MaxRageUpgrade then
    player:MeterSetValue("Blood", player:MeterGetMax("Blood"))
  end
end
function RefreshRageMeter()
  uiCalls_LoadLibrary()
  uiCalls.UI_Refresh_HUD()
  print(player:MeterGetMax("Blood"))
  print("Rage meter refreshed.")
end
function RegisterOnInteractStartCallback(fn)
  if not checkpointOnOpened and not checkpointRequirementDisabled then
    engine.Warning("Chest Error - " .. LD.GetParentTrace(thisObj) .. " has a callback, but isn't set to save a checkpoint. Check the 'CheckpointOnOpened' option in the toolbox to ensure the chest saves correctly")
  end
  if onInteractStartCallbacks == nil then
    onInteractStartCallbacks = {}
  end
  onInteractStartCallbacks[#onInteractStartCallbacks + 1] = fn
end
function FireOnInteractStartCallbacks()
  if onInteractStartCallbacks ~= nil then
    for _, fn in pairs(onInteractStartCallbacks) do
      fn()
    end
  end
end
function RegisterOnInteractFinishCallback(fn)
  if not checkpointOnOpened and not checkpointRequirementDisabled then
    engine.Warning("Chest Error - " .. LD.GetParentTrace(thisObj) .. " has a callback, but isn't set to save a checkpoint. Check the 'CheckpointOnOpened' option in the toolbox to ensure the chest saves correctly")
  end
  if onInteractFinishCallbacks == nil then
    onInteractFinishCallbacks = {}
  end
  onInteractFinishCallbacks[#onInteractFinishCallbacks + 1] = fn
end
function FireOnInteractFinishCallbacks()
  if onInteractFinishCallbacks ~= nil then
    for _, fn in pairs(onInteractFinishCallbacks) do
      fn()
    end
  end
end
local chestSoundEmitter
local chestSoundEvents = {
  Common_IdleLoop = "SND_LOOT_Chest_Wood_Idle_LP",
  Common_OnBreak = "SND_LOOT_Chest_Wood_Open",
  Coffin_IdleLoop = "SND_LOOT_Chest_Wood_Idle_LP",
  Legendary_Gold_IdleLoop = "SND_LOOT_Chest_Gold_Idle_LP",
  Legendary_Runic_IdleLoop = "SND_LOOT_Chest_Legendary_Idle_LP",
  Dispell_IdleLoop = "SND_MAG_Dispel_Barrier_Small_LP",
  Hive_IdleLoop = "SND_LOOT_Chest_Hive_Idle_LP",
  Rune_Appear = "SND_LOOT_Chest_Legendary_Letters",
  Rune_Disappear = "SND_LOOT_Chest_Legendary_Letters"
}
local lootSoundEvents = {
  OnPickUp = "SND_CHR_Kratos_Foley_Item_Pickup_Generic",
  Common_Idle = "SND_LOOT_Shard_White_LP",
  Rare_Idle = "SND_LOOT_Shard_Blue_Idle_LP",
  Legendary_Idle = "SND_LOOT_Shard_Purple_Idle_LP",
  Custom_HammerQuest_Idle = "SND_LOOT_Shard_Orange_LP",
  Custom_MimirsEye_Idle = "SND_LOOT_Shard_Orange_LP"
}
function SoundInit()
  chestSoundEmitter = thisObj:FindSingleSoundEmitterByName("SNDChestSoundEmitter")
end
function SoundSetup(sounds)
  if sounds ~= nil then
    if sounds.SoundEmitter ~= nil then
      chestSoundEmitter = thisObj:FindSingleSoundEmitterByName(sounds.SoundEmitter)
    end
    for key in pairs(chestSoundEvents) do
      for newKey, newValue in pairs(sounds) do
        if newKey == key and newValue ~= nil and newValue ~= "" then
          chestSoundEvents[key] = newValue
        end
      end
      LD.SoundDebug(tostring(key) .. ": " .. tostring(chestSoundEvents[key]))
    end
  end
end
function PlaySoundChestIdle()
  if chestType == "Common" then
    LD.PlayRestartableSoundLoop(chestSoundEmitter, chestSoundEvents.Common_IdleLoop)
  elseif chestType == "Coffin" then
    LD.PlayRestartableSoundLoop(chestSoundEmitter, chestSoundEvents.Coffin_IdleLoop)
  elseif chestType == "Legendary" or chestType == "Custom_HammerQuest" or chestType == "Custom_MimirsEye" then
    LD.PlayRestartableSoundLoop(chestSoundEmitter, chestSoundEvents.Legendary_Gold_IdleLoop)
  elseif chestType == "Runic_Axe" or chestType == "Runic_Blades" then
    LD.PlayRestartableSoundLoop(chestSoundEmitter, chestSoundEvents.Legendary_Runic_IdleLoop)
  elseif chestType == "Dispell" then
    LD.PlayRestartableSoundLoop(chestSoundEmitter, chestSoundEvents.Dispell_IdleLoop)
  else
    LD.PlayRestartableSoundLoop(chestSoundEmitter, chestSoundEvents.Common_IdleLoop)
  end
end
function StopSoundChestIdle()
  if chestType == "Common" then
    LD.StopRestartableSoundLoop(chestSoundEmitter, chestSoundEvents.Common_IdleLoop)
  elseif chestType == "Coffin" then
    LD.StopRestartableSoundLoop(chestSoundEmitter, chestSoundEvents.Coffin_IdleLoop)
  elseif chestType == "Legendary" or chestType == "Custom_HammerQuest" or chestType == "Custom_MimirsEye" then
    LD.StopRestartableSoundLoop(chestSoundEmitter, chestSoundEvents.Legendary_Gold_IdleLoop)
  elseif chestType == "Runic_Axe" or chestType == "Runic_Blades" then
    LD.StopRestartableSoundLoop(chestSoundEmitter, chestSoundEvents.Legendary_Runic_IdleLoop)
  elseif chestType == "Dispell" then
    LD.StopRestartableSoundLoop(chestSoundEmitter, chestSoundEvents.Dispell_IdleLoop)
  else
    LD.StopRestartableSoundLoop(chestSoundEmitter, chestSoundEvents.Common_IdleLoop)
  end
end
function PlaySoundBreakCommonChest()
  LD.PlaySound(chestSoundEmitter, chestSoundEvents.Common_OnBreak)
end
function PlaySoundChestIdle_Roots()
  StopSoundChestIdle()
  LD.PlayRestartableSoundLoop(chestSoundEmitter, chestSoundEvents.Hive_IdleLoop)
end
function StopSoundChestIdle_Roots()
  LD.StopRestartableSoundLoop(chestSoundEmitter, chestSoundEvents.Hive_IdleLoop)
end
function PlaySoundRuneAppear()
  LD.PlaySound(chestSoundEmitter, chestSoundEvents.Rune_Appear)
end
function PlaySoundRuneDisappear()
  LD.PlaySound(chestSoundEmitter, chestSoundEvents.Rune_Disappear)
end
function PlayLootIdleSound()
  if lootObject then
    local lootSoundEmitter = lootObject.SoundEmitters[1]
    if lootObjectName ~= nil then
      local lootObjectNameForTagging = string.upper(lootObjectName)
      if string.find(lootObjectNameForTagging, "COMMON") then
        LD.PlaySound(lootSoundEmitter, lootSoundEvents.Common_Idle)
      elseif string.find(lootObjectNameForTagging, "RARE") then
        LD.PlaySound(lootSoundEmitter, lootSoundEvents.Rare_Idle)
      elseif string.find(lootObjectNameForTagging, "LEGENDARY") then
        LD.PlaySound(lootSoundEmitter, lootSoundEvents.Legendary_Idle)
      elseif string.find(lootObjectNameForTagging, "CUSTOM_HAMMER") then
        LD.PlaySound(lootSoundEmitter, lootSoundEvents.Custom_HammerQuest_Idle)
      elseif string.find(lootObjectNameForTagging, "CUSTOM_MIMIR") then
        LD.PlaySound(lootSoundEmitter, lootSoundEvents.Custom_MimirsEye_Idle)
      else
        LD.PlaySound(lootSoundEmitter, lootSoundEvents.Common_Idle)
      end
    else
      LD.PlaySound(lootSoundEmitter, lootSoundEvents.Common_Idle)
    end
  end
end
function StopLootIdleSound()
  if lootObject then
    local lootSoundEmitter = lootObject.SoundEmitters[1]
    if lootObjectName ~= nil then
      local lootObjectNameForTagging = string.upper(lootObjectName)
      if string.find(lootObjectNameForTagging, "COMMON") then
        LD.StopSound(lootSoundEmitter, lootSoundEvents.Common_Idle)
      elseif string.find(lootObjectNameForTagging, "RARE") then
        LD.StopSound(lootSoundEmitter, lootSoundEvents.Rare_Idle)
      elseif string.find(lootObjectNameForTagging, "LEGENDARY") then
        LD.StopSound(lootSoundEmitter, lootSoundEvents.Legendary_Idle)
      elseif string.find(lootObjectNameForTagging, "CUSTOM_HAMMER") then
        LD.StopSound(lootSoundEmitter, lootSoundEvents.Custom_HammerQuest_Idle)
      elseif string.find(lootObjectNameForTagging, "CUSTOM_MIMIR") then
        LD.StopSound(lootSoundEmitter, lootSoundEvents.Custom_MimirsEye_Idle)
      else
        LD.StopSound(lootSoundEmitter, lootSoundEvents.Common_Idle)
      end
    else
      LD.StopSound(lootSoundEmitter, lootSoundEvents.Common_Idle)
    end
  end
end
function PlayLootPickupSound()
  LD.PlaySound(player:FindSingleSoundEmitterByName("SNDLeftHand"), lootSoundEvents.OnPickUp)
end

-- Observe reward chest opening. The runic puzzle parent can remain ENABLED.
do
  local function key()
    if thisLevel == nil or parentObj == nil or
        type(thisLevel.Name) ~= "string" then return nil end
    local refs = {}
    for index = 1, 3 do
      local ref = parentObj:FindLuaTableAttribute("sealBreakable0" .. tostring(index))
      if type(ref) ~= "string" or ref == "" or string.find(ref, "|", 1, true) then
        return nil
      end
      refs[index] = string.lower(ref)
    end
    table.sort(refs)
    return string.lower(thisLevel.Name) .. "|" .. table.concat(refs, "|")
  end

  local function publish()
    if chestType ~= "Runic_Axe" and chestType ~= "Runic_Blades" then return end
    local identity = key()
    if identity == nil then return end
    local payload = "NORNIR_V1\topened\t" .. identity .. "\t"
    local ok = pcall(function()
      engine.SendHook("COMPLETIONIST_NORNIR_EVENT_V1", engine.GetUIWad(), payload)
    end)
    print("[CompletionistMapV105Nornir] event=opened key=" .. identity ..
      " delivered=" .. tostring(ok))
  end

  local stockOpened = OnOpened
  function OnOpened(...)
    local result = stockOpened(...)
    publish()
    return result
  end

  local stockStart = OnStart
  function OnStart(...)
    local wasOpened = state == states.OPENED
    local result = stockStart(...)
    if wasOpened then publish() end
    return result
  end
end

-- BEGIN COMPLETIONIST COLLECTIBLE OBSERVATION
do
  function CompletionistCollectibleObserve()
    if type(state) ~= "number" or state < 1 or state > 4 or state ~= math.floor(state) then return nil end
    local collected = state == 4
    return "chest", collected and "collected" or "remaining"
  end
  local function clearActiveCompassMarker()
    pcall(function()
      if type(game) == "table" and type(game.Compass) == "table" and type(game.Compass.FindMarkersByIconClass) == "function" then
        local markers = game.Compass.FindMarkersByIconClass({"SIDE"})
        if type(markers) == "table" then
          for _, id in ipairs(markers) do
            pcall(game.Compass.HideMarker, id)
          end
        end
      end
    end)
  end
  local function notify()
    if state == states.OPENED then
      clearActiveCompassMarker()
    end
    if thisLevel == nil or type(thisLevel.Name) ~= "string" then return end
    engine.SendHook("COMPLETIONIST_COLLECTIBLE_DIRTY_V1", engine.GetUIWad(),
      "COLLECTIBLE_DIRTY_V1	" .. string.lower(thisLevel.Name))
  end
  local function pack(...) return {n=select('#',...), ...} end
  local unpackValues = unpack or table.unpack
  local function wrap(original)
    return function(...)
      local result = pack(original(...))
      pcall(notify)
      return unpackValues(result, 1, result.n)
    end
  end
  if type(OnOpened) == "function" then OnOpened = wrap(OnOpened) end
  if type(OnStart) == "function" then OnStart = wrap(OnStart) end
  if type(OnRestoreCheckpoint) == "function" then OnRestoreCheckpoint = wrap(OnRestoreCheckpoint) end
end
-- END COMPLETIONIST COLLECTIBLE OBSERVATION
-- BEGIN COMPLETIONIST PROXIMITY V1.1.0
-- Shows the game's native interact hint dot on this collectible out to the
-- map's [Up Arrow] range. Append-only: OnScriptLoaded runs unchanged first;
-- every call below is pcall-guarded.
do
  local probeRows = {
    {"alf340_trenchbdark", "legendary_chest", "legendary_chest_c14a0f2b4559d859347854bccb307f63", 3, "chestscript", "chest_legendary_parent", "chest_legendary_tier1_alf340_1"},
    {"xpl980_beachwaterfall", "legendary_chest", "legendary_chest_50480b3a40fe25c4770f81a7261cbcb8", 6, "chestscript", "chest_legendary_parent", "chest_legendary_tier1_xpl980_1"},
    {"riv925_freyacave", "legendary_chest", "legendary_chest_36cb588e41cb27a4668052b4529b98a6", 8, "chestscript", "chest_legendary_parent", "chest_legendary_tier1_riv925_3"},
    {"peak740_summitpeak", "wooden_chest", "wooden_chest_a64da46f0ee1e4a1c4f1b4144c88b3eb", 9, "chest_common_parent", "chest_common_tier3_peak740_2"},
    {"xpl100_httk", "coffin", "coffin_514bb8121cc05fa714e491ef162eed3f", 11, "coffin_parent", "cfn_q1_ambush"},
    {"riv925_freyacave", "legendary_chest", "legendary_chest_ae9454d54e9c9a23f21941b41a4038d3", 12, "chestscript", "chest_legendary_parent", "chest_legendary_tier1_riv925_2"},
    {"xpl980_beachwaterfall", "legendary_chest", "legendary_chest_ace99ef5472abcbac29bd2b396a3fdf3", 13, "chestscript", "chest_legendary_parent", "chestobj", "chest_legendary_locked_roots_parent", "chest_legendary_tier3_xpl980_2"},
    {"helr100_docks", "legendary_chest", "legendary_chest_8266c175474b43a4d44938a75e21329d", 14, "chestscript", "chest_legendary_parent", "chest_legendary_tier4_helr100_1"},
    {"stn800_shortcut", "coffin", "coffin_e0e1c7e7bc737efbfacef065908c43d0", 15, "coffin_parent", "chestobj"},
    {"alf600_templeint", "wooden_chest", "wooden_chest_8f8823453060e8adbfbf26f01baa3427", 16, "chest_common_parent", "chest_common_tier1_alf600_1"},
    {"cal100_hub", "legendary_chest", "legendary_chest_5b424870484e691ce32d19be71a03059", 17, "chestscript", "chest_legendary_parent", "chest_legendary_tier4_cal100_1"},
    {"xpl400_huldramines", "coffin", "coffin_5240a7be264002acbff660741e1607ef", 19, "coffin_parent", "coffin_tier3_xpl400_1"},
    {"xpl970_beachtower", "cipher_chest", "cipher_chest_64d0d4b3bf836bbdca27451d720152f8", 20, "chest_dispell_parent", "chest_dispell_tier1_cal200_1"},
    {"peak210_rollerroomlh", "coffin", "coffin_524f412c218f69b5d6fd2b4ace6be1fb", 21, "coffin_parent", "coffin_tier3_peak210_1"},
    {"riv200_dangersmain", "wooden_chest", "wooden_chest_c3065d265dcac89c3b807a1121f459ea", 22, "chest_common_parent", "riv200_cbt"},
    {"stn200_lakeext", "coffin", "coffin_00d1d9586170eb2458c9304285d70c2b", 24, "coffin_parent", "coffin_tier3_stn100_1"},
    {"hel600_guardianarena", "wooden_chest", "wooden_chest_fa54db89fddd352b2984a348dd33ada1", 25, "chest_common_parent", "chest_common_tier4_hel600_1"},
    {"helr100_docks", "coffin", "coffin_d1bfdaff128036c426e567b41358c072", 30, "coffin_parent", "coffin_tier4_helr100_1"},
    {"xpl400_huldramines", "coffin", "coffin_78d857a21516770d19e10a59f5a76335", 31, "coffin_parent", "coffin_tier2_xpl400_1"},
    {"peak720_summitascenthub", "coffin", "coffin_575a07cc7dca64c540088be3f4139842", 32, "coffin_parent", "chestobj"},
    {"peak720_summitascenthub", "legendary_chest", "legendary_chest_d63295f244f330219b003c913c0dab69", 34, "chestscript", "chest_legendary_parent", "chestobj", "chest_legendary_locked_roots_parent", "chest_legendary_tier3_peak720_1"},
    {"foot250_chiselarena", "wooden_chest", "wooden_chest_d753ce063ba2187aaf6ce654558de5c6", 38, "chest_common_parent", "chest_common_tier1_foot250_1"},
    {"helr100_docks", "coffin", "coffin_265ee0bf74ea46d94e2271778008959e", 40, "coffin_parent", "coffin_tier4_helr100_3"},
    {"peak200_chimneylow", "coffin", "coffin_f7c85deadc9605c7a4dde328c9d916b1", 41, "coffin_parent", "coffin_tier4_peak200_1"},
    {"xpl100_httk", "coffin", "coffin_7261934c1430c94f92e2ba079fed8c3c", 42, "coffin_parent", "coffin_tier6_xpl100_1"},
    {"riv975_chiselarena", "wooden_chest", "wooden_chest_765e2894cba2c865774bff371c57a91d", 44, "chest_common_parent", "chest_common_tier1_riv975_2"},
    {"peak180_enttochimneylh", "coffin", "coffin_68e0db213e0e075b272fe88aa8d49f54", 46, "coffin_parent", "coffin_tier3_peak180_1"},
    {"xpl475_huldramineslh", "wooden_chest", "wooden_chest_844dbdd31fe6dc2fb08087399b65f67b", 47, "chest_common_parent", "chest_common_tier2_xpl475_1"},
    {"hel300_mainbridge", "coffin", "coffin_793530dd17ca89215ba5d26f7357b8aa", 48, "coffin_parent", "coffin_tier4_hel300_1"},
    {"riv325_dangersexit", "wooden_chest", "wooden_chest_471003f756043c7046d03da4a1c65372", 49, "chest_common_parent", "chest_common_tier1_riv325_1"},
    {"hel300_mainbridge", "wooden_chest", "wooden_chest_b6c25a3f683631668b90e34378276b82", 50, "chest_common_parent", "bramble_chest_hel300"},
    {"stn430_hammerclimb", "coffin", "coffin_2b80e842d459585947380fe4c7415e0f", 52, "coffin_parent", "coffin_tier3_stn430_2"},
    {"riv925_freyacave", "coffin", "coffin_49c66a6e387cfdaaa98e4b2afdf7b1d3", 54, "coffin_parent", "coffin_tier1_riv925_3"},
    {"xpl920_islandclimb", "wooden_chest", "wooden_chest_cbb47d1bd72b169725ff3d03a4af9282", 55, "chest_common_parent", "chest_common_tier4_xpl920_1"},
    {"helr100_docks", "coffin", "coffin_c289f1218e664d7edf073b93a0cc55f8", 56, "coffin_parent", "coffin_tier4_helr100_5"},
    {"xpl960_beachship", "coffin", "coffin_3dceee4444defddd165bf4929207c58f", 57, "coffin_parent", "coffin_tier3_xpl960_1"},
    {"foot100_base", "coffin", "coffin_c439b69d88a1f2195464c303b8d65e30", 59, "coffin_parent", "coffin_tier1_foot100_1"},
    {"alf355_chiseldungeon", "coffin", "coffin_742ff8d25ea20efe745ec677e3c21d45", 60, "coffin_parent", "coffin_tier1_alf355_1"},
    {"for550_brokenforest", "wooden_chest", "wooden_chest_ef35baf6c74c4cd48702005838cd186e", 61, "chest_common_parent", "chest_common_tier1_for550_1"},
    {"foot500_top", "coffin", "coffin_dbc446d3cdc8af11b26294ada4bf2c9c", 62, "coffin_parent", "chestobj"},
    {"hel100_calderaheldressing", "legendary_chest", "legendary_chest_5618d560426940a02e5b39a340c0c209", 63, "chestscript", "chest_legendary_parent", "chest_legendary_tier4_hel100_2"},
    {"xpl100_httk", "legendary_chest", "legendary_chest_890a24d24d2864a1567af691c615870f", 64, "chestscript", "chest_legendary_parent", "chest_legendary_tier5_xpl100_2"},
    {"for660_templeinterior", "coffin", "coffin_def02bc17b1bb0246e28fded510dccf2", 65, "coffin_parent", "coffin_tier1_for660_1"},
    {"riv200_dangersmain", "coffin", "coffin_f1f9d33e14c532dcec5e55b7e735ca19", 66, "coffin_parent", "coffin_tier1_riv200_2"},
    {"foot100_base", "coffin", "coffin_744b86cb488721d7190188084d7dc635", 67, "coffin_parent", "coffin_tier1_foot100_2"},
    {"peak120_cavescarelh", "coffin", "coffin_07014abc15905dbf2b905d543b85abfe", 68, "coffin_parent", "coffin_tier3_peak120_1"},
    {"xpl960_beachship", "coffin", "coffin_66d5de24a634f6acd7490fe2f02bc871", 69, "coffin_parent", "coffin_tier3_xpl960_3"},
    {"cal820_snakebellymid", "wooden_chest", "wooden_chest_66a6a9d412a0ec0fadc2deca89c8dbf2", 70, "chest_common_parent", "chest_common_tier5_cal820_1"},
    {"xpl450_huldramines", "wooden_chest", "wooden_chest_794573030ab6d881e84137e829ac9ae8", 73, "chest_common_parent", "chest_common_tier2_xpl450_1"},
    {"peak100_entrance", "wooden_chest", "wooden_chest_75ca91755fa5f614d3fadf9a08438fb2", 77, "chest_common_parent", "chest_common_tier3_peak100_1"},
    {"xpl950_beachmaze", "wooden_chest", "wooden_chest_693971af27e4bc2ec41d2f726a42bcbb", 79, "chest_common_parent", "chest_common_tier4_xpl950_1"},
    {"peak300_chimneymid", "wooden_chest", "wooden_chest_c29bba3fbdf1a9d6e75049d29457decf", 80, "chest_common_parent", "chest_common_tier3_peak300_1"},
    {"xpl450_huldramines", "coffin", "coffin_aaaf95f673179f035c1e67f568f08107", 81, "coffin_parent", "coffin_tier5_xpl450_1"},
    {"foot100_base", "wooden_chest", "wooden_chest_d7eadb5de53b3584728f114bdd9a26d2", 85, "chest_common_parent", "chest_common_tier1_foot100_1"},
    {"peak190_chimneyenter", "wooden_chest", "wooden_chest_5a8b57e2e6ed25b4d95144d451fbfb5d", 86, "chest_common_parent", "chest_common_tier3_peak190_1"},
    {"alf345_trenchbdarktwr", "wooden_chest", "wooden_chest_6930ffe1cf86b6c7c705abebba9774c6", 87, "chest_common_parent", "chest_common_tier1_alf345_1"},
    {"xpl910_islandshipwreck", "legendary_chest", "legendary_chest_d6fb0fd64364453cc3e334a2454e0b75", 89, "chestscript", "chest_legendary_parent", "chest_legendary_tier3_xpl910_1"},
    {"foot500_top", "wooden_chest", "wooden_chest_d9336ed2d59cb4a9961eedd85044b193", 91, "chest_common_parent", "chest_common_tier5_foot500_1"},
    {"hel100_calderaheldressing", "wooden_chest", "wooden_chest_b4def36d6cf6253887e2d62acb8e931f", 92, "chest_common_parent", "chest_common_tier4_hel100_3"},
    {"peak210_rollerroomlh", "coffin", "coffin_8f470545b16b1e425d2fd5f47525bff1", 93, "coffin_parent", "coffin_tier3_peak210_2"},
    {"xpl940_beachcave", "wooden_chest", "wooden_chest_779f83a51f7aa40a5c86866d652cb766", 94, "chest_common_parent", "chest_common_tier2_xpl940_1"},
    {"xpl600_masontrail", "coffin", "coffin_cd8cfd54dfd050d5d4b60bd7ff08eb21", 95, "coffin_parent", "coffin_tier3_xpl600_1"},
    {"alf390_templeextlh", "coffin", "coffin_85531ced605effb9af1dad9009031dfd", 96, "coffin_parent", "hivecoffin_tier1_alf390_1"},
    {"riv420_forestboarstart", "wooden_chest", "wooden_chest_c7b27bc28ec7f67ef792e16997dbb5b4", 100, "chest_common_parent", "chest_common_tier1_riv420_1"},
    {"xpl940_beachcave", "wooden_chest", "wooden_chest_21ce00568c4f2f02e51a4fe20ea80030", 101, "chest_common_parent", "chest_common_tier2_xpl940_3"},
    {"xpl850_dungeonforest", "coffin", "coffin_ccc3e6b52c7ac6ccd3a6ac24aced6cfc", 102, "coffin_parent", "coffin_tier2_xpl850_1"},
    {"xpl950_beachmaze", "wooden_chest", "wooden_chest_1adba8510701fc2e921940af402eb450", 103, "chest_common_parent", "chest_common_tier3_xpl950_1"},
    {"xpl400_huldramines", "wooden_chest", "wooden_chest_5db52378a823a4c80828e0c927521dd3", 104, "chest_common_parent", "chest_common_tier3_xpl400_1"},
    {"peak205_chiselarena", "wooden_chest", "wooden_chest_bd68b87e6f2fa142ead9dbf282303da4", 105, "chest_common_parent", "chest_common_tier5_peak205_1"},
    {"riv430_forestboartrack", "wooden_chest", "wooden_chest_32d12c1505dcc72956b8b8cb27f928d1", 106, "chest_common_parent", "chest_common_tier1_riv430_1"},
    {"xpl650_masontrailcave", "wooden_chest", "wooden_chest_0e36e52e4173d490a9b3f8868c7782a0", 107, "chest_common_parent", "chest_common_tier3_xpl650_1"},
    {"riv975_chiselarena", "coffin", "coffin_abc058fb6e88938d0a43c94f13a7bffd", 108, "coffin_parent", "coffin_tier1_riv975_1"},
    {"stn200_lakeext", "legendary_chest", "legendary_chest_0e27df5f4bc5f2545a43178d0115312b", 111, "chestscript", "chest_legendary_parent", "chest_legendary_tier3_stn200_1"},
    {"xpl910_islandshipwreck", "legendary_chest", "legendary_chest_9c0dc602456a00fa44bca1a3b599cf67", 112, "chestscript", "chest_legendary_parent", "chest_legendary_tier4_xpl910_1"},
    {"xpl250_funeralinterior", "legendary_chest", "legendary_chest_d6d6acfe444f2ad10b49cea2ba85a1eb", 114, "chestscript", "chest_legendary_parent", "chest_legendary_tier2_xpl250_1"},
    {"xpl850_dungeonforest", "legendary_chest", "legendary_chest_7a71d104452e16e39a25bb8a14e47343", 117, "chestscript", "chest_legendary_parent", "chest_legendary_tier2_xpl850_2"},
    {"xpl250_funeralinterior", "coffin", "coffin_ebcc7fde6edd3347424493e2700fae89", 118, "coffin_parent", "coffin_tier2_xpl250_1"},
    {"stn600_chasmroom", "wooden_chest", "wooden_chest_6b0d3d9e239100c717236687da581bef", 119, "chest_common_parent", "chest_common_tier3_stn600_1"},
    {"riv925_freyacave", "cipher_chest", "cipher_chest_368ccc0e6d6636bc0c74043536071ef1", 125, "chest_dispell_parent", "riv925_drainchest"},
    {"stn200_lakeext", "wooden_chest", "wooden_chest_acf22956026eaf9efd34a12ef5ca22e2", 127, "chest_common_parent", "chest_common_tier3_stn200_2"},
    {"for260_chiseldungeon", "wooden_chest", "wooden_chest_5156a959c5b5a08a49303486b7d998cd", 128, "chest_common_parent", "chest_common_tier5_for260_1"},
    {"xpl450_huldramines", "wooden_chest", "wooden_chest_0e0ac7e313b7a70479ce4799c063e1b6", 129, "chest_common_parent", "chest_common_tier3_xpl450_2"},
    {"xpl980_beachwaterfall", "wooden_chest", "wooden_chest_f666f4ec08b715cf7e0862fa5d4d2a37", 130, "chest_common_parent", "chest_common_tier3_xpl980_1"},
    {"peak260_chimneylowhall", "wooden_chest", "wooden_chest_dbe63347daadc35034b614654d2e35a1", 131, "chest_common_parent", "chest_common_tier3_peak260_1"},
    {"xpl980_beachwaterfall", "wooden_chest", "wooden_chest_0bb016e6a10fa429fd92e7431244acf3", 135, "chest_common_parent", "chest_common_tier1_xpl980_1"},
    {"foot200_mid", "legendary_chest", "legendary_chest_510bd86441ac6a7b71d4f59321c2a08f", 136, "chestscript", "chest_legendary_parent", "chest_legendary_tier5_foot200_1"},
    {"riv430_forestboartrack", "wooden_chest", "wooden_chest_9cf64f1857fba5b156c819bb82eff1f8", 137, "chest_common_parent", "chest_common_tier1_riv430_2"},
    {"for400_intersection", "wooden_chest", "wooden_chest_78a1535551a9f6fc3d428be55e683d98", 138, "chest_common_parent", "chest_common_tier1_for400_1"},
    {"foot250_chiselarena", "wooden_chest", "wooden_chest_6415bc87e3cee7dc64ff87227be631dc", 139, "chest_common_parent", "chest_common_tier1_foot250_2"},
    {"xpl960_beachship", "wooden_chest", "wooden_chest_dfa557277d10a7a70b656a4620c56fda", 140, "chest_common_parent", "chest_common_tier3_xpl960_2"},
    {"cal500_runevault", "coffin", "coffin_1ec665d11dec0d4959f2fa6fe571a6cf", 141, "coffin_parent", "coffin_tier4_cal500_1"},
    {"xpl900_islandarch", "wooden_chest", "wooden_chest_3c854063b4cea27669211d35562b7a9e", 142, "chest_common_parent", "chest_common_tier3_xpl900_2"},
    {"xpl200_funeral", "wooden_chest", "wooden_chest_47d4448bcb8d2e3a3fde0f69672e1f1e", 144, "chest_common_parent", "chest_common_tier02"},
    {"riv100_dangersentrance", "legendary_chest", "legendary_chest_8aabd22a44df8f25a955fe8e04fc0d95", 145, "chestscript", "chest_legendary_parent", "chest_legendary_tier1_riv100_1"},
    {"xpl225_funerallh", "coffin", "coffin_5abb61ed22d5ef4e63d0fb21411fc797", 148, "coffin_parent", "coffin_tier1_xpl225_1"},
    {"xpl300_stronghold", "wooden_chest", "wooden_chest_c34cd12e6f6d9025df3fdc4fbe29433c", 149, "chest_common_parent", "chest_common_tier3_xpl300_2"},
    {"xpl625_masontraillh", "wooden_chest", "wooden_chest_05777956466a17869155000961f9c0e4", 150, "chest_common_parent", "chest_common_tier3_xpl625_1"},
    {"hel200_entrancedoor", "wooden_chest", "wooden_chest_45cff077ae20b76b69ca0926566ce5c6", 151, "chest_common_parent", "chest_common_tier3_hel200_1"},
    {"xpl650_masontrailcave", "coffin", "coffin_fe52241f85fb3089b8210f793b4a34ee", 154, "coffin_parent", "coffin_tier3_xpl650_1"},
    {"stn750_returnhallway", "coffin", "coffin_f79832e35e68cfc2d8a11e290165fa89", 156, "coffin_parent", "chestobj"},
    {"riv200_dangersmain", "wooden_chest", "wooden_chest_a1d6fa6a5055273efa2aea64e3208312", 157, "chest_common_parent", "chest_common_tier1_riv200_1"},
    {"for700_deerkill", "coffin", "coffin_f9f584304bafcd2f50ab0db9d2694940", 161, "coffin_parent", "coffin_tier1_for700_1"},
    {"for650_bridge", "coffin", "coffin_573b543d74f93b4bd85cffdce6da424d", 162, "coffin_parent", "coffin_tier1_for650_1"},
    {"cal100_hub", "wooden_chest", "wooden_chest_268d53a0272891ccecb31702393e1819", 164, "chest_common_parent", "chest_common_tier1_cal100_1"},
    {"xpl250_funeralinterior", "wooden_chest", "wooden_chest_b14a7e0ad20f015dd563b19abc1a54ca", 165, "chest_common_parent", "chest_common_tier1_xpl250_1"},
    {"stn100_entrance", "coffin", "coffin_4c894a4cd00f5770ebcf2c0c5de8e2b1", 166, "coffin_parent", "coffin_parent_0"},
    {"stn200_lakeext", "coffin", "coffin_5540f9ba7ecad39bfe9f2b5817e16adf", 170, "coffin_parent", "coffin_tier3_stn200_4"},
    {"stn400_hammerbase", "wooden_chest", "wooden_chest_2d23433148d8f06d05b59b34549fd974", 171, "chest_common_parent", "chest_common_tier3_stn400_1"},
    {"hel300_mainbridge", "wooden_chest", "wooden_chest_87235278fe5f92c19968896762202b95", 172, "chest_common_parent", "falling_chest"},
    {"xpl910_islandshipwreck", "coffin", "coffin_cacfc0416ffa2a6daaa23c90fca91ff5", 173, "coffin_parent", "coffin_tier3_xpl910_4"},
    {"stn350_relicroom", "wooden_chest", "wooden_chest_ac18175339972ea504597b184294626a", 174, "chest_common_parent", "chest_common_tier3_stn350_1"},
    {"riv225_dangerscave", "wooden_chest", "wooden_chest_3fe0ed11f8da36cf4d6a8534da039235", 175, "chest_common_parent", "chest_common_tier1_riv420_1"},
    {"alf150_bridgedark", "wooden_chest", "wooden_chest_f588ff33e1919a60d2adb07232f79621", 177, "chest_common_parent", "chest_common_tier1_alf150_1"},
    {"alf340_trenchbdark", "coffin", "coffin_42f17c39434a78c652e5235614526d0a", 178, "coffin_parent", "coffin_tier1_alf340_3"},
    {"riv925_freyacave", "legendary_chest", "legendary_chest_3c05899e46a619015d4cfb995fb61be0", 179, "chestscript", "chest_legendary_parent", "finalchest02"},
    {"cal750_rightwing", "coffin", "coffin_b24c6a682bdd5571637905ce2e305c2f", 180, "coffin_parent", "coffin_tier5_cal750_1"},
    {"xpl200_funeral", "coffin", "coffin_104119f1ce4acbac9a77408da2d7777f", 181, "coffin_parent", "coffin_tier1_xpl200_2"},
    {"stn750_returnhallway", "wooden_chest", "wooden_chest_27794e7010aee1564fa9c0d13927ce5b", 182, "chest_common_parent", "chest_common_tier3_stn750_1"},
    {"peak260_chimneylowhall", "coffin", "coffin_912c5430d4eba71f2aa2b42a05c68d40", 183, "coffin_parent", "coffin_tier3_peak260_1"},
    {"xpl920_islandclimb", "legendary_chest", "legendary_chest_529343984fc313504ac20da874d05c01", 184, "chestscript", "chest_legendary_parent", "chest_legendary_tier3_xpl920_2"},
    {"xpl425_huldramineslh", "coffin", "coffin_32d35ecd545e598e3e3343964f5db9dd", 186, "coffin_parent", "coffin_tier2_xpl425_1"},
    {"helr100_docks", "wooden_chest", "wooden_chest_a8c5ea120a8cc56f28fccd66df0e2f37", 190, "chest_common_parent", "chest_common_tier4_helr100_3"},
    {"peak740_summitpeak", "cipher_chest", "cipher_chest_a4637747ab0a20fa55d7253b2625da13", 191, "chest_dispell_parent", "chest_dispell_tier3_peak740_1"},
    {"xpl980_beachwaterfall", "coffin", "coffin_f1fb65044d01667d716a002b1c3391d5", 192, "coffin_parent", "chestobj"},
    {"xpl910_islandshipwreck", "coffin", "coffin_5f33d793b402e41dfae34b6b00b0fcf1", 193, "coffin_parent", "coffin_tier3_xpl910_2"},
    {"cal170_library1", "coffin", "coffin_a53778e43c763a0bfa7b902a04cf9eb2", 196, "coffin_parent", "coffin_tier4_cal170_1"},
    {"xpl950_beachmaze", "legendary_chest", "legendary_chest_ede160a54530f55a7667f5a39257843c", 201, "chestscript", "chest_legendary_parent", "chest_legendary_tier4_xpl950_1"},
    {"hel100_calderaheldressing", "legendary_chest", "legendary_chest_8002f429448617523d189cbd93b23d4b", 202, "chestscript", "chest_legendary_parent", "chest_legendary_tier4_hel100_1"},
    {"xpl300_stronghold", "coffin", "coffin_345de6844e1e09c6d4d6a6b4133a793c", 203, "coffin_parent", "coffin_tier3_xpl300_1"},
    {"for900_exitclimb", "wooden_chest", "wooden_chest_9796b08ff6484677f92dc5c548be592e", 204, "chest_common_parent", "chest_common_tier1_for900_1"},
    {"alf200_mazedark", "cipher_chest", "cipher_chest_acb38981cfa8d4a13490597c1bcc6dd8", 206, "chest_dispell_parent", "chest_dispell_tier1_alf200_1"},
    {"xpl950_beachmaze", "wooden_chest", "wooden_chest_1346fea0dd6e8e5cb6868dbd2aa9109c", 207, "chest_common_parent", "chest_common_tier2_xpl950_1"},
    {"peak720_summitascenthub", "coffin", "coffin_ce102339a34a1ee210fb708cef487737", 209, "coffin_parent", "coffin_tier4_peak720_2"},
    {"xpl300_stronghold", "wooden_chest", "wooden_chest_33d0f7eadfc4eef14aadaa1e9b6c6143", 210, "chest_common_parent", "chest_common_tier4_xpl300_1"},
    {"cal250_foothillslh", "cipher_chest", "cipher_chest_33234eeb6c2a418623f760e0dd11d24d", 211, "chest_dispell_parent", "chest_dispell_tier1_cal250_1"},
    {"xpl930_beachruins", "cipher_chest", "cipher_chest_5b8711edc0ecbc1775d18513dfd02be8", 212, "chest_dispell_parent", "chest_dispell_tier3_xpl930_1"},
    {"peak500_chimneytop", "legendary_chest", "legendary_chest_ff46dfab43efcfc6f0f382a33e2b571d", 215, "chestscript", "chest_legendary_parent", "chest_legendary_tier4_peak500_1"},
    {"cal750_rightwing", "cipher_chest", "cipher_chest_87d50dbd4e3737165c04ae74fe8ffbb7", 216, "chest_dispell_parent", "chest_dispell_tier5_cal750_1"},
    {"xpl400_huldramines", "coffin", "coffin_d6137b034219becb66bc80d10fd6511f", 218, "coffin_parent", "coffin_tier4_xpl400_1"},
    {"alf600_templeint", "coffin", "coffin_3756070dc04ddc15c61d57cb6c42e5ad", 220, "coffin_parent", "coffin_tier1_alf600_1"},
    {"xpl980_beachwaterfall", "coffin", "coffin_2b66a5509901bb0ae8186134879d62fb", 223, "coffin_parent", "chestobj"},
    {"xpl450_huldramines", "coffin", "coffin_81be3d2815990e8e6e34f3cc239fd25f", 224, "coffin_parent", "coffin_tier4_xpl450_1"},
    {"cal270_stonemasonlh", "cipher_chest", "cipher_chest_bed904beed4cc9151ff7944a557ef0bb", 228, "chest_dispell_parent", "chest_dispell_tier3_cal270_1"},
    {"xpl300_stronghold", "coffin", "coffin_0f897d994245a437eea02861452c1e22", 229, "coffin_parent", "coffin_tier6_xpl300_1"},
    {"peak200_chimneylow", "wooden_chest", "wooden_chest_a23662374dca6281eb791529945c7210", 231, "chest_common_parent", "chest_common_tier3_peak200_1"},
    {"riv325_dangersexit", "wooden_chest", "wooden_chest_3ca0e634863fd2de8454b4713f9426c5", 232, "chest_common_parent", "chest_common_tier1_riv325_3"},
    {"alf340_trenchbdark", "coffin", "coffin_d2080e7d0c12a0ccc335b9b6364a3214", 234, "coffin_parent", "coffin_tier1_alf340_2"},
    {"for260_chiseldungeon", "coffin", "coffin_530e877c15dc4e8af94d97edcb0d27e9", 235, "coffin_parent", "coffin_tier1_for260_1"},
    {"helr100_docks", "wooden_chest", "wooden_chest_7ca006b2b340188300a7e79f6f83391a", 237, "chest_common_parent", "chest_common_tier4_helr100_4"},
    {"xpl400_huldramines", "legendary_chest", "legendary_chest_9d7648ab43bf99f90b0cbd86b0a998f1", 238, "chestscript", "chest_legendary_parent", "chest_legendary_tier1_xpl400_1"},
    {"stn200_lakeext", "wooden_chest", "wooden_chest_7cf0e761c72a66b9b4b45b7e640519a7", 239, "chest_common_parent", "chest_common_tier3_stn200_1"},
    {"hel100_calderaheldressing", "wooden_chest", "wooden_chest_c9b78a83ed706e2f87e723017c735303", 240, "chest_common_parent", "chest_common_tier4_hel100_1"},
    {"xpl960_beachship", "coffin", "coffin_e7c6bb7592f8d71352a303792bc5a6a6", 241, "coffin_parent", "coffin_tier3_xpl960_2"},
    {"xpl920_islandclimb", "coffin", "coffin_483ef71604ed462813b9d2190ffc90cf", 242, "coffin_parent", "coffin_tier6_xpl920_1"},
    {"xpl450_huldramines", "wooden_chest", "wooden_chest_a351d959d938ab662188c62ebb286acc", 244, "chest_common_parent", "chest_common_tier1_xpl450_1"},
    {"hel100_calderaheldressing", "coffin", "coffin_89b943bbda8f5c15788d8c5fe3dd5d42", 246, "coffin_parent", "coffin_tier4_hel100_1"},
    {"peak300_chimneymid", "wooden_chest", "wooden_chest_4120fd9bd6ee2470fe64e0c46ea7c515", 247, "chest_common_parent", "chest_common_tier3_peak300_2"},
    {"cal740_leftwing", "cipher_chest", "cipher_chest_4935b4ad6d592f85492c85bd0829dcb8", 248, "chest_dispell_parent", "chest_dispell_tier5_cal740_1"},
    {"alf355_chiseldungeon", "wooden_chest", "wooden_chest_8836735f3c50fd90d214306b51ebeb79", 252, "chest_common_parent", "chest_common_tier1_alf355_4"},
    {"xpl940_beachcave", "wooden_chest", "wooden_chest_255bd08484850591a8c5077c4efd6b64", 253, "chest_common_parent", "chest_common_tier2_xpl940_2"},
    {"stn110_chiselarena", "coffin", "coffin_a2ec2e348926ce92a6dbfa84d1bb3729", 254, "coffin_parent", "coffin_tier1_stn110_1"},
    {"for660_templeinterior", "wooden_chest", "wooden_chest_c75b16bed331d5ab90b8d6e7a6a742ac", 255, "chest_common_parent", "chest_common_tier1_for660_3"},
    {"for260_chiseldungeon", "wooden_chest", "wooden_chest_34c065eb3609a2c1366263e3f493dfa3", 257, "chest_common_parent", "chest_common_tier5_for260_2"},
    {"xpl850_dungeonforest", "coffin", "coffin_6fc14ea5854a3ac8af7a57a05be00c91", 260, "coffin_parent", "coffin_tier4_xpl850_1"},
    {"xpl150_httktemple", "coffin", "coffin_f0c400642e139948e733d79ec3119f47", 261, "coffin_parent", "coffin_tier4_xpl150_1"},
    {"xpl450_huldramines", "coffin", "coffin_fbad02805a974b9087885a0c497e34ca", 264, "coffin_parent", "coffin_tier3_xpl450_1"},
    {"alf370_moatscripting", "legendary_chest", "legendary_chest_91a9f92a45d2d3fdb92279b4612ab5d7", 265, "chestscript", "chest_legendary_parent", "chest_legendary_tier2_alf370_1"},
    {"xpl910_islandshipwreck", "wooden_chest", "wooden_chest_e22d823077569012bc63ecaf45563e77", 266, "chest_common_parent", "chest_common_tier1_xpl910_1"},
    {"foot100_base", "coffin", "coffin_bc47cbf3655df68aa52d3948f29070ef", 268, "coffin_parent", "chestobj"},
    {"alf325_trenchadarktwr", "coffin", "coffin_73a23f0e4255942c300031a188e8a525", 269, "coffin_parent", "coffin_tier2_alf325_1"},
    {"foot200_mid", "coffin", "coffin_9b316d325ff8c810a3d018399ab0a1fe", 272, "coffin_parent", "coffin_tier1_foot200_1"},
    {"xpl200_funeral", "coffin", "coffin_a1c849de7c794dae09f118bbf46d8dcb", 273, "coffin_parent", "coffin_tier1_xpl200_1"},
    {"stn300_huldracamp", "wooden_chest", "wooden_chest_dac0fe6519eac4b9df6b377f533a73ac", 275, "chest_common_parent", "chest_common_tier3_stn300_1"},
    {"xpl970_beachtower", "wooden_chest", "wooden_chest_bc78435c8826037845b826e1cca23653", 276, "chest_common_parent", "chest_common_tier1_xpl970_1"},
    {"alfdgn110_main", "legendary_chest", "legendary_chest_48f9e1694dc722a549f42893d5b79d9f", 279, "chestscript", "chest_legendary_parent", "chest_legendary_tier1_alfdgn110_1"},
    {"xpl300_stronghold", "wooden_chest", "wooden_chest_2d4638fc479567132f4d797b9b327c48", 280, "chest_common_parent", "chest_common_tier3_xpl300_3"},
    {"hel300_mainbridge", "coffin", "coffin_f2e02def29ac042044af2ff35637b2a9", 282, "coffin_parent", "coffin_tier1_hel300_1"},
    {"alfdgn210_main", "legendary_chest", "legendary_chest_b97f559c471fab8850a2ae8741370020", 283, "chestscript", "chest_legendary_parent", "chest_legendary_tier2_alfdgn210_1"},
    {"alf340_trenchbdark", "coffin", "coffin_8eed9a4a0e0b5390ea90c84406f8f8ce", 285, "coffin_parent", "coffin_tier1_alf340_4"},
    {"xpl400_huldramines", "wooden_chest", "wooden_chest_d122572886b8c92453a055b03706a6ce", 286, "chest_common_parent", "chest_common_tier4_xpl400_1"},
    {"riv225_dangerscave", "coffin", "coffin_dafb5c49c183bb638b57c1be03863ecf", 287, "coffin_parent", "coffin_tier1_riv225_2"},
    {"xpl600_masontrail", "wooden_chest", "wooden_chest_7f6a0836ac388c5b79f08b6048cb998d", 289, "chest_common_parent", "chest_common_tier3_xpl600_1"},
    {"hel350_chiselarena", "coffin", "coffin_e07e5ac1b623623c121b01c2481f504f", 290, "coffin_parent", "coffin_tier1_hel350_1"},
    {"peak300_chimneymid", "coffin", "coffin_92217ff2537c4eca00ca2387cb7a1a42", 291, "coffin_parent", "coffin_tier3_peak300_1"},
    {"xpl910_islandshipwreck", "coffin", "coffin_d468c7d58a26674aa3b5b16dc0e79eaf", 292, "coffin_parent", "coffin_tier3_xpl910_1"},
    {"foot100_base", "coffin", "coffin_715ae2ff1980d3bfee797f2dd1481ec8", 293, "coffin_parent", "coffin_tier3_foot100_2"},
    {"xpl220_funerallh", "coffin", "coffin_d45ead0e44bc195bc94e7ec18de2edb3", 295, "coffin_parent", "coffin_tier1_xpl250_1"},
    {"alf600_templeint", "legendary_chest", "legendary_chest_040af4fa440ef7ba52f8e8b317ac3200", 298, "chestscript", "chest_legendary_parent", "chest_legendary_tier1_alf600_1"},
    {"peak200_chimneylow", "legendary_chest", "legendary_chest_9f29650a4a8a5d0eb8bc43af1dbd3d68", 300, "chestscript", "chest_legendary_parent", "chest_legendary_tier3_peak200_1"},
    {"riv925_freyacave", "coffin", "coffin_6b028789691d219730cefc4630c393f0", 301, "coffin_parent", "coffin_tier1_riv925_1"},
    {"hel300_mainbridge", "wooden_chest", "wooden_chest_8fd4ea6fbc9f86102aa363311d694995", 302, "chest_common_parent", "chest_common_tier4_hel300_1"},
    {"cal500_runevault", "coffin", "coffin_edcb1025a189bc2022b512d6bebaf11a", 303, "coffin_parent", "coffin_tier1_cal500_1"},
    {"alf355_chiseldungeon", "wooden_chest", "wooden_chest_02cb4383595ac1f75f02d048497910be", 304, "chest_common_parent", "chest_common_tier1_alf355_2"},
    {"stn550_chasmclimb", "coffin", "coffin_b9137381c8685a442887b317281334c3", 307, "coffin_parent", "coffin_tier3_stn150_1"},
    {"alf440_hiveextlh", "coffin", "coffin_082e60a8f756390671c4ffa499ce98a2", 308, "coffin_parent", "coffin_tier1_alf440_1"},
    {"stn150_handunder", "coffin", "coffin_e2d0ecbabcb5a115e49005576bc680e0", 309, "coffin_parent", "coffin_tier3_stn150_1"},
    {"xpl875_dungeonforestlh", "wooden_chest", "wooden_chest_f8e1e11f0be082351c02df2da90c1f5b", 310, "chest_common_parent", "chest_common_tier4_xpl875_1"},
    {"xpl450_huldramines", "wooden_chest", "wooden_chest_586cacd7a21c53dd2be423e91e59a256", 312, "chest_common_parent", "chest_common_tier3_xpl450_1"},
    {"cal820_snakebellymid", "cipher_chest", "cipher_chest_f2220e936a3394ddfe1443657707b770", 316, "chest_dispell_parent", "chest_dispell_tier5_cal750_1"},
    {"xpl400_huldramines", "wooden_chest", "wooden_chest_53fd52ac3bb61b72dd6c99bf58b56968", 317, "chest_common_parent", "chest_common_tier2_xpl400_1"},
    {"helr100_docks", "wooden_chest", "wooden_chest_f743cadced96375893da7bd242fd68c0", 318, "chest_common_parent", "chest_common_tier4_helr100_1"},
    {"riv925_freyacave", "wooden_chest", "wooden_chest_affb01a0b9017affae4a4d18ca3e61b7", 319, "chest_common_parent", "chest_common_tier1_riv925_4"},
    {"xpl980_beachwaterfall", "wooden_chest", "wooden_chest_d9b5e3ceb301b036b7cb78f409810ff3", 321, "chest_common_parent", "chest_common_tier3_xpl980_2"},
    {"xpl300_stronghold", "wooden_chest", "wooden_chest_47feaa163975e37d55a81abb7bffba4e", 323, "chest_common_parent", "chest_common_tier3_xpl300_1"},
    {"peak205_chiselarena", "coffin", "coffin_906db69b1c98e210bfd711cea88cd266", 325, "coffin_parent", "coffin_tier1_peak205_1"},
    {"riv475_freyahouseext", "legendary_chest", "legendary_chest_11e085df4bd47deee3a3448bff9efc62", 326, "chestscript", "chest_legendary_parent", "chest_legendary_scripted"},
    {"xpl970_beachtower", "cipher_chest", "cipher_chest_285a8836646562d9520d7c890d4ef3b4", 329, "chest_dispell_parent", "chest_dispell_tier3_xpl970_1"},
    {"xpl100_httk", "coffin", "coffin_5bf1f9791a9a6a851a98e8e377869fbd", 330, "coffin_parent", "coffin_tier4_xpl100_1"},
    {"peak200_chimneylow", "coffin", "coffin_b6a51db40b1e73b0e8c6b24f08b9df77", 335, "coffin_parent", "coffin_tier3_peak200_1"},
    {"cal500_runevault", "legendary_chest", "legendary_chest_d0b93e274754785e08235285bd6b78f2", 336, "chestscript", "chest_legendary_parent", "chest_legendary_tier4_cal500_2"},
    {"xpl900_islandarch", "legendary_chest", "legendary_chest_23d3213f45e38b632ed8048e876e472d", 337, "chestscript", "chest_legendary_parent", "chest_legendary_tier3_xpl900_1"},
    {"xpl920_islandclimb", "wooden_chest", "wooden_chest_a7543637312c028edf79cc16a060097e", 338, "chest_common_parent", "chest_common_tier2_xpl920_1"},
    {"riv225_dangerscave", "coffin", "coffin_07ad6c3ad556b93e9108d10af5a58d8a", 339, "coffin_parent", "coffin_tier1_riv225_1"},
    {"riv975_chiselarena", "wooden_chest", "wooden_chest_7bec312d23c04016fae74ca647bb7bc0", 340, "chest_common_parent", "chest_common_tier1_riv975_1"},
    {"peak780_summitexit", "coffin", "coffin_0efeb8c8cb24d3981a15a70321c096fe", 341, "coffin_parent", "coffin_tier4_peak780_1"},
    {"foot250_chiselarena", "coffin", "coffin_d5a198ed2f341b80b8b04b9a430c5c1c", 343, "coffin_parent", "coffin_tier1_foot250_1"},
    {"xpl900_islandarch", "wooden_chest", "wooden_chest_e04dfd6c26cc8d4dd0bbce8bccd246ff", 344, "chest_common_parent", "chest_common_tier3_xpl900_1"},
    {"alfdgn210_main", "wooden_chest", "wooden_chest_ea3cae8ef3136ef470f6d4b3fed9c6b2", 345, "chest_common_parent", "chest_common_tier1_alfdgn210_1"},
    {"peak740_summitpeak", "coffin", "coffin_f1b0d53b18c6d9100c9573cf006d0b63", 346, "coffin_parent", "coffin_tier1_peak740_1"},
    {"xpl940_beachcave", "cipher_chest", "cipher_chest_a120a8e8b11b778cebccfbe5aab211e9", 350, "chest_dispell_parent", "chest_dispell_tier1_xpl940_1"},
    {"stn400_hammerbase", "coffin", "coffin_44c42ab490af3bedc34e812cb537d913", 351, "coffin_parent", "coffin_tier3_stn150_1"},
    {"xpl300_stronghold", "legendary_chest", "legendary_chest_a24ac28d4ea8598d880d7bb099b8b8be", 352, "chestscript", "chest_legendary_parent", "chestobj", "chest_legendary_locked_roots_parent", "chest_legendary_tier6_xpl300_1"},
    {"helr100_docks", "coffin", "coffin_27372e7163253c3104b397c707ea53bb", 357, "coffin_parent", "coffin_tier4_helr100_2"},
    {"alf355_chiseldungeon", "wooden_chest", "wooden_chest_32d3304f8c18fe1f9d5564e870022cb2", 358, "chest_common_parent", "chest_common_tier1_alf355_1"},
    {"stn110_chiselarena", "wooden_chest", "wooden_chest_cdd6d123984e32a1c6857daaf4212181", 359, "chest_common_parent", "chest_common_tier3_stn110_2"},
    {"for500_forestentry", "wooden_chest", "wooden_chest_c0f40c082a0434d8ba5ee63ee743fb69", 361, "chest_common_parent", "chest_common_tier1_for500_1"},
    {"xpl300_stronghold", "coffin", "coffin_96381eab3f2918f7ebb47343422a8203", 363, "coffin_parent", "coffin_tier5_xpl300_1"},
    {"foot400_arena", "legendary_chest", "legendary_chest_0a04b4de469f3b030064d6827966b213", 364, "chestscript", "chest_legendary_parent", "chest_legendary_tier1_foot400_1"},
    {"xpl450_huldramines", "coffin", "coffin_56534d8b5b802d5d59344beffd1fe9e6", 365, "coffin_parent", "coffin_tier2_xpl450_1"},
    {"xpl900_islandarch", "legendary_chest", "legendary_chest_9226bd444f0f0b95dbeb7c927c6b317b", 366, "chestscript", "chest_legendary_parent", "chest_legendary_tier4_xpl900_1"},
    {"cal740_leftwing", "legendary_chest", "legendary_chest_f714d2d845a3dd9e28808db4655e757f", 367, "chestscript", "chest_legendary_parent", "chest_legendary_tier5_cal740_1"},
    {"peak500_chimneytop", "wooden_chest", "wooden_chest_cb10ac445973e539532db961c1af4e8a", 368, "chest_common_parent", "chest_common_tier4_peak500_1"},
    {"xpl950_beachmaze", "cipher_chest", "cipher_chest_371db5ac6ac1a1ca6bfe75a33315fe6d", 369, "chest_dispell_parent", "chest_dispell_tier1_xpl950_1"},
    {"cal100_hub", "wooden_chest", "wooden_chest_f366e563226a159bf67b76e565795e3d", 370, "chest_common_parent", "chest_common_tier1_cal100_2"},
    {"xpl650_masontrailcave", "wooden_chest", "wooden_chest_c99b83ff35c4c302a595c64fc926d86e", 371, "chest_common_parent", "chest_common_tier2_xpl650_2"},
    {"riv200_dangersmain", "coffin", "coffin_dccf636343f08c57b98bf198059a985f", 373, "coffin_parent", "coffin_tier1_riv200_3"},
    {"xpl960_beachship", "legendary_chest", "legendary_chest_b9e3be9a46c248cc0ddc159643259c52", 374, "chestscript", "chest_legendary_parent", "chest_legendary_tier3_xpl960_1"},
    {"riv925_freyacave", "coffin", "coffin_3340c954018839640be00a0955892015", 375, "coffin_parent", "chestobj"},
    {"foot500_top", "coffin", "coffin_7a8d01b3f8a471a6b7ae8d058f00f12b", 376, "coffin_parent", "coffin_tier5_foot500_1"},
    {"stn110_chiselarena", "wooden_chest", "wooden_chest_2b8135ab4e8526519563c8c391f156f9", 378, "chest_common_parent", "chest_common_tier3_stn110_1"},
    {"peak740_summitpeak", "cipher_chest", "cipher_chest_83a70788cdf281a83161cd7e70101b11", 380, "chest_dispell_parent", "chest_dispell_tier4_peak740_1"},
    {"xpl225_funerallh", "coffin", "coffin_dfca3d7720861fb51244d4e8278d5ab5", 381, "coffin_parent", "coffin_tier1_xpl225_2"},
    {"peak720_summitascenthub", "coffin", "coffin_6dd3b15c19d26faac0ddfecf339a50ab", 385, "coffin_parent", "coffin_tier1_peak720_1"},
    {"for660_templeinterior", "wooden_chest", "wooden_chest_43a2c9ef875eebd6fff86ba2324a982f", 386, "chest_common_parent", "chest_common_tier1_for660_2"},
    {"xpl980_beachwaterfall", "coffin", "coffin_4cb03c66896412451b9a805908c61395", 387, "coffin_parent", "chestobj"},
    {"hel300_mainbridge", "legendary_chest", "legendary_chest_957a57b3456bd17fd24751a66dbcf01c", 388, "chestscript", "chest_legendary_parent", "chest_legendary_tier4_hel300_1"},
    {"stn600_chasmroom", "coffin", "coffin_ea9eca6feb88066fe4fc1111549e67df", 389, "coffin_parent", "chestobj"},
    {"riv325_dangersexit", "coffin", "coffin_5ee94e6e2d8b3f4f14621809c749f528", 391, "coffin_parent", "lootcoffin_scripted"},
    {"xpl910_islandshipwreck", "coffin", "coffin_711c078a74590cb2158c1d1ea7e73389", 393, "coffin_parent", "coffin_tier3_xpl910_3"},
    {"xpl160_httkcavel", "coffin", "coffin_45c3d28bfce2949e7091ea076388005c", 396, "coffin_parent", "coffin_tier3_xpl160_1"},
    {"for560_wolfpit", "coffin", "coffin_02468d124aa5c0271a90ef15db3a4a9e", 398, "coffin_parent", "coffin_tier1_for560_1"},
    {"peak140_caverndark", "coffin", "coffin_cecd3e1ed37118dbc783f38c40ee4803", 399, "coffin_parent", "coffin_tier3_peak140_1"},
    {"cal700_templeflip", "coffin", "coffin_8c8f0d2bb8dc26dc1867c39ec44b8c11", 400, "coffin_parent", "coffin_tier5_cal700_1"},
    {"cal700_templeflip", "coffin", "coffin_e8c9695dda4a836583ad311f9b98d043", 401, "coffin_parent", "coffin_tier1_cal700_1"},
    {"foot400_arena", "coffin", "coffin_e056e03bfc0b68e1f7569b3a03f72722", 402, "coffin_parent", "coffin_tier1_foot400_1"},
    {"peak720_summitascenthub", "wooden_chest", "wooden_chest_8d860a080b9f385f3a3105e035d73ab3", 403, "chest_common_parent", "chest_common_tier3_peak720_1"},
    {"peak205_chiselarena", "wooden_chest", "wooden_chest_7d184e88e7aca574911c6f1addd2a686", 404, "chest_common_parent", "chest_common_tier5_peak205_2"},
    {"riv200_dangersmain", "coffin", "coffin_4721aafec0abacd3c4adb354cdf6c224", 405, "coffin_parent", "coffin_tier1_riv200_1"},
    {"stn800_shortcut", "wooden_chest", "wooden_chest_bcbcd78c5be5d2298f527c26f48c5563", 411, "chest_common_parent", "chest_common_tier3_stn800_1"},
    {"msp100_base", "legendary_chest", "legendary_chest_0656339a4c04a3698b80c0ae57ed2e24", 412, "chestscript", "chest_legendary_parent", "surtrs_trial_silver_r"},
    {"msp100_base", "legendary_chest", "legendary_chest_0e87c24a40632a8e064968874d2b33fc", 413, "chestscript", "chest_legendary_parent", "arena06_gold_legendary_tier3_l"},
    {"msp100_base", "legendary_chest", "legendary_chest_0f68bc8d434fc653dd119d88fe25ac39", 414, "chestscript", "chest_legendary_parent", "surtrs_trial_gold_r"},
    {"msp100_base", "legendary_chest", "legendary_chest_1426a75646869538a1aab6834be04997", 415, "chestscript", "chest_legendary_parent", "surtrs_trial_gold_l"},
    {"msp100_base", "legendary_chest", "legendary_chest_167c0b9e442495b37cbbe6b0a59421c9", 416, "chestscript", "chest_legendary_parent", "arena06_gold_legendary_tier3_r"},
    {"msp100_base", "legendary_chest", "legendary_chest_1ea4b3d24aaae3001a7c779588579d23", 417, "chestscript", "chest_legendary_parent", "surtrs_trial_bronze_r"},
    {"msp100_base", "legendary_chest", "legendary_chest_2106ba90475100c6a58ea0ac3e44f84b", 418, "chestscript", "chest_legendary_parent", "arena05_gold_legendary_tier3"},
    {"msp100_base", "legendary_chest", "legendary_chest_3398a59742fb97a1ffa90a999575ad86", 419, "chestscript", "chest_legendary_parent", "arena02_silver_legendary_tier3"},
    {"msp100_base", "legendary_chest", "legendary_chest_3a43afc448ef450e8db6478342603b96", 420, "chestscript", "chest_legendary_parent", "arena04_silver_legendary_tier3"},
    {"msp100_base", "legendary_chest", "legendary_chest_4e9ceb3946ffc7ee27f94a8421e26426", 421, "chestscript", "chest_legendary_parent", "arena03_bronze_legendary_tier3"},
    {"msp100_base", "legendary_chest", "legendary_chest_5ee9b99949168a003242f99b3a7a9e40", 422, "chestscript", "chest_legendary_parent", "arena01_bronze_legendary_tier3"},
    {"msp100_base", "legendary_chest", "legendary_chest_62733a594d3d75eafab57d8f356c5e5d", 423, "chestscript", "chest_legendary_parent", "arena02_gold_legendary_tier3"},
    {"msp100_base", "legendary_chest", "legendary_chest_778c66804cd49dc1154a6e87d91b6f94", 424, "chestscript", "chest_legendary_parent", "arena03_gold_legendary_tier3"},
    {"msp100_base", "legendary_chest", "legendary_chest_7e85dc2d4905c3d53d06388e05fa3a3d", 425, "chestscript", "chest_legendary_parent", "arena01_gold_legendary_tier3"},
    {"msp100_base", "legendary_chest", "legendary_chest_8666ad60456472e7c4678183988ff6a6", 426, "chestscript", "chest_legendary_parent", "arena06_silver_legendary_tier3_l"},
    {"msp100_base", "legendary_chest", "legendary_chest_86a82b8b451b29c7671ece9c0c3b02b6", 427, "chestscript", "chest_legendary_parent", "arena04_bronze_legendary_tier3"},
    {"msp100_base", "legendary_chest", "legendary_chest_8751f6cc4bc76143fafe0fbbd24835e7", 428, "chestscript", "chest_legendary_parent", "arena04_gold_legendary_tier3"},
    {"msp100_base", "legendary_chest", "legendary_chest_986af1ac43ce92971070738ef0f0e26f", 429, "chestscript", "chest_legendary_parent", "arena06_bronze_legendary_tier3_l"},
    {"msp100_base", "legendary_chest", "legendary_chest_9af2b5194b2e647634c4a89eebf594cd", 430, "chestscript", "chest_legendary_parent", "arena05_bronze_legendary_tier3"},
    {"msp100_base", "legendary_chest", "legendary_chest_a727239b4ba27f22bd1f34bef81b9c26", 431, "chestscript", "chest_legendary_parent", "arena05_silver_legendary_tier3"},
    {"msp100_base", "legendary_chest", "legendary_chest_a7fa046d4390121fef12309f326e5a73", 432, "chestscript", "chest_legendary_parent", "surtrs_trial_silver_l"},
    {"msp100_base", "legendary_chest", "legendary_chest_a9e88e5d4159d86d6bbdaf98ea1421ef", 433, "chestscript", "chest_legendary_parent", "arena06_bronze_legendary_tier3_r"},
    {"msp100_base", "legendary_chest", "legendary_chest_af802a024b7ebfbf480f449f9c033616", 434, "chestscript", "chest_legendary_parent", "arena01_silver_legendary_tier3"},
    {"msp100_base", "legendary_chest", "legendary_chest_b7e0c5d14e1cf09b614010bbc6cacf16", 435, "chestscript", "chest_legendary_parent", "arena06_silver_legendary_tier3_r"},
    {"msp100_base", "legendary_chest", "legendary_chest_d389c19140167b88d7a6819e7c392c93", 436, "chestscript", "chest_legendary_parent", "arena02_bronze_legendary_tier3"},
    {"msp100_base", "legendary_chest", "legendary_chest_d3cc74624839fc657d7ecd8f255e0113", 437, "chestscript", "chest_legendary_parent", "arena03_silver_legendary_tier3"},
    {"msp100_base", "legendary_chest", "legendary_chest_ed7fec9d410885a9729dc3baab012f1f", 438, "chestscript", "chest_legendary_parent", "surtrs_trial_bronze_l"},
  }
  local probeFamily = nil
  local probeDefaultRange = 50
  local probeMember = nil
  local probeErrors = {}

  local function probeLog(text)
    print("[CompletionistProximity] " .. text)
  end

  local function probeError(key, err)
    if not probeErrors[key] then
      probeErrors[key] = true
      probeLog("error " .. key .. " " .. tostring(err))
    end
  end

  local function probeLower(value, prefix)
    if type(value) ~= "string" then return nil end
    value = string.lower(value)
    if string.sub(value, 1, #prefix) == prefix then value = string.sub(value, #prefix + 1) end
    return value
  end

  local function probeName(go)
    if go == nil then return nil end
    local ok, name = pcall(function() return go:GetName() end)
    if ok then return probeLower(name, "go") end
  end

  local function probeParent(go)
    if go == nil then return nil end
    local ok, parent = pcall(function() return go.Parent end)
    if ok then return parent end
  end

  local function probeFind(node, name)
    for _, query in ipairs({name, "go" .. name}) do
      local ok, found = pcall(function() return node:FindSingleGOByName(query) end)
      if ok and found ~= nil then return found end
    end
  end

  local function probeChain(node, row)
    local cursor = node
    for index = 5, #row do
      if cursor == nil or probeName(cursor) ~= row[index] then return false end
      cursor = probeParent(cursor)
    end
    return true
  end

  -- Exact catalogue identity: level plus the owner name path, starting at this
  -- script's object, one of its ancestors, or a named descendant of the object
  -- or its two nearest ancestors. Ambiguous or unmatched objects are left alone.
  local function probeIdentify(obj, levelName)
    local level = probeLower(levelName, "wad_")
    local node = obj
    for depth = 0, 6 do
      if node == nil then break end
      local found
      for _, row in ipairs(probeRows) do
        if row[1] == level then
          local matched = probeChain(node, row)
          if not matched and depth <= 2 then
            local child = probeFind(node, row[5])
            matched = child ~= nil and probeChain(child, row)
          end
          if matched then
            if found ~= nil and found ~= row then return nil, "ambiguous" end
            found = row
          end
        end
      end
      if found ~= nil then return found, depth end
      node = probeParent(node)
    end
    return nil, "unmatched"
  end

  -- The script's own hint distances, as its zone factory and code set them.
  local function probeOriginal()
    return 3, 2
  end

  -- Applied on every broadcast: the script may recreate its zone or reset its
  -- hint distance, and zones have no hint getter. Logged only on change.
  local function probeWiden(range)
    local member = probeMember
    local zone = interactZone
    if zone == nil then
      probeError("zone", "interact zone missing")
      return
    end
    local xz, y = probeOriginal()
    if range > 0 then
      xz, y = math.max(xz, range), math.max(y, range)
    end
    local ok, err = pcall(function()
      zone:SetHintXZRange(xz)
      zone:SetHintYRange(y)
    end)
    if not ok then
      probeError("hint", err)
      return
    end
    if member.zone == zone and member.applied == range then return end
    member.zone, member.applied = zone, range
    probeLog("hint " .. member.id .. " family=" .. member.family .. " xz=" .. tostring(xz) ..
      " y=" .. tostring(y) .. " range=" .. tostring(range))
  end

  -- Hint-only zones the probe owns: no interact range, so no button prompt;
  -- enabled while the range is on and the collectible is not collected.
  local probeEntries = {}
  local probeJoints = {"promptJointFront", "zeroJoint", "promptJoint", "synchJoint", "promptJoint_Son", "linkJoint", "root", "Root", "JORoot", "jointRoot", "joint1", "ApproachPoint", "enabledCollision", "disabledCollision", "Pristine", "Broken1", "approachJoint", "gameJoint", "rewardJoint", "syncJoint", "lootObjLocation", "SpawnDirection", "JOPelvis1", "JOBell1"}
  -- This object's own token (a table address in its Lua state), so the map
  -- can grant art to one object even when two objects claim one catalogue row.
  local probeToken = string.match(tostring({}), "(%x+)$") or "0"
  local probeGranted = {}

  local function probeObserved()
    if type(CompletionistCollectibleObserve) ~= "function" then return nil end
    local ok, _, state = pcall(CompletionistCollectibleObserve)
    if ok then return state end
  end

  local function probeList(...)
    return {n = select("#", ...), ...}
  end

  local function probeChild(go)
    if go == nil then return nil end
    local ok, child = pcall(function() return go.Child end)
    if ok then return child end
  end

  local function probeSonHosts()
    local okSon, son = pcall(function() return thisObj:FindSingleGOByName("GenericSonInteract") end)
    if not okSon or son == nil then return thisObj end
    return probeChild(son), son, thisObj
  end

  -- The object, its descendants breadth first (ref-node Child and grouped
  -- Children), then its parent: joints sit on the meshes, not the roots.
  local function probeTree(root)
    local found, queue, head = {}, {root}, 1
    while queue[head] ~= nil and #found < 48 do
      local node = queue[head]
      head = head + 1
      found[#found + 1] = node
      local child = probeChild(node)
      if child ~= nil then queue[#queue + 1] = child end
      local ok, children = pcall(function() return node.Children end)
      if ok and type(children) == "table" then
        for _, item in ipairs(children) do queue[#queue + 1] = item end
      end
    end
    local parent = probeParent(root)
    if parent ~= nil then found[#found + 1] = parent end
    found.n = #found
    return found
  end

  -- Where the zone's joint is in the world, for the log.
  local function probeWhere(host, joint)
    local ok, position = pcall(function() return host:GetWorldJointPosition(host:GetJointIndex(joint)) end)
    if not ok or position == nil then
      ok, position = pcall(function() return host:GetWorldPosition() end)
    end
    if ok and position ~= nil then
      return string.format("%.1f,%.1f,%.1f", position.x, position.y, position.z)
    end
    return "?"
  end

  -- Joint names the engine reports for a host, when it has such calls; the
  -- static puzzle meshes list no joint names in the level data.
  local function probeJointNames(host)
    local names, info = {}, {}
    for _, method in ipairs({"GetJointCount", "GetNumJoints"}) do
      local ok, value = pcall(function() return host[method](host) end)
      if ok and value ~= nil then info[#info + 1] = method .. "=" .. tostring(value) end
    end
    for index = 0, 8 - 1 do
      local ok, value = pcall(function() return host:GetJointName(index) end)
      if ok and type(value) == "string" and value ~= "" then names[#names + 1] = value end
    end
    if #names > 0 then info[#info + 1] = "names=" .. table.concat(names, ",") end
    return names, table.concat(info, " ")
  end

  local function probeCreate(hosts, icon, range)
    local last, tried = "no host", {}
    for index = 1, hosts.n do
      local host = hosts[index]
      if host ~= nil then
        local joints = probeJoints
        local reported, info = probeJointNames(host)
        if #reported > 0 then
          joints = {}
          for _, joint in ipairs(probeJoints) do joints[#joints + 1] = joint end
          for _, joint in ipairs(reported) do joints[#joints + 1] = joint end
        end
        if #tried < 24 then
          tried[#tried + 1] = tostring(probeName(host)) .. (info ~= "" and ("{" .. info .. "}") or "")
        end
        for _, joint in ipairs(joints) do
          local ok, zone = pcall(function() return game.InteractZone.New(host, joint) end)
          if ok and zone ~= nil then
            local okSetup, err = pcall(function()
              zone:SetTemplateValues({
                name = "Completionist Hint",
                interactFrontAngleMax = 360,
                yRangeMax = 0,
                xzRange = 0,
                xzRangeMax = 0,
                hintXZRange = range,
                hintYRange = range,
                onScreenPercentMin = 1,
                onScreenPercentMax = 0.01,
                onScreenPercentWeight = 0,
                cameraFrontAngleMax = 360
              })
              zone:SetTags("NotInCombat")
              zone:SetPromptIconSet({
                normal = "WORLD_INTERACT_LOOT",
                unavailable = "WORLD_INTERACT_UNAVAILABLE_LOOT",
                locked = "WORLD_INTERACT_LOCKED_LOOT",
                hint = icon
              })
            end)
            if not okSetup then return nil, "setup " .. tostring(err) end
            -- Hints show only within this angle of the joint's facing; the
            -- game uses 360 for hints seen from every side (xpl950_beachmaze).
            local okAngle, angleErr = pcall(function() zone:SetHintAngle(360) end)
            if not okAngle then probeError("hint_angle", angleErr) end
            return zone, tostring(probeName(host)) .. "/" .. joint .. " pos=" .. probeWhere(host, joint)
          end
          last = tostring(zone)
        end
      end
    end
    return nil, last .. " tried=" .. table.concat(tried, ",")
  end

  -- art: reports this collectible to the map, which shows its family art as a
  -- compass marker; while it does, the token is granted and dots give way.
  -- dot: a white hint zone where no stock zone is widened.
  local function probeAdd(key, family, hosts, done, dot, token)
    probeEntries[#probeEntries + 1] = {key = key, family = family, kind = "art", hosts = hosts, done = done,
      token = token}
    if dot then
      probeEntries[#probeEntries + 1] = {key = key, family = family, kind = "dot", hosts = hosts, done = done,
        token = token, icon = "WORLD_INTERACT_HINT_LOOT"}
    end
  end

  local function probeBuild()
    probeAdd(probeMember.id, probeMember.family, function() return probeList(parentObj, thisObj) end,
      function() return probeMember.mapCollected == true or (probeObserved() == "collected") end, false, probeToken)
  end

  -- A zone that is no longer wanted is destroyed, not just disabled.
  local function probeDrop(entry)
    local zone = entry.zone
    entry.zone, entry.applied = nil, nil
    pcall(function() zone:Disable() end)
    local ok = pcall(function() zone:Destroy() end)
    probeLog("zone " .. entry.key .. " kind=" .. entry.kind .. " family=" .. entry.family ..
      " dropped destroyed=" .. tostring(ok))
  end

  local function probeEntry(entry, range)
    local okDone, done = pcall(entry.done)
    local show = range > 0 and not (okDone and done == true) and not probeGranted[entry.token]
    if entry.kind == "art" then
      if entry.zone ~= nil then probeDrop(entry) end
      return
    end
    if entry.zone == nil then
      if not show or (entry.failures or 0) >= 5 then return end
      local okHosts, hosts = pcall(entry.hosts)
      local zone, where = nil, tostring(hosts)
      if okHosts and type(hosts) == "table" then zone, where = probeCreate(hosts, entry.icon, range) end
      if zone == nil then
        entry.failures = (entry.failures or 0) + 1
        probeError("zone " .. entry.key .. " " .. entry.kind, where)
        return
      end
      entry.zone, entry.where = zone, where
    end
    local ok, err = pcall(function()
      if show then
        entry.zone:SetHintXZRange(range)
        entry.zone:SetHintYRange(range)
        entry.zone:Enable()
      else
        entry.zone:Disable()
      end
    end)
    if not ok then
      probeError("hint " .. entry.key .. " " .. entry.kind, err)
      return
    end
    local applied = show and range or 0
    if entry.applied == applied then return end
    entry.applied = applied
    probeLog("zone " .. entry.key .. " kind=" .. entry.kind .. " family=" .. entry.family .. " at=" ..
      tostring(entry.where) .. " shown=" .. tostring(show) .. " range=" .. tostring(range))
  end

  -- Rows the map store holds as collected (what hides their map pins) get no
  -- dots and the stock hint distance. Probe-owned zones wait for the map's
  -- first broadcast, so a collected row never flashes at load.
  local function probeApply(range)
    local member = probeMember
    if member == nil then return end
    if member.mapCollected then range = 0 end
    range = math.min(range, 25)
    if probeWiden ~= nil then probeWiden(probeGranted[probeToken] and 0 or range) end
    if not member.mapSeen then return end
    for _, entry in ipairs(probeEntries) do probeEntry(entry, range) end
  end

  -- Each collectible this object carries tells the map where it is and
  -- whether it is done; the map grants art from these reports.
  local function probeReport()
    local route = engine.GetUIWad()
    for _, entry in ipairs(probeEntries) do
      if entry.kind == "art" then
        local okDone, done = pcall(entry.done)
        local position
        local okHosts, hosts = pcall(entry.hosts)
        if okHosts and type(hosts) == "table" then
          for index = 1, hosts.n do
            if position == nil and hosts[index] ~= nil then
              local ok, value = pcall(function() return hosts[index]:GetWorldPosition() end)
              if ok and value ~= nil then position = value end
            end
          end
        end
        -- This object's own CompletionistCollectibleObserve answer, which the
        -- map cannot read itself (LuaObjectScript is nil from the UI state).
        local observed = "-"
        if entry.key == probeMember.id then
          local seen = probeObserved()
          if seen == "collected" then observed = "c" elseif seen == "remaining" then observed = "r" end
        end
        if position ~= nil then
          engine.SendHook("COMPLETIONIST_PROXIMITY23_REPORT", route, string.format("PROX23R|%s|%s|%s|%.1f|%.1f|%.1f|%d|%s",
            entry.token, entry.key, entry.family, position.x, position.y, position.z,
            (okDone and done == true) and 1 or 0, observed))
        end
      end
    end
  end

  local function probeRangeHook(...)
    for index = 1, select("#", ...) do
      local value = select(index, ...)
      if type(value) == "string" then
        local range, collected, art = string.match(value, "^PROX23|(%d+)|([%d,]*)|([%w,]*)$")
        if range ~= nil then
          local member = probeMember
          if member ~= nil and member.index ~= nil then
            local mapCollected = false
            for number in string.gmatch(collected, "%d+") do
              if tonumber(number) == member.index then mapCollected = true end
            end
            member.mapSeen, member.mapCollected = true, mapCollected
          end
          probeGranted = {}
          for token in string.gmatch(art, "%w+") do probeGranted[token] = true end
          local ok, err = pcall(probeApply, tonumber(range))
          if not ok then probeError("apply", err) end
          local okReport, reportErr = pcall(probeReport)
          if not okReport then probeError("report", reportErr) end
          return
        end
      end
    end
  end

  local function probeStart()
    if probeMember ~= nil then return end
    local row, detail
    if probeFamily ~= nil then
      row, detail = {nil, probeFamily, probeFamily .. ":" .. tostring(probeName(thisObj))}, "script"
    else
      row, detail = probeIdentify(thisObj, thisLevel and thisLevel.Name)
    end
    if row == nil then
      probeLog("unidentified reason=" .. tostring(detail) .. " level=" ..
        tostring(thisLevel and thisLevel.Name) .. " object=" .. tostring(probeName(thisObj)))
      return
    end
    probeMember = {id = row[3], family = row[2], index = row[4], mapSeen = row[4] == nil}
    local okBuild, buildErr = pcall(probeBuild)
    if not okBuild then probeError("build", buildErr) end
    local okThunk, thunk = pcall(require, "core.thunk")
    if okThunk and type(thunk) == "table" and type(thunk.Install) == "function" then
      local okInstall, err = pcall(thunk.Install, "COMPLETIONIST_PROXIMITY23_SHOW", probeRangeHook)
      if not okInstall then probeError("hook", err) end
    else
      probeError("thunk", thunk)
    end
    probeLog("identified id=" .. row[3] .. " family=" .. row[2] .. " depth=" .. tostring(detail))
    probeApply(probeDefaultRange)
  end

  local function probePack(...)
    return {n = select("#", ...), ...}
  end
  local probeOriginalLoaded = OnScriptLoaded
  if type(probeOriginalLoaded) == "function" then
    function OnScriptLoaded(...)
      local results = probePack(probeOriginalLoaded(...))
      local ok, err = pcall(probeStart)
      if not ok then probeError("start", err) end
      return unpack(results, 1, results.n)
    end
  end
end
-- END COMPLETIONIST PROXIMITY V1.1.0
