local LD = require("design.LevelDesignLibrary")
local enabled
local hasOpened = false
local lootInProgress, stage0mesh, stage1mesh, stage3mesh, isCombatRift, combatIntiatesFromInteract, skipLootAfterCombat, onOpenedEvent, combatStartedEvent, combatEndedEvent, onInteractStartCallbacks, RewardTier, RewardTierIndex, WADName, lootObject, frontInteractZone, thisLevel, thisObj, player, regionSummaryQuest, soundEmitter, pocketRiftSoundGroup
function OnScriptLoaded(level, obj)
  thisLevel = level
  thisObj = obj
  player = game.Player.FindPlayer()
  stage0mesh = obj.Parent:FindSingleGOByName("stage0_Idle")
  stage1mesh = obj.Parent:FindSingleGOByName("stage1_Glitch")
  stage3mesh = obj.Parent:FindSingleGOByName("SpawnAnim")
  pocketRiftSoundGroup = thisObj:FindSingleGOByName("pocketRiftSound")
  regionSummaryQuest = obj:FindLuaTableAttribute("regionSummaryQuest")
  isCombatRift = thisObj:FindLuaTableAttribute("isCombatRift")
  skipLootAfterCombat = thisObj:FindLuaTableAttribute("skipLootAfterCombat")
  combatIntiatesFromInteract = thisObj:FindLuaTableAttribute("combatIntiatesFromInteract")
  enabled = thisObj:FindLuaTableAttribute("StartEnabled")
  if obj:FindLuaTableAttribute("onOpenedEvent") ~= nil then
    onOpenedEvent = LD.ExtractCallbacksForEvent(thisLevel, thisObj, obj:FindLuaTableAttribute("onOpenedEvent"))
  end
  if obj:FindLuaTableAttribute("combatStartedEvent") ~= nil then
    combatStartedEvent = LD.ExtractCallbacksForEvent(thisLevel, thisObj, obj:FindLuaTableAttribute("combatStartedEvent"))
  end
  if obj:FindLuaTableAttribute("combatEndedEvent") ~= nil then
    combatEndedEvent = LD.ExtractCallbacksForEvent(thisLevel, thisObj, obj:FindLuaTableAttribute("combatEndedEvent"))
  end
  RewardTier = obj:FindLuaTableAttribute("RewardTier") or 0
  RewardTierIndex = obj:FindLuaTableAttribute("RewardTierIndex") or 0
  WADName = obj:FindLuaTableAttribute("WADName")
  if WADName == nil or WADName == "" then
    WADName = "TB"
  end
  lootObject = obj.Parent:FindSingleGOByName("LootObject")
  frontInteractZone = LD.CreateInteractZone_Standard_360(obj, "promptJointFront")
  frontInteractZone:SetDebugOffset(0, 0, 2)
  frontInteractZone:SetTags("CarryActive")
  if not combatIntiatesFromInteract then
    frontInteractZone:Disable()
  end
  SoundInit()
  game.SubObject.Sleep(obj)
end
function OnFirstStart(level, obj)
  if enabled then
    if not isCombatRift then
      SetVisualState(0)
      Enable()
    else
      SetVisualState(1)
    end
  else
    Disable()
  end
  if lootObject then
    for _, desc in pairs(lootObject.Descendants) do
      desc:Hide()
    end
  end
  HideStage3()
  thisObj:HideCollision()
end
function OnStart(level, obj)
  if not hasOpened then
    if enabled then
      if not isCombatRift then
        SetVisualState(0)
        Enable()
      else
        SetVisualState(1)
      end
    else
      Disable()
    end
  else
    Disable()
  end
  thisObj:HideCollision()
end
function OnUseWorld(level, obj)
  if frontInteractZone:PlayerCanInteract() then
    LD.SetFacingTowardObject(obj, player)
    player:RequestInteract(obj, {
      InteractZone = frontInteractZone,
      LerpObject = lootObject.Child
    })
  end
end
function ForceInteract()
  LD.SetFacingTowardObject(thisObj, player)
  player:RequestInteract(thisObj, {
    InteractZone = frontInteractZone,
    LerpObject = lootObject.Child
  })
end
function OnInteractStart(level, obj, creature)
  LD.PlaySingleSynchMove_KratosObject(thisObj, "syncJoint", "Pocket Rift Interaction", "BRA_bifrostPockRiftEnter", "", frontInteractZone, true)
  FireOnInteractStartCallbacks()
  CameraApproach()
end
function LuaHook_CheckForCombatState()
  if combatIntiatesFromInteract then
    StartCombatState()
    local concussionParams = {
      Tweak = "CNC_PocketRiftKnockBack",
      WorldLocation = player:GetWorldPosition(),
      GameObject = thisObj,
      EnemyId = player:GetID()
    }
    game.Combat.PlayConcussion(concussionParams)
  end
end
function InteractEnable()
  enabled = true
  if frontInteractZone ~= nil then
    frontInteractZone:Enable()
  end
end
function InteractDisable()
  enabled = false
  if frontInteractZone ~= nil then
    frontInteractZone:Disable()
  end
end
function Enable()
  if not hasOpened then
    PlayTransitionFx()
    if isCombatRift then
      SetVisualState(1)
    else
      SetVisualState(0)
    end
    thisObj:HideCollision()
    InteractEnable()
    if lootObject then
      for _, desc in pairs(lootObject.Descendants) do
        desc:Hide()
      end
    end
    pocketRiftSoundGroup:Show()
    PlaySoundInIdle()
  end
end
function SpawnInAndEnable()
  PlayTransitionFx()
  InteractEnable()
  SetVisualState(0)
  PlaySoundInIdle()
end
function Disable()
  StopSoundInIdle()
  HideStage0()
  HideStage1()
  HideStage3()
  InteractDisable()
end
function IsOpen()
  return hasOpened
end
function Lock()
  if frontInteractZone ~= nil then
    frontInteractZone:Lock()
  end
end
function Unlock()
  if frontInteractZone ~= nil then
    frontInteractZone:Unlock()
  end
end
function RegisterOnInteractStartCallback(fn)
  if onInteractStartCallbacks == nil then
    onInteractStartCallbacks = {}
  end
  onInteractStartCallbacks[#onInteractStartCallbacks + 1] = fn
end
function FireOnInteractStartCallbacks()
  if onInteractStartCallbacks ~= nil then
    for _, fn in pairs(onInteractStartCallbacks) do
      fn()
    end
  end
end
function ResetCombatState()
  if not hasOpened then
    pocketRiftSoundGroup:Show()
  end
  if lootObject then
    for _, desc in pairs(lootObject.Descendants) do
      desc:Hide()
    end
  end
  thisObj:HideCollision()
  SetVisualState(1)
  InteractEnable()
end
function HideStage3()
  stage3mesh = thisObj.Parent:FindSingleGOByName("SpawnAnim")
  if stage3mesh ~= nil then
    stage3mesh:JumpAnimToFrame(0)
    stage3mesh:PauseAnim()
    stage3mesh:Hide()
    for _, desc in pairs(stage3mesh.Descendants) do
      desc:Hide()
    end
  end
end
function HideStage1()
  print("found stage 1 mesh its.......", stage1mesh)
  if stage1mesh ~= nil then
    stage1mesh:JumpAnimToFrame(0)
    stage1mesh:PauseAnim()
    stage1mesh:Hide()
    stage1mesh:HideBehaviors()
    for _, desc in pairs(stage1mesh.Descendants) do
      desc:Hide()
      desc:HideBehaviors()
    end
  end
end
function HideStage0()
  stage0mesh = thisObj.Parent:FindSingleGOByName("stage0_Idle")
  if stage0mesh ~= nil then
    stage0mesh:Hide()
    stage0mesh:HideBehaviors()
    for _, desc in pairs(stage0mesh.Descendants) do
      desc:Hide()
      desc:HideBehaviors()
    end
  end
end
function StartCombatState()
  ShowCollision()
  InteractDisable()
  if combatStartedEvent ~= nil then
    LD.ExecuteCallbacksForEvent(thisLevel, thisObj, combatStartedEvent, "combatStartedEvent")
  end
  SetVisualState(3)
  player:CallScript("LuaHook_PocketRiftCombatStarted")
end
function ShowCollision()
  thisObj:ShowCollision()
end
function SpawningDone()
  if combatIntiatesFromInteract == true then
    SetVisualState(4)
    thisObj:HideCollision()
  end
end
function StopCombatState()
  thisObj:HideCollision()
  stage3mesh:JumpAnimToFrame(75)
  stage3mesh:PlayAnimToEnd()
  enabled = true
  combatIntiatesFromInteract = false
  isCombatRift = false
  stage3mesh:OnAnimDone(thisObj, "PostCombatState")
  if combatEndedEvent ~= nil then
    LD.ExecuteCallbacksForEvent(thisLevel, thisObj, combatEndedEvent, "combatEndedEvent")
  end
  player:CallScript("LuaHook_PocketRiftCombatSuccessful")
end
function PostCombatState()
  thisObj:HideCollision()
  if not skipLootAfterCombat then
    stage3mesh:ClearAllAnimCallbacks()
    PlayTransitionFx()
    if stage3mesh ~= nil then
      stage3mesh:Destroy()
    end
    if stage1mesh ~= nil then
      stage1mesh:Destroy()
    end
    if stage0mesh ~= nil then
      stage0mesh:SetScale(2.5)
    end
    SetVisualState(0)
    Enable()
  else
    stage3mesh:ClearAllAnimCallbacks()
    PlayTransitionFx()
    SetVisualState(5)
  end
end
function LuaHook_SpawnFX01()
  local transitionFX = game.FX.Spawn("pocketrift_spawn_transition", thisLevel, {
    GameObject = thisObj,
    Joint = "lootSpawnFX",
    Scale = 1.5,
    Follow = true,
    AutoDelete = true
  })
end
function PlayTransitionFx()
  if combatIntiatesFromInteract then
    local transitionFX = game.FX.Spawn("pocketrift_spawn_transition", thisLevel, {
      GameObject = thisObj,
      Joint = "lootSpawnFX",
      Follow = true,
      AutoDelete = true
    })
  else
    local transitionFXAlt = game.FX.Spawn("pocketrift_spawn_transition", thisLevel, {
      GameObject = thisObj,
      Joint = "lootSpawnFX",
      Follow = true,
      AutoDelete = true
    })
  end
end
function SetCombatIntiatesFromInteract()
  combatIntiatesFromInteract = true
  frontInteractZone:Enable()
end
function SetIsCombatRift()
  isCombatRift = true
end
function SetVisualState(data)
  if data == 0 then
    print("Pocket Rift Entering stage 0")
    stage0mesh = thisObj.Parent:FindSingleGOByName("stage0_Idle")
    print("Stage 0 mesh is...", stage0mesh)
    if stage0mesh ~= nil then
      stage0mesh:Show()
      stage0mesh:ShowBehaviors()
      stage0mesh:SetScale(2.5)
      for _, desc in pairs(stage0mesh.Descendants) do
        desc:ShowBehaviors()
        desc:Show()
      end
      stage0mesh:JumpAnimToFrame(0)
      stage0mesh:PlayAnimCycle()
    end
    HideStage1()
    HideStage3()
    PlaySoundInIdle()
  elseif data == 1 then
    print("Pocket Rift Entering stage 1")
    stage1mesh:Show()
    HideStage0()
    HideStage3()
    PlaySoundInIdle()
  elseif data == 2 then
    local interactFX = game.FX.Spawn("pocketrift_interact_loot", thisLevel, {
      GameObject = thisObj,
      Joint = "lootSpawnFX",
      AutoDelete = true
    })
    PlayTransitionFx()
    print("Pocket Rift Entering stage 2")
    HideStage0()
    HideStage1()
    HideStage3()
    StopSoundInIdle()
    PlaySoundOnInteract()
  elseif data == 3 then
    print("Pocket Rift Entering stage 3")
    stage3mesh:Show()
    PlayTransitionFx()
    stage3mesh:PlayAnimToFrame(30)
    HideStage0()
    HideStage1()
    StopSoundInIdle()
    PlaySoundOnInteract_CombatPortal()
  elseif data == 4 then
    print("Pocket Rift Entering Agitated state")
    if stage3mesh ~= nil then
      stage3mesh:Show()
      stage3mesh:JumpAnimToFrame(60)
      stage3mesh:PlayAnimToFrame(75)
    end
    HideStage0()
    HideStage1()
    PlaySoundCombatPortalClose()
  else
    print("Pocket Rift Entering unknown state")
    HideStage0()
    HideStage1()
    stage3mesh:Destroy()
  end
end
function LuaHook_PlayerEnteredRift()
  if not combatIntiatesFromInteract then
    SetVisualState(2)
    PlaySoundLootIdle()
    lootInProgress = true
  end
end
function LuaHook_SpawnLoot()
  lootObject:Show()
end
function LuaHook_GivePockeRiftLoot()
  if lootObject then
    lootObject:Hide()
  end
  if thisObj:FindLuaTableAttribute("onOpenedEvent") ~= nil then
    LD.ExecuteCallbacksForEvent(thisLevel, thisObj, onOpenedEvent, "onOpenedEvent")
  end
  local rewardName = "MISC_LEGENDARY_TIER"
  LD.RollContainerConditionLoot(rewardName, RewardTier, WADName, RewardTierIndex, thisObj:GetName())
  CheckQuestState()
end
function CheckQuestState()
  local questState = game.QuestManager.GetQuestState("Quest_Labor_RiftPockets_Parent")
  if questState == "Inactive" then
    game.QuestManager.StartQuest("Quest_Labor_RiftPockets_Parent")
  end
  local questStateBronze = game.QuestManager.GetQuestState("Quest_Labor_RiftPockets_Bronze")
  local questStateSilver = game.QuestManager.GetQuestState("Quest_Labor_RiftPockets_Silver")
  game.QuestManager.IncrementQuestProgress("Quest_Labor_RiftPockets", 1)
  if questStateBronze == "Active" then
    game.QuestManager.IncrementQuestProgress("Quest_Labor_RiftPockets_Bronze", 1)
  end
  if questStateSilver == "Active" then
    game.QuestManager.IncrementQuestProgress("Quest_Labor_RiftPockets_Silver", 1)
  end
  if regionSummaryQuest ~= nil and regionSummaryQuest ~= "" then
    regionSummaryQuest = string.gsub(regionSummaryQuest, "%s+", "")
    LD.ActivateAndIncrementQuest(regionSummaryQuest)
  end
end
function OnInteractFinish(level, obj, creature)
  if lootInProgress then
    hasOpened = true
    game.SubObject.SoftSave(thisObj)
    print("soft saving")
  end
end
function OnSaveCheckpoint(level, obj)
  return {
    enabled = enabled,
    hasOpened = hasOpened,
    combatIntiatesFromInteract = combatIntiatesFromInteract,
    isCombatRift = isCombatRift
  }
end
function OnRestoreCheckpoint(level, obj, tab)
  enabled = tab.enabled
  hasOpened = tab.hasOpened
  combatIntiatesFromInteract = tab.combatIntiatesFromInteract
  isCombatRift = tab.isCombatRift
end
function CameraApproach()
  game.Camera.Recenter({
    TimeStart = 0,
    TimeDuration = 2,
    LockRecenter = 1,
    YawRange = -1,
    TriggerLeft = 0,
    TriggerRight = 0,
    ReturnLeft = 0,
    ReturnRight = 0,
    PitchRange = 0,
    ReturnUp = -8,
    ReturnDown = -8
  })
end
local soundEvents = {
  IdleLoop = "SND_LOOT_Rift_Pocket_LP",
  OnInteract = "SND_LOOT_Rift_Pocket_Reach_In",
  CombatPortalOpen = "SND_LOOT_Rift_Pocket_Portal_Gate_Open",
  CombatPortalClose = "SND_LOOT_Rift_Pocket_Portal_Gate_Close",
  CombatPortalEnemySpawn = "SND_LOOT_Rift_Pocket_Portal_Gate_Enemy_Exit",
  CombatPortalLoop = "SND_LOOT_Rift_Pocket_Portal_LP",
  LootIdleLoop = "SND_LOOT_Shard_Purple_Idle_LP"
}
function SoundInit()
  soundEmitter = pocketRiftSoundGroup:FindSingleSoundEmitterByName("SNDPocketRift")
end
function SoundSetup(sounds)
  if sounds ~= nil then
    if sounds.SoundEmitter ~= nil then
      soundEmitter = thisObj:FindSingleSoundEmitterByName(sounds.SoundEmitter)
    end
    for key in pairs(soundEvents) do
      for newKey, newValue in pairs(sounds) do
        if newKey == key and newValue ~= nil and newValue ~= "" then
          soundEvents[key] = newValue
        end
      end
      LD.SoundDebug(tostring(key) .. ": " .. tostring(soundEvents[key]))
    end
  end
end
function PlaySoundInIdle()
  LD.PlayRestartableSoundLoop(soundEmitter, soundEvents.IdleLoop)
end
function StopSoundInIdle()
  LD.StopRestartableSoundLoop(soundEmitter, soundEvents.IdleLoop)
end
function PlaySoundOnInteract()
  LD.PlaySound(soundEmitter, soundEvents.OnInteract)
end
function PlaySoundOnInteract_CombatPortal()
  LD.PlaySound(soundEmitter, soundEvents.CombatPortalOpen)
  PlaySoundCombatPortalLoop()
end
function PlaySoundCombatPortalClose()
  StopSoundCombatPortalLoop()
  LD.PlaySound(soundEmitter, soundEvents.CombatPortalClose)
  LD.PlaySoundOnFrame(soundEmitter, stage3mesh, soundEvents.IdleLoop, 75)
end
function PlaySoundCombatPortalLoop()
  LD.PlayRestartableSoundLoop(soundEmitter, soundEvents.CombatPortalLoop)
end
function StopSoundCombatPortalLoop()
  LD.StopRestartableSoundLoop(soundEmitter, soundEvents.CombatPortalLoop)
end
function PlaySoundCombatPortalEnemySpawn()
  LD.PlaySound(soundEmitter, soundEvents.CombatPortalEnemySpawn)
end
function PlaySoundLootIdle()
  local lootSoundEmitter = thisObj.Parent:FindSingleGOByName("LootPocketGeo"):FindSingleGOByName("LootObject").Child.SoundEmitters[1]
  if lootSoundEmitter then
    LD.PlaySound(lootSoundEmitter, soundEvents.LootIdleLoop)
  end
end

-- BEGIN COMPLETIONIST COLLECTIBLE OBSERVATION
do
  function GetState()
    return hasOpened and 4 or 0
  end
  function HasOpened()
    return hasOpened
  end
  function CompletionistCollectibleObserve()
    if type(hasOpened) ~= "boolean" then return nil end
    local collected = hasOpened
    return "rift", collected and "collected" or "remaining"
  end
  local function clearActiveCompassMarker()
    pcall(function()
      if type(game) == "table" and type(game.Compass) == "table" and type(game.Compass.FindMarkersByIconClass) == "function" then
        local markers = game.Compass.FindMarkersByIconClass({"SIDE"})
        if type(markers) == "table" then
          for _, id in ipairs(markers) do
            pcall(game.Compass.HideMarker, id)
          end
        end
      end
    end)
  end
  local function notify()
    if hasOpened then
      clearActiveCompassMarker()
    end
    if thisLevel == nil or type(thisLevel.Name) ~= "string" then return end
    engine.SendHook("COMPLETIONIST_COLLECTIBLE_DIRTY_V1", engine.GetUIWad(),
      "COLLECTIBLE_DIRTY_V1	" .. string.lower(thisLevel.Name))
  end
  local function pack(...) return {n=select('#',...), ...} end
  local unpackValues = unpack or table.unpack
  local function wrap(original)
    return function(...)
      local result = pack(original(...))
      pcall(notify)
      return unpackValues(result, 1, result.n)
    end
  end
  if type(OnInteractFinish) == "function" then OnInteractFinish = wrap(OnInteractFinish) end
  if type(LuaHook_GivePockeRiftLoot) == "function" then LuaHook_GivePockeRiftLoot = wrap(LuaHook_GivePockeRiftLoot) end
  if type(OnStart) == "function" then OnStart = wrap(OnStart) end
  if type(OnRestoreCheckpoint) == "function" then OnRestoreCheckpoint = wrap(OnRestoreCheckpoint) end
end
-- END COMPLETIONIST COLLECTIBLE OBSERVATION
-- BEGIN COMPLETIONIST PROXIMITY V1.1.0
-- Shows the game's native interact hint dot on this collectible out to the
-- map's [Up Arrow] range. Append-only: OnScriptLoaded runs unchanged first;
-- every call below is pcall-guarded.
do
  local probeRows = {
    {"alf300_lakedark", "realm_tear", "realm_tear_d9d5fe53b4d7bd0c88376c7647f5537e", 33, "lootpocketgeo", "lootpocketrift110"},
    {"cal250_foothillslh", "realm_tear", "realm_tear_1c939364d61323b0c9db30a25da5b0f0", 45, "lootpocketgeo", "lootpocketriftcal250"},
    {"cal100_hub", "realm_tear", "realm_tear_64b7ac07cbf1db2d7956e3298e23970f", 72, "lootpocketgeo", "lootpocketriftalf"},
    {"nid400_center", "realm_tear", "realm_tear_80a81219135f07ea1c0eb1948748fc58", 74, "lootpocketgeo", "misc_legendary_tier5_nid400_1"},
    {"nid400_center", "realm_tear", "realm_tear_ad3009f9f80b31ab80419fd380e60c1c", 75, "lootpocketgeo", "misc_legendary_tier6_nid400_1"},
    {"nid400_center", "realm_tear", "realm_tear_10374be1dacc7b5afc9b38ff1c50b3f5", 76, "lootpocketgeo", "misc_legendary_tier4_nid400_1"},
    {"peak740_summitpeak", "realm_tear", "realm_tear_75c3365cbb3042f761a82660c314147e", 97, "lootpocketgeo", "lootpocketrift740"},
    {"cal100_hub", "realm_tear", "realm_tear_af0e22716b928bcf52889387ffc91c4f", 110, "lootpocketgeo", "lootpocketriftnid"},
    {"cal100_hub", "realm_tear", "realm_tear_71588ab9681c6184279e7384fdafbbdd", 116, "lootpocketgeo", "lootpocketriftdragon"},
    {"alfdgn210_main", "realm_tear", "realm_tear_885f79d8699b58e655739f1b924bf442", 163, "lootpocketgeo", "lootpocketrift210"},
    {"stn800_shortcut", "realm_tear", "realm_tear_b24fe2ba5298d202f41bda97b2a00845", 168, "lootpocketgeo", "lootpocketrift_stn800"},
    {"for260_chiseldungeon", "realm_tear", "realm_tear_a3857496e778be84cdb14938feb3885d", 205, "lootpocketgeo", "lpktrft_startfight"},
    {"cal100_hub", "realm_tear", "realm_tear_664c0fd312a6e88d8739f7d5af968fe3", 227, "lootpocketgeo", "lootpocketrift940"},
    {"stn200_lakeext", "realm_tear", "realm_tear_2b6da4fe76312741d21ade4905d66ff4", 236, "lootpocketgeo", "lootpocketrift_1_a"},
    {"cal100_hub", "realm_tear", "realm_tear_6f5037ce091595b1bc2b0ab31cfaf05b", 245, "lootpocketgeo", "misc_legendary_tier3_cal100_2"},
    {"xpl920_islandclimb", "realm_tear", "realm_tear_cb9a35e72a6bd571c820349c901762a9", 267, "lootpocketgeo", "pocketrift_loot"},
    {"cal100_hub", "realm_tear", "realm_tear_ae12a2c33fd8e441bf159a5fd7ac3c22", 281, "lootpocketgeo", "pocketriftdbang"},
    {"xpl920_islandclimb", "realm_tear", "realm_tear_12672293750dfc6b1381cf5159ad0615", 320, "lootpocketgeo", "lootpocketrift920"},
    {"xpl200_funeral", "realm_tear", "realm_tear_64256db4dca56cbedc9c2ad1bb454bef", 348, "lootpocketgeo", "misc_legendary_tier2_xpl200_1"},
    {"xpl960_beachship", "realm_tear", "realm_tear_f4600a74cbfaceabd4ba6d80a59a66bc", 377, "lootpocketgeo", "misc_legendary_tier3_xpl960_1"},
    {"xpl100_httk", "realm_tear", "realm_tear_c3d17070f981647e7189e2076fbcc55c", 390, "lootpocketgeo", "misc_legendary_tier5_xpl100_1"},
  }
  local probeFamily = nil
  local probeDefaultRange = 50
  local probeMember = nil
  local probeErrors = {}

  local function probeLog(text)
    print("[CompletionistProximity] " .. text)
  end

  local function probeError(key, err)
    if not probeErrors[key] then
      probeErrors[key] = true
      probeLog("error " .. key .. " " .. tostring(err))
    end
  end

  local function probeLower(value, prefix)
    if type(value) ~= "string" then return nil end
    value = string.lower(value)
    if string.sub(value, 1, #prefix) == prefix then value = string.sub(value, #prefix + 1) end
    return value
  end

  local function probeName(go)
    if go == nil then return nil end
    local ok, name = pcall(function() return go:GetName() end)
    if ok then return probeLower(name, "go") end
  end

  local function probeParent(go)
    if go == nil then return nil end
    local ok, parent = pcall(function() return go.Parent end)
    if ok then return parent end
  end

  local function probeFind(node, name)
    for _, query in ipairs({name, "go" .. name}) do
      local ok, found = pcall(function() return node:FindSingleGOByName(query) end)
      if ok and found ~= nil then return found end
    end
  end

  local function probeChain(node, row)
    local cursor = node
    for index = 5, #row do
      if cursor == nil or probeName(cursor) ~= row[index] then return false end
      cursor = probeParent(cursor)
    end
    return true
  end

  -- Exact catalogue identity: level plus the owner name path, starting at this
  -- script's object, one of its ancestors, or a named descendant of the object
  -- or its two nearest ancestors. Ambiguous or unmatched objects are left alone.
  local function probeIdentify(obj, levelName)
    local level = probeLower(levelName, "wad_")
    local node = obj
    for depth = 0, 6 do
      if node == nil then break end
      local found
      for _, row in ipairs(probeRows) do
        if row[1] == level then
          local matched = probeChain(node, row)
          if not matched and depth <= 2 then
            local child = probeFind(node, row[5])
            matched = child ~= nil and probeChain(child, row)
          end
          if matched then
            if found ~= nil and found ~= row then return nil, "ambiguous" end
            found = row
          end
        end
      end
      if found ~= nil then return found, depth end
      node = probeParent(node)
    end
    return nil, "unmatched"
  end

  -- The script's own hint distances, as its zone factory and code set them.
  local function probeOriginal()
    return 5, 2
  end

  -- Applied on every broadcast: the script may recreate its zone or reset its
  -- hint distance, and zones have no hint getter. Logged only on change.
  local function probeWiden(range)
    local member = probeMember
    local zone = frontInteractZone
    if zone == nil then
      probeError("zone", "interact zone missing")
      return
    end
    local xz, y = probeOriginal()
    if range > 0 then
      xz, y = math.max(xz, range), math.max(y, range)
    end
    local ok, err = pcall(function()
      zone:SetHintXZRange(xz)
      zone:SetHintYRange(y)
    end)
    if not ok then
      probeError("hint", err)
      return
    end
    if member.zone == zone and member.applied == range then return end
    member.zone, member.applied = zone, range
    probeLog("hint " .. member.id .. " family=" .. member.family .. " xz=" .. tostring(xz) ..
      " y=" .. tostring(y) .. " range=" .. tostring(range))
  end

  -- Hint-only zones the probe owns: no interact range, so no button prompt;
  -- enabled while the range is on and the collectible is not collected.
  local probeEntries = {}
  local probeJoints = {"promptJointFront", "zeroJoint", "promptJoint", "synchJoint", "promptJoint_Son", "linkJoint", "root", "Root", "JORoot", "jointRoot", "joint1", "ApproachPoint", "enabledCollision", "disabledCollision", "Pristine", "Broken1", "approachJoint", "gameJoint", "rewardJoint", "syncJoint", "lootObjLocation", "SpawnDirection", "JOPelvis1", "JOBell1"}
  -- This object's own token (a table address in its Lua state), so the map
  -- can grant art to one object even when two objects claim one catalogue row.
  local probeToken = string.match(tostring({}), "(%x+)$") or "0"
  local probeGranted = {}

  local function probeObserved()
    if type(CompletionistCollectibleObserve) ~= "function" then return nil end
    local ok, _, state = pcall(CompletionistCollectibleObserve)
    if ok then return state end
  end

  local function probeList(...)
    return {n = select("#", ...), ...}
  end

  local function probeChild(go)
    if go == nil then return nil end
    local ok, child = pcall(function() return go.Child end)
    if ok then return child end
  end

  local function probeSonHosts()
    local okSon, son = pcall(function() return thisObj:FindSingleGOByName("GenericSonInteract") end)
    if not okSon or son == nil then return thisObj end
    return probeChild(son), son, thisObj
  end

  -- The object, its descendants breadth first (ref-node Child and grouped
  -- Children), then its parent: joints sit on the meshes, not the roots.
  local function probeTree(root)
    local found, queue, head = {}, {root}, 1
    while queue[head] ~= nil and #found < 48 do
      local node = queue[head]
      head = head + 1
      found[#found + 1] = node
      local child = probeChild(node)
      if child ~= nil then queue[#queue + 1] = child end
      local ok, children = pcall(function() return node.Children end)
      if ok and type(children) == "table" then
        for _, item in ipairs(children) do queue[#queue + 1] = item end
      end
    end
    local parent = probeParent(root)
    if parent ~= nil then found[#found + 1] = parent end
    found.n = #found
    return found
  end

  -- Where the zone's joint is in the world, for the log.
  local function probeWhere(host, joint)
    local ok, position = pcall(function() return host:GetWorldJointPosition(host:GetJointIndex(joint)) end)
    if not ok or position == nil then
      ok, position = pcall(function() return host:GetWorldPosition() end)
    end
    if ok and position ~= nil then
      return string.format("%.1f,%.1f,%.1f", position.x, position.y, position.z)
    end
    return "?"
  end

  -- Joint names the engine reports for a host, when it has such calls; the
  -- static puzzle meshes list no joint names in the level data.
  local function probeJointNames(host)
    local names, info = {}, {}
    for _, method in ipairs({"GetJointCount", "GetNumJoints"}) do
      local ok, value = pcall(function() return host[method](host) end)
      if ok and value ~= nil then info[#info + 1] = method .. "=" .. tostring(value) end
    end
    for index = 0, 8 - 1 do
      local ok, value = pcall(function() return host:GetJointName(index) end)
      if ok and type(value) == "string" and value ~= "" then names[#names + 1] = value end
    end
    if #names > 0 then info[#info + 1] = "names=" .. table.concat(names, ",") end
    return names, table.concat(info, " ")
  end

  local function probeCreate(hosts, icon, range)
    local last, tried = "no host", {}
    for index = 1, hosts.n do
      local host = hosts[index]
      if host ~= nil then
        local joints = probeJoints
        local reported, info = probeJointNames(host)
        if #reported > 0 then
          joints = {}
          for _, joint in ipairs(probeJoints) do joints[#joints + 1] = joint end
          for _, joint in ipairs(reported) do joints[#joints + 1] = joint end
        end
        if #tried < 24 then
          tried[#tried + 1] = tostring(probeName(host)) .. (info ~= "" and ("{" .. info .. "}") or "")
        end
        for _, joint in ipairs(joints) do
          local ok, zone = pcall(function() return game.InteractZone.New(host, joint) end)
          if ok and zone ~= nil then
            local okSetup, err = pcall(function()
              zone:SetTemplateValues({
                name = "Completionist Hint",
                interactFrontAngleMax = 360,
                yRangeMax = 0,
                xzRange = 0,
                xzRangeMax = 0,
                hintXZRange = range,
                hintYRange = range,
                onScreenPercentMin = 1,
                onScreenPercentMax = 0.01,
                onScreenPercentWeight = 0,
                cameraFrontAngleMax = 360
              })
              zone:SetTags("NotInCombat")
              zone:SetPromptIconSet({
                normal = "WORLD_INTERACT_LOOT",
                unavailable = "WORLD_INTERACT_UNAVAILABLE_LOOT",
                locked = "WORLD_INTERACT_LOCKED_LOOT",
                hint = icon
              })
            end)
            if not okSetup then return nil, "setup " .. tostring(err) end
            -- Hints show only within this angle of the joint's facing; the
            -- game uses 360 for hints seen from every side (xpl950_beachmaze).
            local okAngle, angleErr = pcall(function() zone:SetHintAngle(360) end)
            if not okAngle then probeError("hint_angle", angleErr) end
            return zone, tostring(probeName(host)) .. "/" .. joint .. " pos=" .. probeWhere(host, joint)
          end
          last = tostring(zone)
        end
      end
    end
    return nil, last .. " tried=" .. table.concat(tried, ",")
  end

  -- art: reports this collectible to the map, which shows its family art as a
  -- compass marker; while it does, the token is granted and dots give way.
  -- dot: a white hint zone where no stock zone is widened.
  local function probeAdd(key, family, hosts, done, dot, token)
    probeEntries[#probeEntries + 1] = {key = key, family = family, kind = "art", hosts = hosts, done = done,
      token = token}
    if dot then
      probeEntries[#probeEntries + 1] = {key = key, family = family, kind = "dot", hosts = hosts, done = done,
        token = token, icon = "WORLD_INTERACT_HINT_LOOT"}
    end
  end

  local function probeBuild()
    probeAdd(probeMember.id, probeMember.family, function() return probeList(thisObj) end,
      function() return probeMember.mapCollected == true or (probeObserved() == "collected") end, false, probeToken)
  end

  -- A zone that is no longer wanted is destroyed, not just disabled.
  local function probeDrop(entry)
    local zone = entry.zone
    entry.zone, entry.applied = nil, nil
    pcall(function() zone:Disable() end)
    local ok = pcall(function() zone:Destroy() end)
    probeLog("zone " .. entry.key .. " kind=" .. entry.kind .. " family=" .. entry.family ..
      " dropped destroyed=" .. tostring(ok))
  end

  local function probeEntry(entry, range)
    local okDone, done = pcall(entry.done)
    local show = range > 0 and not (okDone and done == true) and not probeGranted[entry.token]
    if entry.kind == "art" then
      if entry.zone ~= nil then probeDrop(entry) end
      return
    end
    if entry.zone == nil then
      if not show or (entry.failures or 0) >= 5 then return end
      local okHosts, hosts = pcall(entry.hosts)
      local zone, where = nil, tostring(hosts)
      if okHosts and type(hosts) == "table" then zone, where = probeCreate(hosts, entry.icon, range) end
      if zone == nil then
        entry.failures = (entry.failures or 0) + 1
        probeError("zone " .. entry.key .. " " .. entry.kind, where)
        return
      end
      entry.zone, entry.where = zone, where
    end
    local ok, err = pcall(function()
      if show then
        entry.zone:SetHintXZRange(range)
        entry.zone:SetHintYRange(range)
        entry.zone:Enable()
      else
        entry.zone:Disable()
      end
    end)
    if not ok then
      probeError("hint " .. entry.key .. " " .. entry.kind, err)
      return
    end
    local applied = show and range or 0
    if entry.applied == applied then return end
    entry.applied = applied
    probeLog("zone " .. entry.key .. " kind=" .. entry.kind .. " family=" .. entry.family .. " at=" ..
      tostring(entry.where) .. " shown=" .. tostring(show) .. " range=" .. tostring(range))
  end

  -- Rows the map store holds as collected (what hides their map pins) get no
  -- dots and the stock hint distance. Probe-owned zones wait for the map's
  -- first broadcast, so a collected row never flashes at load.
  local function probeApply(range)
    local member = probeMember
    if member == nil then return end
    if member.mapCollected then range = 0 end
    range = math.min(range, 25)
    if probeWiden ~= nil then probeWiden(probeGranted[probeToken] and 0 or range) end
    if not member.mapSeen then return end
    for _, entry in ipairs(probeEntries) do probeEntry(entry, range) end
  end

  -- Each collectible this object carries tells the map where it is and
  -- whether it is done; the map grants art from these reports.
  local function probeReport()
    local route = engine.GetUIWad()
    for _, entry in ipairs(probeEntries) do
      if entry.kind == "art" then
        local okDone, done = pcall(entry.done)
        local position
        local okHosts, hosts = pcall(entry.hosts)
        if okHosts and type(hosts) == "table" then
          for index = 1, hosts.n do
            if position == nil and hosts[index] ~= nil then
              local ok, value = pcall(function() return hosts[index]:GetWorldPosition() end)
              if ok and value ~= nil then position = value end
            end
          end
        end
        -- This object's own CompletionistCollectibleObserve answer, which the
        -- map cannot read itself (LuaObjectScript is nil from the UI state).
        local observed = "-"
        if entry.key == probeMember.id then
          local seen = probeObserved()
          if seen == "collected" then observed = "c" elseif seen == "remaining" then observed = "r" end
        end
        if position ~= nil then
          engine.SendHook("COMPLETIONIST_PROXIMITY23_REPORT", route, string.format("PROX23R|%s|%s|%s|%.1f|%.1f|%.1f|%d|%s",
            entry.token, entry.key, entry.family, position.x, position.y, position.z,
            (okDone and done == true) and 1 or 0, observed))
        end
      end
    end
  end

  local function probeRangeHook(...)
    for index = 1, select("#", ...) do
      local value = select(index, ...)
      if type(value) == "string" then
        local range, collected, art = string.match(value, "^PROX23|(%d+)|([%d,]*)|([%w,]*)$")
        if range ~= nil then
          local member = probeMember
          if member ~= nil and member.index ~= nil then
            local mapCollected = false
            for number in string.gmatch(collected, "%d+") do
              if tonumber(number) == member.index then mapCollected = true end
            end
            member.mapSeen, member.mapCollected = true, mapCollected
          end
          probeGranted = {}
          for token in string.gmatch(art, "%w+") do probeGranted[token] = true end
          local ok, err = pcall(probeApply, tonumber(range))
          if not ok then probeError("apply", err) end
          local okReport, reportErr = pcall(probeReport)
          if not okReport then probeError("report", reportErr) end
          return
        end
      end
    end
  end

  local function probeStart()
    if probeMember ~= nil then return end
    local row, detail
    if probeFamily ~= nil then
      row, detail = {nil, probeFamily, probeFamily .. ":" .. tostring(probeName(thisObj))}, "script"
    else
      row, detail = probeIdentify(thisObj, thisLevel and thisLevel.Name)
    end
    if row == nil then
      probeLog("unidentified reason=" .. tostring(detail) .. " level=" ..
        tostring(thisLevel and thisLevel.Name) .. " object=" .. tostring(probeName(thisObj)))
      return
    end
    probeMember = {id = row[3], family = row[2], index = row[4], mapSeen = row[4] == nil}
    local okBuild, buildErr = pcall(probeBuild)
    if not okBuild then probeError("build", buildErr) end
    local okThunk, thunk = pcall(require, "core.thunk")
    if okThunk and type(thunk) == "table" and type(thunk.Install) == "function" then
      local okInstall, err = pcall(thunk.Install, "COMPLETIONIST_PROXIMITY23_SHOW", probeRangeHook)
      if not okInstall then probeError("hook", err) end
    else
      probeError("thunk", thunk)
    end
    probeLog("identified id=" .. row[3] .. " family=" .. row[2] .. " depth=" .. tostring(detail))
    probeApply(probeDefaultRange)
  end

  local function probePack(...)
    return {n = select("#", ...), ...}
  end
  local probeOriginalLoaded = OnScriptLoaded
  if type(probeOriginalLoaded) == "function" then
    function OnScriptLoaded(...)
      local results = probePack(probeOriginalLoaded(...))
      local ok, err = pcall(probeStart)
      if not ok then probeError("start", err) end
      return unpack(results, 1, results.n)
    end
  end
end
-- END COMPLETIONIST PROXIMITY V1.1.0
