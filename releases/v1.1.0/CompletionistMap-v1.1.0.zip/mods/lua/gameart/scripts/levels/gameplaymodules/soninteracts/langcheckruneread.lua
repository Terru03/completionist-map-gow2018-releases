local LD = require("design.LevelDesignLibrary")
local thisObj, thisLevel, language, languageResource, languageGated, discsToComplete, xpReward, journalUpdateID, regionSummaryQuest, Event_OnFailure, Event_OnPartialFailure, Event_OnSuccessfulStart, interactObj, mapSummaryComplete
local enableDelay = 5
function OnScriptLoaded(level, obj)
  thisObj = obj
  thisLevel = level
  languageGated = thisObj:FindLuaTableAttribute("LanguageGated")
  language = thisObj:FindLuaTableAttribute("LanguageToCheck")
  languageResource = language .. "CipherPiece"
  xpReward = thisObj:FindLuaTableAttribute("XpReward")
  journalUpdateID = thisObj:FindLuaTableAttribute("journalUpdateID")
  regionSummaryQuest = thisObj:FindLuaTableAttribute("regionSummaryQuest")
  Event_OnFailure = thisObj:FindLuaTableAttribute("Event_OnFailure")
  if Event_OnFailure then
    Event_OnFailure = LD.ExtractCallbacksForEvent(thisLevel, thisObj, Event_OnFailure)
  end
  Event_OnPartialFailure = thisObj:FindLuaTableAttribute("Event_OnPartialFailure")
  if Event_OnPartialFailure then
    Event_OnPartialFailure = LD.ExtractCallbacksForEvent(thisLevel, thisObj, Event_OnPartialFailure)
  end
  Event_OnSuccessfulStart = thisObj:FindLuaTableAttribute("Event_OnSuccessfulStart")
  if Event_OnSuccessfulStart then
    Event_OnSuccessfulStart = LD.ExtractCallbacksForEvent(thisLevel, thisObj, Event_OnSuccessfulStart)
  end
  if languageGated == true then
    discsToComplete = 4
  end
  interactObj = thisObj:FindSingleGOByName("GenericSonInteract")
  interactObj.LuaObjectScript.GetInteractZone():SetRequiresCriticalBanterComplete(true)
  game.SubObject.Sleep(obj)
  game.SubObject.SetForgetOnCheckpoint(obj)
end
function OnPreStart(level, obj)
  local oldOnInteractCompleteCallbacks = interactObj.LuaObjectScript.TriggerOnInteractCompleteCallbacks
  function interactObj.LuaObjectScript.TriggerOnInteractCompleteCallbacks()
    oldOnInteractCompleteCallbacks()
    UpdateJournal()
  end
  local oldOnEngagedCallbacks = interactObj.LuaObjectScript.TriggerOnInteractEngagedCallbacks
  function interactObj.LuaObjectScript.TriggerOnInteractEngagedCallbacks()
    print("!!!!! Triggering OnEngaged Callbacks")
    oldOnEngagedCallbacks()
    InterruptIfLanguageUnknown()
  end
  SoundOnPreStart()
end
function GetInteractZone()
  return interactObj.LuaObjectScript.GetInteractZone()
end
function InterruptIfLanguageUnknown()
  print("!!!!! Triggering InterruptIfLanguageUnknown")
  if languageGated then
    local discsCollected = game.Wallets.GetResourceValue("HERO", languageResource)
    local banterLine = ""
    if language == "Muspelheim" then
      banterLine = "RuneMarker_03_Fail"
    end
    if language == "Niflheim" then
      banterLine = "RuneMarker_04_Fail"
    end
    if discsCollected == -1 then
      interactObj.LuaObjectScript.Disable()
      if thisObj:FindLuaTableAttribute("IsTowerBrazier") == true then
        CheckForFailureType()
      elseif FreyaCheck() then
        if language == "Niflheim" then
          game.Audio.PlayBanter("Brazier_Indecipherable_Freya_Nif", FailInteract)
        else
          game.Audio.PlayBanter("Brazier_Indecipherable_Freya_Musp", FailInteract)
        end
      else
        game.Audio.PlayBanter(banterLine, FailInteract)
      end
      return
    end
    if 0 < discsCollected and discsCollected < discsToComplete then
      interactObj.LuaObjectScript.Disable()
      if thisObj:FindLuaTableAttribute("IsTowerBrazier") == true then
        CheckForFailureType()
      elseif FreyaCheck() then
        if language == "Niflheim" then
          game.Audio.PlayBanter("Brazier_Indecipherable_Freya_Nif", PartiallyFailInteract)
        else
          game.Audio.PlayBanter("Brazier_Indecipherable_Freya_Musp", PartiallyFailInteract)
        end
      else
        game.Audio.PlayBanter(banterLine, PartiallyFailInteract)
      end
      return
    end
  end
  if thisObj:FindLuaTableAttribute("IsTowerBrazier") then
    local _, progress = game.QuestManager.GetQuestProgressAndGoal("Quest_Labor_LightBrazier")
    if progress == 0 then
      game.Audio.PlayBanter("Brazier_Light_First", thisObj.Parent.Parent.LuaObjectScript.RealmSpecificBanter)
    elseif 0 < progress and progress < 7 then
      game.Audio.PlayBanter("Brazier_Subsequent_Intro", thisObj.Parent.Parent.LuaObjectScript.RealmSpecificBanter)
    elseif progress == 7 then
      game.Audio.PlayBanter("Brazier_Light_Final", thisObj.Parent.Parent.LuaObjectScript.RealmSpecificBanter)
    end
  elseif Event_OnSuccessfulStart then
    LD.ExecuteCallbacksForEvent(thisLevel, thisObj, Event_OnSuccessfulStart)
  end
end
function FreyaCheck()
  if game.Level.GetVariable("FreyaLTWStage") > 0 and game.Level.GetVariable("FreyaLTWStage") < 500 then
    return true
  else
    return false
  end
end
function CheckForFailureType()
  local cineNumber = game.Level.GetVariable("CompletedCineNumber")
  local lo9Quest = game.QuestManager.GetQuestState("Quest_UnfinishedBusiness05_Parent")
  local muspCipherQuest = game.QuestManager.GetQuestState("Quest_SonLanguage_Muspelheim")
  local nifCipherQuest = game.QuestManager.GetQuestState("Quest_SonLanguage_Niflheim")
  local firstMimirRead = game.Level.GetVariable("MimirBrazierRead")
  local lo9InProgressRead = game.Level.GetVariable("BrazierInProgressRead")
  if firstMimirRead == false and 330 <= cineNumber then
    game.Audio.PlayBanter("Brazier_Mimir_Indecipherable", PartiallyFailInteract)
    game.Level.SetVariable("MimirBrazierRead", true)
  elseif lo9Quest ~= "Inactive" and lo9InProgressRead == false then
    game.Audio.PlayBanter("Brazier_Indecipherable_OneLit", PartiallyFailInteract)
    game.Level.SetVariable("BrazierInProgressRead", true)
  elseif muspCipherQuest == "Inactive" and nifCipherQuest == "Inactive" then
    game.Audio.PlayBanter("Brazier_Indecipherable_None", FailInteract)
  elseif muspCipherQuest ~= "Inactive" or nifCipherQuest ~= "Inactive" then
    if nifCipherQuest == "Inactive" or muspCipherQuest == "Inactive" then
      if language == "Muspelheim" and nifCipherQuest == "Complete" then
        game.Audio.PlayBanter("Brazier_Indecipherable_OneDiscComplete", PartiallyFailInteract)
      elseif language == "Niflheim" and muspCipherQuest == "Complete" then
        game.Audio.PlayBanter("Brazier_Indecipherable_OneDiscComplete", PartiallyFailInteract)
      else
        game.Audio.PlayBanter("Brazier_Indecipherable_OneDiscPartial", PartiallyFailInteract)
      end
    else
      game.Audio.PlayBanter("Brazier_Indecipherable_SomeOfBoth", PartiallyFailInteract)
    end
  end
end
function FailInteract()
  print("Fail callback hit")
  EnableAfterDelay()
  if Event_OnFailure then
    LD.ExecuteCallbacksForEvent(thisLevel, thisObj, Event_OnFailure)
  end
end
function PartiallyFailInteract()
  print("Partial fail callback hit")
  EnableAfterDelay()
  if Event_OnPartialFailure then
    LD.ExecuteCallbacksForEvent(thisLevel, thisObj, Event_OnPartialFailure)
  end
end
function UpdateJournal()
  if journalUpdateID ~= nil and journalUpdateID ~= "" then
    journalUpdateID = string.gsub(journalUpdateID, "%s+", "")
    if game.Resources.HasFlag(journalUpdateID, "LoreMarker") then
      LD.UpdateJournal(journalUpdateID, 1)
    else
      LD.UpdateJournal(journalUpdateID, 2)
    end
  end
  if not mapSummaryComplete then
    if regionSummaryQuest ~= nil and regionSummaryQuest ~= "" then
      regionSummaryQuest = string.gsub(regionSummaryQuest, "%s+", "")
      LD.ActivateAndIncrementQuest(regionSummaryQuest)
    end
    mapSummaryComplete = true
    _G.StartLevelTimer(1.35, GiveXP)
  end
  SoftSave()
end
function GiveXP()
  game.Loot.GrantAward(xpReward, "HERO")
end
function InteractAbort()
  interactObj.LuaObjectScript.InteractAbort()
end
function SoftSave()
  game.SubObject.SoftSave(thisObj)
end
function EnableAfterDelay()
  LD.CallFunctionAfterDelay(interactObj.LuaObjectScript.Enable, enableDelay)
end
function Disable()
  interactObj.LuaObjectScript.Disable()
end
function Enable()
  interactObj.LuaObjectScript.Enable()
end
function OnSaveCheckpoint(level, obj)
  return {mapSummaryComplete = mapSummaryComplete}
end
function OnRestoreCheckpoint(level, obj, tab)
  mapSummaryComplete = tab.mapSummaryComplete
end
local wallRuneReadOverride = {
  SoundEmitter = nil,
  SNDFXLP = "SND_MAG_Rune_Read_Burn_Away_LP",
  StartFrame = 35,
  EndFrame = 178
}
local loreMarkerOverride = {
  SoundEmitter = nil,
  SNDFXLP = "SND_MAG_Rune_Read_Burn_Away_LP",
  StartFrame = 45,
  EndFrame = 178
}
function SoundOnPreStart()
  SoundSetup(wallRuneReadOverride)
end
function WallRuneReadSoundSetup(newEmitter)
  if newEmitter ~= nil then
    wallRuneReadOverride.SoundEmitter = newEmitter
    thisObj:FindSingleGOByName("GenericSonInteract").Child:HideAudio()
  end
  SoundSetup(wallRuneReadOverride)
end
function LoreMarkerRuneReadSoundSetup(newEmitter)
  if newEmitter ~= nil then
    loreMarkerOverride.SoundEmitter = newEmitter
    thisObj:FindSingleGOByName("GenericSonInteract").Child:HideAudio()
  end
  SoundSetup(loreMarkerOverride)
end
function SoundSetup(newSoundTable)
  if newSoundTable ~= nil then
    interactObj.LuaObjectScript.SoundSetup(newSoundTable)
  end
end

-- BEGIN COMPLETIONIST COLLECTIBLE OBSERVATION
do
  function IsComplete()
    return mapSummaryComplete
  end
  function CompletionistCollectibleObserve()
    if type(mapSummaryComplete) ~= "boolean" then return nil end
    local collected = mapSummaryComplete
    return "lore", collected and "collected" or "remaining"
  end
  local function clearActiveCompassMarker()
    pcall(function()
      if type(game) == "table" and type(game.Compass) == "table" and type(game.Compass.FindMarkersByIconClass) == "function" then
        local markers = game.Compass.FindMarkersByIconClass({"SIDE"})
        if type(markers) == "table" then
          for _, id in ipairs(markers) do
            pcall(game.Compass.HideMarker, id)
          end
        end
      end
    end)
  end
  local function notify()
    if mapSummaryComplete then
      clearActiveCompassMarker()
    end
    if thisLevel == nil or type(thisLevel.Name) ~= "string" then return end
    engine.SendHook("COMPLETIONIST_COLLECTIBLE_DIRTY_V1", engine.GetUIWad(),
      "COLLECTIBLE_DIRTY_V1	" .. string.lower(thisLevel.Name))
  end
  local function pack(...) return {n=select('#',...), ...} end
  local unpackValues = unpack or table.unpack
  local function wrap(original)
    return function(...)
      local result = pack(original(...))
      pcall(notify)
      return unpackValues(result, 1, result.n)
    end
  end
  if type(UpdateJournal) == "function" then UpdateJournal = wrap(UpdateJournal) end
  if type(OnPreStart) == "function" then OnPreStart = wrap(OnPreStart) end
  if type(OnRestoreCheckpoint) == "function" then OnRestoreCheckpoint = wrap(OnRestoreCheckpoint) end
end
-- END COMPLETIONIST COLLECTIBLE OBSERVATION
-- BEGIN COMPLETIONIST PROXIMITY V1.1.0
-- Shows the game's native interact hint dot on this collectible out to the
-- map's [Up Arrow] range. Append-only: OnScriptLoaded runs unchanged first;
-- every call below is pcall-guarded.
do
  local probeRows = {
    {"peak180_enttochimneylh", "lore_marker", "lore_marker_peak180enttochimneylhwadcc54f8d5e69b0945a3674ddc65276412", 5, "inktotem", "peak180_ents"},
    {"peak100_entrance", "lore_marker", "lore_marker_peak100entrancewadeda4d87459eae64ba0a1c556edca5809", 10, "sonreadrune", "peak100_ents"},
    {"riv475_freyahouseext", "lore_marker", "lore_marker_riv475freyahouseextwad9a50243a697a924481d49d5c44c980ac", 98, "sonruneread2", "riv475_ents"},
    {"xpl940_beachcave", "lore_marker", "lore_marker_xpl940beachcavewad6093995aaaf7ad4b9830d1be0e7e0684", 120, "psoninteractrune", "quest_lightbeacon_root", "lakeofnine_lightbeacon"},
    {"xpl950_beachmaze", "lore_marker", "lore_marker_xpl950beachmazewad6093995aaaf7ad4b9830d1be0e7e0684", 121, "psoninteractrune", "quest_lightbeacon_root", "lakeofnine_lightbeacon"},
    {"peak500_chimneytop", "lore_marker", "lore_marker_peak500chimneytopwad1d9b928f5f7eab4082f9c52e2f066780", 146, "sonreadrune", "peak500_ents"},
    {"stn200_lakeext", "lore_marker", "lore_marker_stn200lakeextwad64309dc36de48d438409f5abb85cfc92", 152, "sonreadrune", "stn200_ents_nooffset"},
    {"alf690_lakelightlh", "lore_marker", "lore_marker_alf690lakelightlhwade723fb1f62e1ef4a94d19a5eeeef0673", 159, "invisibleinktotem", "alf690_ents_nooffset"},
    {"cal750_rightwing", "lore_marker", "lore_marker_d988f2795775914592a04b62df2726d9", 176, "rune_18", "runereading", "rightwing_gameplay", "cal750_ents"},
    {"xpl225_funerallh", "lore_marker", "lore_marker_xpl225funerallhwadb18d193b7ba34340a8831d0e11ff1b4e", 185, "sonreadrune", "xpl225_ents_nooffset"},
    {"xpl960_beachship", "lore_marker", "lore_marker_xpl960beachshipwad6093995aaaf7ad4b9830d1be0e7e0684", 194, "psoninteractrune", "quest_lightbeacon_root", "lakeofnine_lightbeacon"},
    {"riv200_dangersmain", "lore_marker", "lore_marker_riv200dangersmainwad452dc462aab2814097a8c9a7d317c558", 197, "sonknowledge_underbridge", "riv200_ents"},
    {"riv475_freyahouseext", "lore_marker", "lore_marker_riv475freyahouseextwadd328468a73cead438031e76201fbddc9", 198, "invisibleink_totem_well", "____invisibleink_setup____", "riv475_ents"},
    {"xpl200_funeral", "lore_marker", "lore_marker_xpl200funeralwad0ab993b107a42f41af27749c6749728d", 200, "beachloremarker", "xpl200_ents_nooffset"},
    {"riv085_dangersentrancelh", "lore_marker", "lore_marker_riv085dangersentrancelhwad0359c55688ca5b48bd66cf4ae66fbed3", 208, "riv085_runeread", "riv085_ents"},
    {"peak140_caverndark", "lore_marker", "lore_marker_peak140caverndarkwad3aae61a66981c34082d9e3dcb14c9a39", 213, "inktotem", "peak140_ents"},
    {"alf150_bridgedark", "lore_marker", "lore_marker_alf150bridgedarkwad969e45f02f76844192ec5566056fbfd4", 221, "sonreadrune01", "runeread_beforegroup", "alf150_ents_nooffset"},
    {"xpl125_httklh", "lore_marker", "lore_marker_xpl125httklhwad36f99a6c8537174bbaab95fb9d956455", 225, "questloremarker", "xpl125_ents_nooffset"},
    {"alf440_hiveextlh", "lore_marker", "lore_marker_alf440hiveextlhwad0f75539e19bc0947ba4d6f46ea0a95d2", 243, "sonreadrune", "alf440_ents_nooffset"},
    {"cal500_runevault", "lore_marker", "lore_marker_cal500runevaultwad14f472bb0d9d2e4993d0774cbc755e02", 249, "sonreadrune", "wad", "cal500_ents"},
    {"peak200_chimneylow", "lore_marker", "lore_marker_peak200chimneylowwad29a3fec3318213458a458abb0eb539a2", 250, "sonreadrune", "peak200_ents_nooffset"},
    {"xpl650_masontrailcave", "lore_marker", "lore_marker_xpl650masontrailcavewadb2f0bf0705313e4aa27b33fddd3a0665", 256, "questloremarker", "questloremarker_01", "xpl650_ents_nooffset"},
    {"riv420_forestboarstart", "lore_marker", "lore_marker_riv420forestboarstartwad0c671129ecb3144cbcf4a641a4160b66", 258, "riv420_loremarker", "riv420_ents"},
    {"xpl250_funeralinterior", "lore_marker", "lore_marker_xpl250funeralinteriorwadd1ddaedac0dbac478444718ac2f19211", 262, "questloremarker", "loremarker", "xpl250_ents_nooffset"},
    {"xpl300_stronghold", "lore_marker", "lore_marker_xpl300strongholdwad79d7700bc6e8cf47a77b5403426b5297", 270, "shipruneread", "xpl300_shipruneread", "xpl300_ents_nooffset"},
    {"xpl910_islandshipwreck", "lore_marker", "lore_marker_xpl910islandshipwreckwad6093995aaaf7ad4b9830d1be0e7e0684", 271, "psoninteractrune", "quest_lightbeacon_root", "lakeofnine_lightbeacon"},
    {"peak720_summitascenthub", "lore_marker", "lore_marker_peak720summitascenthubwadda8178f1357e8d45922a657e6f760dd8", 284, "questloremarker", "peak720_ents_nooffset"},
    {"xpl400_huldramines", "lore_marker", "lore_marker_xpl400huldramineswade1701a5ddf529645b442371f82145220", 294, "outsideruneread", "xpl400_qst_nooffset"},
    {"riv475_freyahouseext", "lore_marker", "lore_marker_riv475freyahouseextwad5124f330461a8e42b1659c4517e18c29", 296, "sonreadrune1", "riv475_ents"},
    {"cal250_foothillslh", "lore_marker", "lore_marker_cal250foothillslhwadb456381ff98fb449896acb659da524fa", 299, "loremarker_02_readpoint", "_____infomarkers", "cal250_ents"},
    {"xpl220_funerallh", "lore_marker", "lore_marker_xpl220funerallhwadeea6c57321539249a4d58ca8baa527cb", 314, "questloremarker1", "xpl220_ents_nooffset"},
    {"xpl400_huldramines", "lore_marker", "lore_marker_xpl400huldramineswadf014bd94366e7b49ade008aff1769396", 322, "questdwarvenrunes", "xpl400_qst_nooffset"},
    {"alf150_bridgedark", "lore_marker", "lore_marker_alf150bridgedarkwad76250fcb340065498ff1b75bddd20fcf", 324, "sonreadrune01_alt", "runeread_aftergroup", "alf150_ents_nooffset"},
    {"nid150_calderabridge", "lore_marker", "lore_marker_nid150calderabridgewad2eabc6ebc9dafd40b34cb41a6ffcd2d4", 327, "niflheimstatuec6", "____runeread", "nid150_ents_nooffset"},
    {"cal250_foothillslh", "lore_marker", "lore_marker_cal250foothillslhwad8ab6b877e9062c4b9f0d0f375f8326c1", 331, "invisibleinktotem_01", "_____inktotem", "cal250_ents"},
    {"xpl300_stronghold", "lore_marker", "lore_marker_xpl300strongholdwade361f1b4a04c074b84896263475139ab", 347, "questloremarker", "questloremarker_01", "xpl300_ents_nooffset"},
    {"xpl225_funerallh", "lore_marker", "lore_marker_xpl225funerallhwadfb3c8f6c096b464dafa89220022f8c54", 354, "questloremarker", "xpl225_ents_nooffset"},
    {"xpl200_funeral", "lore_marker", "lore_marker_xpl200funeralwadf8ceaf9fdf59ef4c97b6d4398c23bb9d", 384, "castleloremarker", "xpl200_ents_nooffset"},
    {"xpl425_huldramineslh", "lore_marker", "lore_marker_xpl425huldramineslhwad7f236d968be3c14db2ecde8780a968a0", 392, "questloremarker_xpl425", "xpl425_ents_nooffset"},
    {"xpl170_httkcaver", "lore_marker", "lore_marker_xpl170httkcaverwad776651e16e0bcd4995eaa2ad3e73f56a", 397, "caver_loremarker01", "caver_questlore01", "xpl170_ents_nooffset"},
    {"cal740_leftwing", "lore_marker", "lore_marker_3d2e2f04d7df6a4b9a4e30601432871f", 408, "rune_19", "runereading", "leftwing_gameplay", "cal740_ents"},
    {"cal250_foothillslh", "lore_marker", "lore_marker_cal250foothillslhwad9614e6b2dfd34f4b86e932b59f2aa621", 409, "loremarker_01_readpoint", "_____infomarkers", "cal250_ents"},
    {"riv925_freyacave", "lore_marker", "lore_marker_ab859d0b83766845bb0b0e69023e1c31", 410, "rune_12_well", "riv925_ents"},
  }
  local probeFamily = nil
  local probeDefaultRange = 50
  local probeMember = nil
  local probeErrors = {}

  local function probeLog(text)
    print("[CompletionistProximity] " .. text)
  end

  local function probeError(key, err)
    if not probeErrors[key] then
      probeErrors[key] = true
      probeLog("error " .. key .. " " .. tostring(err))
    end
  end

  local function probeLower(value, prefix)
    if type(value) ~= "string" then return nil end
    value = string.lower(value)
    if string.sub(value, 1, #prefix) == prefix then value = string.sub(value, #prefix + 1) end
    return value
  end

  local function probeName(go)
    if go == nil then return nil end
    local ok, name = pcall(function() return go:GetName() end)
    if ok then return probeLower(name, "go") end
  end

  local function probeParent(go)
    if go == nil then return nil end
    local ok, parent = pcall(function() return go.Parent end)
    if ok then return parent end
  end

  local function probeFind(node, name)
    for _, query in ipairs({name, "go" .. name}) do
      local ok, found = pcall(function() return node:FindSingleGOByName(query) end)
      if ok and found ~= nil then return found end
    end
  end

  local function probeChain(node, row)
    local cursor = node
    for index = 5, #row do
      if cursor == nil or probeName(cursor) ~= row[index] then return false end
      cursor = probeParent(cursor)
    end
    return true
  end

  -- Exact catalogue identity: level plus the owner name path, starting at this
  -- script's object, one of its ancestors, or a named descendant of the object
  -- or its two nearest ancestors. Ambiguous or unmatched objects are left alone.
  local function probeIdentify(obj, levelName)
    local level = probeLower(levelName, "wad_")
    local node = obj
    for depth = 0, 6 do
      if node == nil then break end
      local found
      for _, row in ipairs(probeRows) do
        if row[1] == level then
          local matched = probeChain(node, row)
          if not matched and depth <= 2 then
            local child = probeFind(node, row[5])
            matched = child ~= nil and probeChain(child, row)
          end
          if matched then
            if found ~= nil and found ~= row then return nil, "ambiguous" end
            found = row
          end
        end
      end
      if found ~= nil then return found, depth end
      node = probeParent(node)
    end
    return nil, "unmatched"
  end

  local probeWiden = nil

  -- Hint-only zones the probe owns: no interact range, so no button prompt;
  -- enabled while the range is on and the collectible is not collected.
  local probeEntries = {}
  local probeJoints = {"promptJoint_Son", "zeroJoint", "promptJointFront", "promptJoint", "synchJoint", "linkJoint", "root", "Root", "JORoot", "jointRoot", "joint1", "ApproachPoint", "enabledCollision", "disabledCollision", "Pristine", "Broken1", "approachJoint", "gameJoint", "rewardJoint", "syncJoint", "lootObjLocation", "SpawnDirection", "JOPelvis1", "JOBell1"}
  -- This object's own token (a table address in its Lua state), so the map
  -- can grant art to one object even when two objects claim one catalogue row.
  local probeToken = string.match(tostring({}), "(%x+)$") or "0"
  local probeGranted = {}

  local function probeObserved()
    if type(CompletionistCollectibleObserve) ~= "function" then return nil end
    local ok, _, state = pcall(CompletionistCollectibleObserve)
    if ok then return state end
  end

  local function probeList(...)
    return {n = select("#", ...), ...}
  end

  local function probeChild(go)
    if go == nil then return nil end
    local ok, child = pcall(function() return go.Child end)
    if ok then return child end
  end

  local function probeSonHosts()
    local okSon, son = pcall(function() return thisObj:FindSingleGOByName("GenericSonInteract") end)
    if not okSon or son == nil then return thisObj end
    return probeChild(son), son, thisObj
  end

  -- The object, its descendants breadth first (ref-node Child and grouped
  -- Children), then its parent: joints sit on the meshes, not the roots.
  local function probeTree(root)
    local found, queue, head = {}, {root}, 1
    while queue[head] ~= nil and #found < 48 do
      local node = queue[head]
      head = head + 1
      found[#found + 1] = node
      local child = probeChild(node)
      if child ~= nil then queue[#queue + 1] = child end
      local ok, children = pcall(function() return node.Children end)
      if ok and type(children) == "table" then
        for _, item in ipairs(children) do queue[#queue + 1] = item end
      end
    end
    local parent = probeParent(root)
    if parent ~= nil then found[#found + 1] = parent end
    found.n = #found
    return found
  end

  -- Where the zone's joint is in the world, for the log.
  local function probeWhere(host, joint)
    local ok, position = pcall(function() return host:GetWorldJointPosition(host:GetJointIndex(joint)) end)
    if not ok or position == nil then
      ok, position = pcall(function() return host:GetWorldPosition() end)
    end
    if ok and position ~= nil then
      return string.format("%.1f,%.1f,%.1f", position.x, position.y, position.z)
    end
    return "?"
  end

  -- Joint names the engine reports for a host, when it has such calls; the
  -- static puzzle meshes list no joint names in the level data.
  local function probeJointNames(host)
    local names, info = {}, {}
    for _, method in ipairs({"GetJointCount", "GetNumJoints"}) do
      local ok, value = pcall(function() return host[method](host) end)
      if ok and value ~= nil then info[#info + 1] = method .. "=" .. tostring(value) end
    end
    for index = 0, 8 - 1 do
      local ok, value = pcall(function() return host:GetJointName(index) end)
      if ok and type(value) == "string" and value ~= "" then names[#names + 1] = value end
    end
    if #names > 0 then info[#info + 1] = "names=" .. table.concat(names, ",") end
    return names, table.concat(info, " ")
  end

  local function probeCreate(hosts, icon, range)
    local last, tried = "no host", {}
    for index = 1, hosts.n do
      local host = hosts[index]
      if host ~= nil then
        local joints = probeJoints
        local reported, info = probeJointNames(host)
        if #reported > 0 then
          joints = {}
          for _, joint in ipairs(probeJoints) do joints[#joints + 1] = joint end
          for _, joint in ipairs(reported) do joints[#joints + 1] = joint end
        end
        if #tried < 24 then
          tried[#tried + 1] = tostring(probeName(host)) .. (info ~= "" and ("{" .. info .. "}") or "")
        end
        for _, joint in ipairs(joints) do
          local ok, zone = pcall(function() return game.InteractZone.New(host, joint) end)
          if ok and zone ~= nil then
            local okSetup, err = pcall(function()
              zone:SetTemplateValues({
                name = "Completionist Hint",
                interactFrontAngleMax = 360,
                yRangeMax = 0,
                xzRange = 0,
                xzRangeMax = 0,
                hintXZRange = range,
                hintYRange = range,
                onScreenPercentMin = 1,
                onScreenPercentMax = 0.01,
                onScreenPercentWeight = 0,
                cameraFrontAngleMax = 360
              })
              zone:SetTags("NotInCombat")
              zone:SetPromptIconSet({
                normal = "WORLD_INTERACT_LOOT",
                unavailable = "WORLD_INTERACT_UNAVAILABLE_LOOT",
                locked = "WORLD_INTERACT_LOCKED_LOOT",
                hint = icon
              })
            end)
            if not okSetup then return nil, "setup " .. tostring(err) end
            -- Hints show only within this angle of the joint's facing; the
            -- game uses 360 for hints seen from every side (xpl950_beachmaze).
            local okAngle, angleErr = pcall(function() zone:SetHintAngle(360) end)
            if not okAngle then probeError("hint_angle", angleErr) end
            return zone, tostring(probeName(host)) .. "/" .. joint .. " pos=" .. probeWhere(host, joint)
          end
          last = tostring(zone)
        end
      end
    end
    return nil, last .. " tried=" .. table.concat(tried, ",")
  end

  -- art: reports this collectible to the map, which shows its family art as a
  -- compass marker; while it does, the token is granted and dots give way.
  -- dot: a white hint zone where no stock zone is widened.
  local function probeAdd(key, family, hosts, done, dot, token)
    probeEntries[#probeEntries + 1] = {key = key, family = family, kind = "art", hosts = hosts, done = done,
      token = token}
    if dot then
      probeEntries[#probeEntries + 1] = {key = key, family = family, kind = "dot", hosts = hosts, done = done,
        token = token, icon = "WORLD_INTERACT_HINT_LOOT"}
    end
  end

  local function probeBuild()
    probeAdd(probeMember.id, probeMember.family, function() return probeList(probeSonHosts()) end,
      function() return probeMember.mapCollected == true or (probeObserved() == "collected") end, true, probeToken)
  end

  -- A zone that is no longer wanted is destroyed, not just disabled.
  local function probeDrop(entry)
    local zone = entry.zone
    entry.zone, entry.applied = nil, nil
    pcall(function() zone:Disable() end)
    local ok = pcall(function() zone:Destroy() end)
    probeLog("zone " .. entry.key .. " kind=" .. entry.kind .. " family=" .. entry.family ..
      " dropped destroyed=" .. tostring(ok))
  end

  local function probeEntry(entry, range)
    local okDone, done = pcall(entry.done)
    local show = range > 0 and not (okDone and done == true) and not probeGranted[entry.token]
    if entry.kind == "art" then
      if entry.zone ~= nil then probeDrop(entry) end
      return
    end
    if entry.zone == nil then
      if not show or (entry.failures or 0) >= 5 then return end
      local okHosts, hosts = pcall(entry.hosts)
      local zone, where = nil, tostring(hosts)
      if okHosts and type(hosts) == "table" then zone, where = probeCreate(hosts, entry.icon, range) end
      if zone == nil then
        entry.failures = (entry.failures or 0) + 1
        probeError("zone " .. entry.key .. " " .. entry.kind, where)
        return
      end
      entry.zone, entry.where = zone, where
    end
    local ok, err = pcall(function()
      if show then
        entry.zone:SetHintXZRange(range)
        entry.zone:SetHintYRange(range)
        entry.zone:Enable()
      else
        entry.zone:Disable()
      end
    end)
    if not ok then
      probeError("hint " .. entry.key .. " " .. entry.kind, err)
      return
    end
    local applied = show and range or 0
    if entry.applied == applied then return end
    entry.applied = applied
    probeLog("zone " .. entry.key .. " kind=" .. entry.kind .. " family=" .. entry.family .. " at=" ..
      tostring(entry.where) .. " shown=" .. tostring(show) .. " range=" .. tostring(range))
  end

  -- Rows the map store holds as collected (what hides their map pins) get no
  -- dots and the stock hint distance. Probe-owned zones wait for the map's
  -- first broadcast, so a collected row never flashes at load.
  local function probeApply(range)
    local member = probeMember
    if member == nil then return end
    if member.mapCollected then range = 0 end
    range = math.min(range, 25)
    if probeWiden ~= nil then probeWiden(probeGranted[probeToken] and 0 or range) end
    if not member.mapSeen then return end
    for _, entry in ipairs(probeEntries) do probeEntry(entry, range) end
  end

  -- Each collectible this object carries tells the map where it is and
  -- whether it is done; the map grants art from these reports.
  local function probeReport()
    local route = engine.GetUIWad()
    for _, entry in ipairs(probeEntries) do
      if entry.kind == "art" then
        local okDone, done = pcall(entry.done)
        local position
        local okHosts, hosts = pcall(entry.hosts)
        if okHosts and type(hosts) == "table" then
          for index = 1, hosts.n do
            if position == nil and hosts[index] ~= nil then
              local ok, value = pcall(function() return hosts[index]:GetWorldPosition() end)
              if ok and value ~= nil then position = value end
            end
          end
        end
        -- This object's own CompletionistCollectibleObserve answer, which the
        -- map cannot read itself (LuaObjectScript is nil from the UI state).
        local observed = "-"
        if entry.key == probeMember.id then
          local seen = probeObserved()
          if seen == "collected" then observed = "c" elseif seen == "remaining" then observed = "r" end
        end
        if position ~= nil then
          engine.SendHook("COMPLETIONIST_PROXIMITY23_REPORT", route, string.format("PROX23R|%s|%s|%s|%.1f|%.1f|%.1f|%d|%s",
            entry.token, entry.key, entry.family, position.x, position.y, position.z,
            (okDone and done == true) and 1 or 0, observed))
        end
      end
    end
  end

  local function probeRangeHook(...)
    for index = 1, select("#", ...) do
      local value = select(index, ...)
      if type(value) == "string" then
        local range, collected, art = string.match(value, "^PROX23|(%d+)|([%d,]*)|([%w,]*)$")
        if range ~= nil then
          local member = probeMember
          if member ~= nil and member.index ~= nil then
            local mapCollected = false
            for number in string.gmatch(collected, "%d+") do
              if tonumber(number) == member.index then mapCollected = true end
            end
            member.mapSeen, member.mapCollected = true, mapCollected
          end
          probeGranted = {}
          for token in string.gmatch(art, "%w+") do probeGranted[token] = true end
          local ok, err = pcall(probeApply, tonumber(range))
          if not ok then probeError("apply", err) end
          local okReport, reportErr = pcall(probeReport)
          if not okReport then probeError("report", reportErr) end
          return
        end
      end
    end
  end

  local function probeStart()
    if probeMember ~= nil then return end
    local row, detail
    if probeFamily ~= nil then
      row, detail = {nil, probeFamily, probeFamily .. ":" .. tostring(probeName(thisObj))}, "script"
    else
      row, detail = probeIdentify(thisObj, thisLevel and thisLevel.Name)
    end
    if row == nil then
      probeLog("unidentified reason=" .. tostring(detail) .. " level=" ..
        tostring(thisLevel and thisLevel.Name) .. " object=" .. tostring(probeName(thisObj)))
      return
    end
    probeMember = {id = row[3], family = row[2], index = row[4], mapSeen = row[4] == nil}
    local okBuild, buildErr = pcall(probeBuild)
    if not okBuild then probeError("build", buildErr) end
    local okThunk, thunk = pcall(require, "core.thunk")
    if okThunk and type(thunk) == "table" and type(thunk.Install) == "function" then
      local okInstall, err = pcall(thunk.Install, "COMPLETIONIST_PROXIMITY23_SHOW", probeRangeHook)
      if not okInstall then probeError("hook", err) end
    else
      probeError("thunk", thunk)
    end
    probeLog("identified id=" .. row[3] .. " family=" .. row[2] .. " depth=" .. tostring(detail))
    probeApply(probeDefaultRange)
  end

  local function probePack(...)
    return {n = select("#", ...), ...}
  end
  local probeOriginalLoaded = OnScriptLoaded
  if type(probeOriginalLoaded) == "function" then
    function OnScriptLoaded(...)
      local results = probePack(probeOriginalLoaded(...))
      local ok, err = pcall(probeStart)
      if not ok then probeError("start", err) end
      return unpack(results, 1, results.n)
    end
  end
end
-- END COMPLETIONIST PROXIMITY V1.1.0
