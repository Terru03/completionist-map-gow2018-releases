<#
.SYNOPSIS
    Universal 1-Click Installer for God of War (2018) Completionist Map Mod.
.DESCRIPTION
    Auto-detects God of War install folder across Steam, Epic Games, custom drives,
    or user prompt. Safely backs up stock game files before copying mod files.
#>
param(
    [string]$TargetDir = ""
)

$ErrorActionPreference = "Stop"

# Keep existing ReShade through D3D11. No preset or shader writes.
function Get-CompletionistCompatHash([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Test-CompletionistReShade([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    return (Get-Item -LiteralPath $Path).VersionInfo.ProductName -eq 'ReShade'
}

function Test-CompletionistDxgiOwnership([string]$Hash) {
    return $Hash -in @($completionistKnownPayloads.PSObject.Properties['dxgi.dll'].Value)
}

function Assert-CompletionistCompatPath([string]$Game, [string]$Path) {
    $root = [IO.Path]::GetFullPath($Game).TrimEnd('\')
    $full = [IO.Path]::GetFullPath($Path)
    if (-not $full.StartsWith($root + '\', [StringComparison]::OrdinalIgnoreCase)) {
        throw 'ReShade compatibility path outside game folder.'
    }
    $current = $full
    while ($current.Length -gt $root.Length) {
        $item = Get-Item -LiteralPath $current -Force -ErrorAction SilentlyContinue
        if ($item -and ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
            throw 'ReShade compatibility path uses a link; no files changed.'
        }
        $current = [IO.Path]::GetDirectoryName($current)
    }
}

function Assert-CompletionistReShade64([string]$Path) {
    $stream = [IO.File]::OpenRead($Path)
    $reader = New-Object IO.BinaryReader($stream)
    try {
        if ($stream.Length -lt 64 -or $reader.ReadUInt16() -ne 0x5A4D) { throw 'Invalid ReShade PE header.' }
        $stream.Position = 0x3C
        $offset = $reader.ReadInt32()
        if ($offset -lt 64 -or $offset -gt $stream.Length - 6) { throw 'Invalid ReShade PE offset.' }
        $stream.Position = $offset
        if ($reader.ReadUInt32() -ne 0x4550 -or $reader.ReadUInt16() -ne 0x8664) {
            throw 'God of War needs 64-bit ReShade. No game files changed.'
        }
    } finally { $reader.Dispose() }
}

function Read-CompletionistReShadeRecord([string]$Game) {
    $path = Join-Path $Game 'completionist_backup\reshade-compat.json'
    Assert-CompletionistCompatPath $Game $path
    if (-not (Test-Path -LiteralPath $path)) { return $null }
    $record = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
    if ($record.schema -ne 1 -or $record.sha256 -notmatch '\A[0-9a-f]{64}\z' -or
        $record.dxgi_sha256 -notmatch '\A[0-9a-f]{64}\z' -or
        -not (Test-CompletionistDxgiOwnership $record.dxgi_sha256)) {
        throw 'Invalid ReShade compatibility record; no files changed.'
    }
    if ($record.previous_alias_sha256 -and $record.previous_alias_sha256 -notmatch '\A[0-9a-f]{64}\z') {
        throw 'Invalid pending ReShade alias hash; no files changed.'
    }
    return $record
}

function Get-CompletionistReShadePlan([string]$Game, $PackageManifest) {
    $payload = $PackageManifest.files.PSObject.Properties['dxgi.dll']
    if (-not $payload) { return $null }
    $expected = $payload.Value.sha256
    if ($expected -notmatch '\A[0-9a-f]{64}\z') { throw 'Invalid Completionist DXGI hash.' }
    $rootDll = Join-Path $Game 'dxgi.dll'
    $alias = Join-Path $Game 'd3d11.dll'
    Assert-CompletionistCompatPath $Game $rootDll
    Assert-CompletionistCompatPath $Game $alias
    $record = Read-CompletionistReShadeRecord $Game
    $source = $null
    if (Test-CompletionistReShade $rootDll) {
        $source = $rootDll
    } else {
        $rootHash = if (Test-Path -LiteralPath $rootDll -PathType Leaf) { Get-CompletionistCompatHash $rootDll } else { $null }
        if ($rootHash -and $rootHash -ne $expected -and -not (Test-CompletionistDxgiOwnership $rootHash)) {
            throw 'Another mod owns dxgi.dll. No game files changed.'
        }
        if ($record -and (Test-CompletionistReShade $alias) -and
            (Get-CompletionistCompatHash $alias) -ne $record.sha256 -and
            (Get-CompletionistCompatHash $alias) -ne $record.previous_alias_sha256) {
            $source = $alias
        } elseif ($record) {
            $saved = Join-Path $Game ('completionist_backup\reshade-compat\' + $record.sha256 + '.dll')
            Assert-CompletionistCompatPath $Game $saved
            if (-not (Test-Path -LiteralPath $saved -PathType Leaf) -or
                (Get-CompletionistCompatHash $saved) -ne $record.sha256 -or
                -not (Test-CompletionistReShade $saved)) { throw 'ReShade recovery copy changed; no files changed.' }
            $source = $saved
        } elseif ($rootHash -eq $expected) {
            $saved = Join-Path $Game 'completionist_backup\dxgi.dll'
            Assert-CompletionistCompatPath $Game $saved
            if (Test-CompletionistReShade $saved) {
                $backupPath = Join-Path $Game 'completionist_backup\backup_manifest.json'
                Assert-CompletionistCompatPath $Game $backupPath
                $backup = Get-Content -LiteralPath $backupPath -Raw | ConvertFrom-Json
                $proof = $backup.files.PSObject.Properties['dxgi.dll']
                if (-not $proof -or $proof.Value -ne (Get-CompletionistCompatHash $saved)) {
                    throw 'ReShade backup hash mismatch; no files changed.'
                }
                $source = $saved
            }
        }
    }
    if (-not $source) { return $null }
    if (-not (Test-CompletionistDxgiOwnership $expected)) { throw 'Unsupported Completionist DXGI build for ReShade repair.' }
    Assert-CompletionistReShade64 $source
    $digest = Get-CompletionistCompatHash $source
    $replaceAliasHash = $null
    if ((Test-Path -LiteralPath $alias) -and (Get-CompletionistCompatHash $alias) -ne $digest) {
        $aliasHash = Get-CompletionistCompatHash $alias
        if ($record -and $aliasHash -in @($record.sha256, $record.previous_alias_sha256) -and (Test-CompletionistReShade $alias)) {
            $replaceAliasHash = $aliasHash
        } else { throw 'd3d11.dll already used by another DLL. No game files changed.' }
    }
    return [PSCustomObject]@{ Source=$source; Hash=$digest; DxgiHash=$expected; ReplaceAliasHash=$replaceAliasHash }
}

function Save-CompletionistReShade([string]$Game, $Plan) {
    if (-not $Plan) { return }
    $folder = Join-Path $Game 'completionist_backup\reshade-compat'
    $saved = Join-Path $folder ($Plan.Hash + '.dll')
    Assert-CompletionistCompatPath $Game $saved
    [IO.Directory]::CreateDirectory($folder) | Out-Null
    if (-not (Test-Path -LiteralPath $saved)) { [IO.File]::Copy($Plan.Source, $saved, $false) }
    if ((Get-CompletionistCompatHash $saved) -ne $Plan.Hash) { throw 'ReShade recovery copy mismatch.' }
    $recordPath = Join-Path $Game 'completionist_backup\reshade-compat.json'
    Assert-CompletionistCompatPath $Game $recordPath
    $record = @{ schema=1; sha256=$Plan.Hash; dxgi_sha256=$Plan.DxgiHash }
    if ($Plan.ReplaceAliasHash) { $record.previous_alias_sha256 = $Plan.ReplaceAliasHash }
    $record = $record | ConvertTo-Json
    Write-CompletionistText $recordPath $record
}

function Enable-CompletionistReShade([string]$Game, $Plan) {
    if (-not $Plan) { return }
    $saved = Join-Path $Game ('completionist_backup\reshade-compat\' + $Plan.Hash + '.dll')
    $alias = Join-Path $Game 'd3d11.dll'
    Assert-CompletionistCompatPath $Game $saved
    Assert-CompletionistCompatPath $Game $alias
    if ((Get-CompletionistCompatHash $saved) -ne $Plan.Hash) { throw 'ReShade recovery copy changed.' }
    if (-not (Test-CompletionistReShade $saved)) { throw 'Recovery copy is not ReShade.' }
    Assert-CompletionistReShade64 $saved
    if ($Plan.ReplaceAliasHash -and (Test-Path -LiteralPath $alias) -and
        (Get-CompletionistCompatHash $alias) -eq $Plan.ReplaceAliasHash) {
        Copy-CompletionistDxgi $saved $alias
    }
    if (-not (Test-Path -LiteralPath $alias)) { [IO.File]::Copy($saved, $alias, $false) }
    if ((Get-CompletionistCompatHash $alias) -ne $Plan.Hash) { throw 'd3d11.dll changed during install.' }
    if ($Plan.DxgiHash) {
        $recordPath = Join-Path $Game 'completionist_backup/reshade-compat.json'
        $record = @{ schema=1; sha256=$Plan.Hash; dxgi_sha256=$Plan.DxgiHash } | ConvertTo-Json
        Write-CompletionistText $recordPath $record
    }
    Write-Host '[+] ReShade preserved through d3d11.dll; preset and shaders kept.' -ForegroundColor Green
}

function Assert-CompletionistReShadeRemoval([string]$Game) {
    $record = Read-CompletionistReShadeRecord $Game
    if (-not $record) { return }
    $rootDll = Join-Path $Game 'dxgi.dll'
    $alias = Join-Path $Game 'd3d11.dll'
    Assert-CompletionistCompatPath $Game $rootDll
    Assert-CompletionistCompatPath $Game $alias
    $pendingAlias = $record.previous_alias_sha256 -and (Test-CompletionistReShade $alias) -and
        (Get-CompletionistCompatHash $alias) -eq $record.previous_alias_sha256
    if ((Test-CompletionistReShade $rootDll) -or
        ((Test-Path -LiteralPath $alias) -and -not $pendingAlias)) { return }
    $saved = Join-Path $Game ('completionist_backup/reshade-compat/' + $record.sha256 + '.dll')
    Assert-CompletionistCompatPath $Game $saved
    if (-not (Test-Path -LiteralPath $saved -PathType Leaf) -or
        (Get-CompletionistCompatHash $saved) -ne $record.sha256 -or -not (Test-CompletionistReShade $saved)) {
        throw 'ReShade recovery copy changed; no files changed.'
    }
    Assert-CompletionistReShade64 $saved
}

function Copy-CompletionistDxgi([string]$Source, [string]$Destination) {
    $temporary = $Destination + '.completionist-' + [Guid]::NewGuid().ToString('N') + '.tmp'
    try {
        [IO.File]::Copy($Source, $temporary, $false)
        if ((Get-CompletionistCompatHash $temporary) -ne (Get-CompletionistCompatHash $Source)) { throw 'DXGI copy mismatch.' }
        if (Test-Path -LiteralPath $Destination) { [IO.File]::Replace($temporary, $Destination, [NullString]::Value) }
        else { [IO.File]::Move($temporary, $Destination) }
    } finally {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force }
    }
}

function Test-CompletionistKeepReShade([string]$Game, [string]$BackupDll) {
    if (Test-CompletionistReShade (Join-Path $Game 'dxgi.dll')) { return $true }
    return (Test-CompletionistReShade $BackupDll) -and
        (Test-CompletionistReShade (Join-Path $Game 'd3d11.dll'))
}

function Remove-CompletionistDxgiAfterReShade([string]$Game) {
    $record = Read-CompletionistReShadeRecord $Game
    if (-not $record) { return $false }
    $rootDll = Join-Path $Game 'dxgi.dll'
    Assert-CompletionistCompatPath $Game $rootDll
    if ((Test-Path -LiteralPath $rootDll -PathType Leaf) -and
        (Get-CompletionistCompatHash $rootDll) -eq $record.dxgi_sha256) {
        Remove-Item -LiteralPath $rootDll -Force
    }
    $alias = Join-Path $Game 'd3d11.dll'
    Assert-CompletionistCompatPath $Game $alias
    if ($record.previous_alias_sha256 -and -not (Test-CompletionistReShade $rootDll) -and
        (Test-CompletionistReShade $alias) -and
        (Get-CompletionistCompatHash $alias) -eq $record.previous_alias_sha256) {
        Enable-CompletionistReShade $Game ([PSCustomObject]@{ Hash=$record.sha256; ReplaceAliasHash=$record.previous_alias_sha256 })
    }
    if (-not (Test-CompletionistReShade $rootDll) -and -not (Test-CompletionistReShade $alias)) {
        if (Test-Path -LiteralPath $alias) {
            Write-Host '[!] Changed d3d11.dll preserved; ReShade recovery backup kept.' -ForegroundColor Yellow
            return $true
        }
        Enable-CompletionistReShade $Game ([PSCustomObject]@{ Hash=$record.sha256 })
    }
    if ($record.previous_alias_sha256) {
        $activeCurrent = ((Test-CompletionistReShade $rootDll) -and (Get-CompletionistCompatHash $rootDll) -eq $record.sha256) -or
            ((Test-CompletionistReShade $alias) -and (Get-CompletionistCompatHash $alias) -eq $record.sha256)
        if (-not $activeCurrent) {
            Write-Host '[!] Pending ReShade update backup kept.' -ForegroundColor Yellow
            return $true
        }
    }
    Write-Host '[+] Existing ReShade and presets kept.' -ForegroundColor Green
    return $false
}

function Remove-CompletionistUnbackedPayloads([string]$Game, [string]$PackageRoot, $OriginalFiles) {
    $packagePath = Join-Path $PackageRoot 'manifest.json'
    if (-not (Test-Path -LiteralPath $packagePath -PathType Leaf)) { return }
    $package = Get-Content -LiteralPath $packagePath -Raw | ConvertFrom-Json
    $allowed = @(
        'dxgi.dll',
        'mods/loader_config.toml',
        'exec/dc/pc_le/mapcoords.dcb',
        'exec/dc/pc_le/mapmaster.dcb',
        'exec/dc/pc_le/wad_r_perm.dcb',
        'exec/dc/pc_le/wad_r_ui.dcb',
        'exec/patch/pc_le/completionist_v105_family_art.texpack',
        'exec/patch/pc_le/completionist_v105_family_art.texpack.toc',
        'exec/wad/pc_le/r_ui.wad',
        'mods/completionist-map/native/collectible-base-dxgi.dll',
        'mods/completionist-map/native/raven-native-bridge-manifest.json',
        'mods/lua/gameart/scripts/levels/gameplaymodules/interactive/triptychs/interact_triptych.lua',
        'mods/lua/gameart/scripts/levels/gameplaymodules/progression/interact_chest_runic.lua',
        'mods/lua/gameart/scripts/levels/gameplaymodules/progression/interact_chest_standard.lua',
        'mods/lua/gameart/scripts/levels/gameplaymodules/progression/interact_loot_artifact.lua',
        'mods/lua/gameart/scripts/levels/gameplaymodules/progression/interact_loot_dirtdig.lua',
        'mods/lua/gameart/scripts/levels/gameplaymodules/progression/interact_loot_pocketrift.lua',
        'mods/lua/gameart/scripts/levels/gameplaymodules/progression/precisionchallenge.lua',
        'mods/lua/gameart/scripts/levels/gameplaymodules/soninteracts/langcheckruneread.lua',
        'mods/lua/gameart/scripts/levels/gameplaymodules/soninteracts/sonlanguagepickup.lua',
        'mods/lua/gameart/ui/scripts/inworldmenu/mapmenu.lua'
    )
    foreach ($relative in $allowed) {
        if ($OriginalFiles.PSObject.Properties[$relative]) { continue }
        if ($relative -eq 'mods/loader_config.toml' -and (Test-Path -LiteralPath (Join-Path $Game 'version.dll'))) {
            continue
        }
        $entry = $package.files.PSObject.Properties[$relative]
        if (-not $entry -or $entry.Value.sha256 -notmatch '\A[0-9a-f]{64}\z') { continue }
        $target = Join-Path $Game $relative
        Assert-CompletionistCompatPath $Game $target
        if ((Test-Path -LiteralPath $target -PathType Leaf) -and
            (Get-CompletionistCompatHash $target) -eq $entry.Value.sha256) {
            Remove-Item -LiteralPath $target -Force
        }
    }
}

# Shared config stays. Unknown mod scripts stop install.
$completionistKnownPayloads = @'
{"dxgi.dll":["ecf448b5634aa8b3afe37a10e339f3cf53eb85c8b9d614a7fbfa72a50355a56c","05d98222e23f7e2150d9a745c81eca4066350eb96d2d88ba747e10c226aa1427","6b0e47855122218fe658fe409acae860c551cd051ac0407a9d860768e4124643","7bace63175d9f12b058d416ad884af8b00e5927f490d4c917a5510e734d8bbf8","6aad2b5880a9d664b42725c12a24168f8700e380a46bf26f59a4fda130e18bef","ab86e99b410086357edb57e1ffcc3736d2f0adc85dbafb48891c8ec0b3d7dea6","948e1131d23e1d34f1b0beb5cb8187acee16f480e0370c54da7ca1e3d222550e","2eea820b1ba7ceddce7b6957ca2ee5f34496b43f93957e6ad5d04b4380f2d8eb","776d4df10f89d75202b0043f0a6f78c1e6fde5e6b8a80b41141240c3b94fd306","0ef00460f1bf5cc3bf719c99a2a8ab8b8382196e3f9041e1b07c86d8850e5ddc","5876defc3fbc10d34b4453c082be69f70d182045515e20d31ccf38e8215671f5","923afa1bc59751722f32351ffc17d337ef86beec4a89066dee6909d4e226357e","fe427a11d190dbd7c39377566da6d54487f209f2b5c1126d1656ff2a11321e1a"],"exec/dc/pc_le/mapcoords.dcb":["0ed129042219f0a99ceda02b38d98521276ed94c8491d64e8e599746f0197b8c","5117caed652ec9120a5da3d7531001ab5254580980c4d0ea0476c0d0e9f0a9c2","5117caed652ec9120a5da3d7531001ab5254580980c4d0ea0476c0d0e9f0a9c2","7644b280ee4bedc1af7a4d81d5e1aacfaaac91ec8795c8f2f4434b4fa0534772"],"exec/dc/pc_le/mapmaster.dcb":["88cd527582efe5d708d465e6593921e92164831b9b2d34bd36c5b47aa0ec920d"],"exec/dc/pc_le/wad_r_perm.dcb":["217048e876014869608f873ddb02550d9e29b3d3dc66427ad6a41c0649ec6841"],"exec/dc/pc_le/wad_r_ui.dcb":["9a22b36bb09167f967ab708471fab253b1292ed733dc1347a41f02e802c102c6"],"exec/patch/pc_le/completionist_v105_family_art.texpack":["eafeb31882ceff41dc50b1d6cd3057fb57f5e6a83585a9992b6044f606603485"],"exec/patch/pc_le/completionist_v105_family_art.texpack.toc":["31a97b87a27623a5b1b023113afc288b5e435a8ecca2a372d1da69e18f8f28f4"],"exec/wad/pc_le/r_ui.wad":["44866aaa861a62dd4d4aacad5dd39881728e055925d6113e26f2dfaa03143204"],"mods/completionist-map/native/collectible-base-dxgi.dll":["9043eac673ae15cd4f4b5c2f5bc96c64d17aa1fd613d588ce2547532fcb8f02c","2ce810e0f969d44bedb944db375a715c7eadd26e96830af924e5a8a50aaa668a"],"mods/completionist-map/native/raven-native-bridge-manifest.json":["4ea73ef34b461867c82b02cc5e66e39d6cf946467631f1c1fb7b63c3c4da2ca4","1d210335ee687bcaf2c39d31766f5f22311ce4f6ca56a3cc1509a6656f2b7426","1c477f6f90a7d0de0c871885e5abff9fcf9a4347d420a095a8ec0f5f24fe1191","be934b4ea8c9468991abd0b5468c9b2bc7cf9fe1118c53c0a95b36e479961742","b1c7e55a60afa9230263dc0333c8a81ae45da7bac1e74ae4d88171d6206526c1","a452dceaa7d4ebbf557773ed84984a0f1cb04a1cddef883125c24a9579bc3547","64bb82a167a6d3b5eb356de0fa1a1a132da517aac4d9de6d2f9bcc2252d041f5","df79b017bf13e117f9fae7f253bdde88b6a2c569e38364a2f73303f75ac4af8a","4cc161c7884c8d2b8c5560a45a0cdfb4ae9a879b6b4206b2e453d11bb3b72597","f5da4af2e780a28df60c20a0e9e4d14d002ab9dc55af76c678f26a6d1a9524de","9e011761beccf5f1d618e8ba80c6ede1c0a26384d40fe875b7218cefbff34139","4ea73ef34b461867c82b02cc5e66e39d6cf946467631f1c1fb7b63c3c4da2ca4"],"mods/lua/gameart/scripts/levels/gameplaymodules/interactive/triptychs/interact_triptych.lua":["802f9b79c485c8945ddd2d300aadc28b312594c446d0ef690eeff35aff9369c3","6daf6bb69cb2efb7d17fc6f8972435998e10b23b903ad129c1e4ee7ba9edf2cc","95951123ac70aca8132763919d8e25caa371295d0fb0e27c7aa66f91ca03dd27","ac7f2ce658b4ef3563c1a0e96bf2e957283e2720c4a617589cc90a027b35d006","fd5deca3910621eb4cae6820eb47f9f14a57118f2deece38bfb6e8d55231e06a","a02a3b9b21840517bfc361ee3364710deda4382fbc6aacddc6f6d8d875f00de0","a5c42b8b8650f24172b52163e5c6f0c735322f71a08aead967d04d3d31703423","89c24051c4e6ce7ab934db71194bdbcc754a9aa6ceeff5933e8b7e83e1df2fb1","51697b2941289f03c793ab00cb6d526aef0437e044fb83012119875500cdb34d","f117841aec3b80b494330d46bc0fbd21af00e2d771579c2e7ee54aa565c7066b","54770b641c3a63fcbffcea4c8791de8c1dc293f38e5298ddc6428cf3957bb6d7","3778ddc8414b439cf21febf9f497c5c2c26aa9fcd8012b060523bdb7841f5125","8cf33015fec153d3820b653faf6bfaec985ed665b10707d9297afcfcd8a43159","e5ac07f69517cacdd6336f93139af1e26e7ae9ef450f084451d2a75682bb5d5d","8ff0a7b7f6e2b97667ca35dce88e8b81f3ba6c649b0bcc89c3cec4f9ac69ca28","8b31a5d42cc24765ce23bd416d3a06fbbb89f330a9b780d8ae77706a31f7f5f7","4e828f4cfe3a66981af48febc72558942cbc5c83bda679eae3b6a985e6b765dc","bd685a0b565dad9a9a3702763968859497a3a755d35f904cb55fbe25177c0cf5","5d9bdab90a9422b4b34d610d79bf77a43ebe2afbfb2732a0ba6d4068139e0de4","1adf613ffc496e17ab85b57b3a41f9d3004be462a04497ad91b494fd027432f0","9cc7a16407005a2fc16359c80fed4cd1f39eb8b8d3d96811e4a82df8a56ba627"],"mods/lua/gameart/scripts/levels/gameplaymodules/progression/interact_chest_runic.lua":["7151b45579d9837dab8c2b2ac5e1b6b3ab8f75d1ddab035cd48811da9816de7d","caa911104d03de11fcb99c241fec83c4137c949b2fc1d33e45dd5b29092fae3c","5a7e30f00079c71568cf66c7d34c79fd05ae1094593aa0c607368bbf6d5cb12c","252cc44b5b9f80a3026b328e54dd7c52d67553b229b224ff3c01d1e690474ed4","5b18657934be22a3de76e0e0b792bb4dc39f12fb1953680f2295891abcd0af55","54db1710886a13dcd0403ea773b6982dc2ea5c0d25ccc7b1ccc152ea7218ff0f","9b52fe97b07c86b8b151284d01e535047ae7a47c1f1c190966374b5d9affe633","95955c9fb482c463149232e7af4f1bca36822428fe5ec3ede9e115186abe6bad","ce86d763e9972c933e3c52bceb8108d3e82f49912a6ff155b4f24be7b3d46fba","98114293e73c08c3a450d134577456e77c7548cc4798d79db7aafe6056ed0e0b","c8a64747f6ac5cb32921cbf34dbb83e04561d1ed58c368dfd55e6e6d8ec79161","a4a73296e36c07b0da44413365ac5c87fcab9fd4d454b11edaa75a40e927e5a8","e7073e47ea8d19ea4a4faae1117fb98610910259cc43f84154f22045941455e8","e9dfb1a6a686b7e1e86c64338566b00eceacc8ae6d90d8cf03a5dd994fbdae23","e9c77fbaa9ba8d678d0ade38f1016b83dd20ebda9d252189973490a1c73ff454"],"mods/lua/gameart/scripts/levels/gameplaymodules/progression/interact_chest_standard.lua":["11811cd6651f3d6b2d5694eb30be0fc2652aaa44915ebf3db0029ca8a861014d","7a0313cbe39c24e1ee50bb07e4e322feaec0549508b1b8b240a6e87f69cdda02","fd5e33bc3867e7860eac552d74a9acdd385e8f999fdca3faa03cbf30938e4d94","8b9a786c4799b88fe7134338181b81fc2f8eaf3200058453e272859515fefb59","561be38b5b06b08a54ebdcbedf57a29aca8e5df8afefae70bd4fe510b14edc2b","6b962eda2592e92622f19b1cc7c8f808dfdfe16fa17766c27bbb457289a81482","56b77ed9d8a178793ac7fa57bcec7a73b16acdf6f1670d737532e99a77446bed","182e654b27bdd1999cbf338f17de4adc30865beb70a3bc2ef6243b0f9b8bf6c7","c2d4309b2e1b85f5fcf4abfc84ecf12cf12bc8fe28b87cbdaad4ebfd6f932f8c","0d1c8bb22a6074c39f964984f67b92e5b3eaa0f9d8f67eecb63a1ff3516710f9","081b0df9d30904a53097b3bec9faa880f3df76f881c2967b2e42f69121aaa6cc","85c8b4f0e31fb6e3776c4e58b7522c25c84716e4c47f7c9f4353c26bccf54d73","890040b587ff662f2e29e972fc664578ee780185813c86483afb8df66bae9bb7","2259b8f498269669f265d7abc3845902b2d2711272cb376e311e9bf1890e61dd","e6d1ce0ec90a9c13eaa930f803e74bc7ef455ed0010f6ce210d1d0166aabbf61","74849651001db90cdd20760101a72254a05711e3fd8f1c935058f99110f4cce1","ca06f3fe082e20ae4bd66bbfee976062f808d98163937f3360918eae2505029d","f7f2b5193ba54f760fbb788e13bca3e4777c03502fd1a0ebf5299ef09a6a4373","25a985659b27da2822815e45490c602a658a131bd9c80f9c8f5591a0d3348eb9","4d5b7d5d2a0b827f5971e96c488403c8002696ba8fac5b22d7e15ce87e6411cf","0cc8b8ae7b8685b01e0449e7ba110cefeda19d00f9c2dba2987803752f38f3c7"],"mods/lua/gameart/scripts/levels/gameplaymodules/progression/interact_loot_artifact.lua":["78bff1068ae286baf81e5ca74805d6670ad5407e5d2068e216cea6e132bc37e9","c6fa36e09c685688d2ba9ec1301f368b4bdf23668c92032792d22e3f007f1b78","05004752fbd53ed2255a302d2c2f07904c762a77d1e50c94be26153749a8b356","6eedecbf0a9c1cec1cba794f5c4779e891d43ef9f2115dfe5b2513ef96657461","11889c0bb55ff1911ea38d9dc66a6c9045b68d0045a72ebdb765884051ed96a1","ea839266d388a2f9ef3b070563494799e5f3f02d595e072e27acefcf8b64f5b4","3fcd46348468869189f102e88ba5a54cc74d2565e0fab8bf69339b6961d1e2dc","795de999cef02891506a5010922383ed37200013dccd1a1e5b6c3e5fafcefcd1","013141b939fd19130ac9e72b55853f12f622eb58f1b69d0def9e8b572a2db1da","53d411efc00f5a5acbf750b0b0688c9f26bfc6af57541828f37427501e88749b","a7750ced164f834c4e17728b897aa30396022568dca576540dc5be7e4b8fd47a","ddab3d0fedb6a5883628db1221f06348c1532f9db717be25870744196e9ff4fd","cba6b462f09efa2e01bc30767ad6805d9cd21c373ad6b80b061274414aa466f8","4ba3a8e7ac6ed784b7bfbd6dae2e709aa34c063222dc2fcfca751922ddfde2ff","7a67a68be9d614b6bc32b1a13298cfcac5bd13005b48550d75d1b9ce67a1edb0","a42fae6808b25816020c55dd3d459c451ac8cfd7c94742cb0b457739221e6554","b061c506069ba3b4d3f7abce27d0c484d2551c1c5b63d952c28d9edc7ed536d9","b16915d53da6a66b0c95ae6245814406d95d874634765bac0427f5dc8095a9ab","c26a869331d9f7b7efe9b642387ac28400766951eae9b28ad2a96b02e91f2887","a16b0c55ccb41374a554ab16eef07732359fcb2b4265aef70eee2e1e5ca870d6","30e69322ecdcf3ccd0a884e0d281ff3db28adb869c23e2ad3806da8f023d8bf3"],"mods/lua/gameart/scripts/levels/gameplaymodules/progression/interact_loot_dirtdig.lua":["535971f056a8ca3d3df22c1c5010079e5f59939191830c9e7e794f38bfb64536","08c795e613c12f402624ac862b157a150d05ca1295e0142fa6e3378c475ff6ce","670a85659faa0278ced0aee87036b003508b7e6ad2965b2fbbc4de221c3e3241","24b7eaeb2cf4a108656ea127a05962a948d4b628393d0955c58d58b439b02136","5fe454531ffa967e9759ebeda352c6b9913f610f69c660a20aebe678b892ca4f","c57ed60f05a1aa60967bebdf1d6a5b366d90adf6d0592864b1eb4f289cdc066b","9dc3276a0e49bc3960909597b39bf21becf8b79d1d2848b3b51296e6d658025d","8a30c28d57a2dc40cc8158f2982c6e6f4016fd6cb6fcc62db8f4ef2fb8918912","f8c3e77bfcda499076d0cc9b2255121e2aa0a09ef2f73c8f79ae6bef47535c7b","bad8008e8fdbdf38c410cc31450c5a00161912fad50c57f66306ed0a0edbba6c","647368d3b395c9175e1fe7b060e0093c655aa2c2f7486c5566c6287893d912b4","5bba7eaa92c24326cf4cf307fb0dba5c6f94c1f6ef192f007b413e1b279f064e","deb558447ad10bc683892a865749339cca4d4c1ad38df545aca32236669576c2","e885dfd0524f450ea99b568a4bf33091d657db46939365526f0684f1b313e35b","ca24c4f0f65f1ab44cca877f63b0d0f5217089e1e0042e268c2f0127b4cf5514","8c0ddf31f0f42b1aac379f7ab1984918904909936f1c7267263b4b84861c30c2","976846097d3bfd458470bd1f74f258441ef3cc88461e31c442f755cc714b4d39","2b71c847886c6d93da80e723c0ae292236a46067678692886d84fdd2e17d975c","7567ad2bf3b2997b7e3432889eb097a7114f08266f6dde22d824b708819d2fa1","935db17ef749d23c773498454e5304b702204a3cc4449a3392ca083e30a95a1d","56936cc8e6f0765980499e0b3752ca5976d73121813905c0625b5968a82fd9b0"],"mods/lua/gameart/scripts/levels/gameplaymodules/progression/interact_loot_pocketrift.lua":["dbd366a7708543f08cc2b257fae832cd92e59624ea90a4990d4c3a219fd48ea4","a00396e5b5a26063f16d9088e313d841493d6c403dc5b3c13a60a99b8d2fcf4e","8f9456ae9d841ddfb6a9ca56c1b4580ecf6cc20e8834b4cff3c01b98f6beee10","add4e84871fa597dbf0af394e3640b4a78efd2bee56af7d4c034a87bede2d37a","3c01e06301403c01d2b9aad75255519d46b00c280b577274bf9874fa4fab3146","f3cfa2a8e321ce40719b63cc9b87a69226a3d466b5c3b014ac70549e34ab904c","cf7f8cf8448b7e99a25b03658b911b91cc2e6f5ca6b450080b69d8d8f7bca06f","ee3ed81f5878394aa10fd8e7803013157ecac5d9346025ec24e1225dc1cec0c1","c616a8aee7f094ee782552c547c722a58d8549f28f0976511b13e285672e05e8","5f753390dff28537155ebb5dc084ce384b183635effa327520da26847578df97","cad2bf584ee5a15a95e396899f1f5769e7defe73a305cb4d3692e06c184d446a","3d34aa512306efeebb5fa562b07714ec3bd209b1da6f8252e21c73ef0c02ba64","7e0f8134e184f2ec6bb315eac81dc3eca0a519a5c5fee52e8c27ef865104c29a","484a50764e7f22560a19c2d9546133dc6e80642d40620c2f8d4414b29bead47d","e60740d0542f4bc080caa3bbdd93d02ff91b4b243fb37be556cace9f4226376c","083d33f84179da06d1ba0cee6dfdd4e532da7270aae7e98aabbc71aa38917fef","e124579fdd6f4b703e11c5bf5c3279c02015e82f8f56da97583d4a64daf0a941","b331f8ae75ae6f0b86004b853ac99750f611db49b43887a726ad3bd281db8eb5","b0fdb96fbae30841d81e8637a165627ca93bd1bf9824b8d9a057593a2f56ac50","49ec4385dbfd5c6754f4c661735f527eabd7c084a017c720f29f827ebc01e3d1","c8593984f001a9817a10a522dbbcd2c2e145e767a130d319744d8a9293be3c91"],"mods/lua/gameart/scripts/levels/gameplaymodules/progression/precisionchallenge.lua":["db42861f158625cc8763c1999dd1a44c60ef27b2983e3220eda3d39fc91c6a01","4c5bc2282f5e32b2373796dc632892264c035854764bdf6ab1e8b5f5dfc3973c","3b6e2894d7447af2861ab4456aa1103a213445bc43a52ccba2a950346609924c","6fc3bacac085765eaec2e75371402ee3277be44ad5ea5b3789511cc8ae7a20ff","22711cfc51704a976500fbad71186888e753bf935e65e778a47cc732efc29a27","203eac17f6ac1c2f0922bd7bef2897e13eabff9bff74224895f8799eb43a11ec","b12e98b812e5efe52c7fe6ed374e9d45e6d25151d12830dfb79418bdc9c7b702","b323595b4d9fcfb154316ed43c1c803481dfcba0d23609a417756d556acf9157","e623fe48db1e6e965fc5a5dfa8d206edb1701a40f039476e66f91cc55e9a9746","a8791807d198ab5e1648f9530fdf7c201b5c5540d7a31a78b21d50a91cf2b78a","b8a1ea346ffd77c6852bb15fd61b65926fe2308ac1583a08d459d6e4af737c39","893ae261b3c35b3929fcb297e7e71071ddd0be9cec8a49bf998bb2c90ba94993","38fd418bf5949b2a6273247033e02f1e31b51c9a0a1542f90177f6df3571971c","36a68232db0372668ec55f6f0b2e6e46a58c083bf7b4abf34134debb9a6302a5","b7039c3c558e82dd9cbd4053b2bf9baddfd34b9ad65f34d631556ad9a7378054","0fbc45ed07f9116fbb98906bf1c2468ed0b1c45d2652238c1f1a2b9a8f59ff82"],"mods/lua/gameart/scripts/levels/gameplaymodules/soninteracts/langcheckruneread.lua":["69645fe6c4200e0fd68df0e0be86d78e95be41d722303d2403fbab3c8c7cb6c8","b46eb4ef75bd670f9a82766d41c0c19aff75baa9fc3014dcd10d777e041db0bd","10afd75b8f27bcfcaf0910b3e51d1c09a1af464b8cf2f3df25013dc4c915f46e","15d717c746e6ef3fa2881b50a11e8109a57d238e310705adfb3c57c9e6ed97ee","a4b55d1f8801723e7c0d29a6d936f7ad80c6db291bbf70f8703086837bc0cfe4","a41821fcd89fb45c349bed28a4389fa30b2c522027adfbfe55303fae79851123","8c1311d490a4cf603f815deb7c88c21b449b5c2909dcf1231c9955bd22223fe5","b07e9c75b492fcf223f3fffbb26fa8ce80f979fb96fed01f14005a3a3577cd96","39264c644da48bf80d83a4d588ebdf5b72486861378471e0687e7e6214532262","bf60e369bf8aaeb52abf36a785020cc5712fe148ab2d072ec6abfd36f6b99175","b662e1d4b4ddaa0096177c5ad61a93c456fdb923c768669d951009d92451e061","19f89311f507b957656329ac61eced9c1e7e58767676bfea83a512abc6c4af55","669579f8be4eccb379f0c32e7eb73cc9424ede028074f399a44f4348d1d8df16","43d0fd087d25eb4f28a8f29c11c315d0677ac4754bcfe0d068ccf7f00baec55d","49610c943a3db4f9ba60f5b6360be574fc233bdbb75d3260c10fa0c74127ed00","2cbe1b4bee33ac990e229e2ed19450887b48868e30985f7375e3bd67d7ad5a61","becfe254bbeb631bff935c39b0e5f8cf258553c3e86cff61f3be0f042c65b9a7","732b535caab45d7ef21858cbd8ea1fc3a77a6797bba7cbe8aa64e30a0ceb3dfd","be3af957790e4f8403c8fc9a3e4fcec778c271df08723a7b4a0e2db23a3470fb","28a9dcb9877b4d0f76fa67aa99cb894e9209f8ba0341dd5713913af0521f273d","a1f05574ab6707d9973dd7fa0d623624bca2ad807400cfb38ed8731884419b54"],"mods/lua/gameart/scripts/levels/gameplaymodules/soninteracts/sonlanguagepickup.lua":["5cc2fa4d6da426a1ea8b191ef8a5689ed9ddcbbafff26f42a0748ab046e33d3c","f01d0c4f5eb66a4704b684b09fcffaee3995fe7e5c4b2ade31e4f3a781d114f3","9f8f1c842e6297dde93bb84a24a542f1441b0ea3d08936b31cd9e576c5b6e96f","fde0a93cfd1b445695461b1a9903c36167ac856a9c7352c60ec699238d993f70","d274106c02c0500f1643cf615b0ef61960788602cdac588893e09c4451556f70","d193b930db0fc0b565e2bd036fbf2144514da5d2cdadb4d0183aa3c55f699909","369162761ef089b1cc8c0209f505b727e28b924e79b8216f456e202a126beb24","b49ff37132dd2b0ab0b7378bb40a3ede65e230d9bd64d4ed5be14be7c020dd59","b9f360c48853266d5fa7ab2d83dbcaa2355d3f483f723a7df4d43cf00ce8a0e4","72b4e04c8125cfa3dffa4a5caa389b127d447f665600b6ccd0b11f820fb9212f","4bd03ea3cb22258a2865ac80dadbc2b105e59baa8faec721b650e1a16148b264","6bbd0d72d22d427967e62b700f30f968627834801e9d1b7db8a1e07018921aed","e689bad7891dd65bfeac0b84878642a85368e950784a4778172a27ef8317ecbb","062af924e7342414837b9d7d889b00e82e3c0253703c083d7d3a4474716726ad","eeccac747745446260f769c5978c34fb3a2538f8f7cd433df08467e0ff273ff9","fa1032938d7ac834027a9455ad7621febe2daafef0586c289f037635f6ff23c7","7957bdf459580d3a97398c266e0cf044af8ac67236b6660434902f6a66ca1a57","6a3131d0552dee3a63ae699f6ea86ebc9e49a4731abbdc853a6c8c13c1f70607","5feb18d0e9369f0141a872047879764902b70971eec83e75a2dd70239196af4a","d9afbfb4d7f0445a6ae5665c317cce9b68fe21704e1c7062d0651e7c7b657872"],"mods/lua/gameart/ui/scripts/inworldmenu/mapmenu.lua":["fb82f9d0e118abe7b092f19669ef5554ebb443c510e8946edbc2ecc15afe162f","4be3a89d29f71e67c001bd8e59b85da5b7d7ebffc17df155dade1f62731bc8e2","7cd9cf407cfde019c2d8a340f4dc689dae6224b4a44a6ef38eacdb75e70e7e03","ce1e66bc820fc8c4df9f538eada35f8d20c31260eade560c737397afe4c9f10a","91f8440cf58c48c53e2e89388e9fdc701711ebbd180a23e405945749eae19c57","206a3b5751b98ef32c1a3a244ba8edc3794b7c28a3962586768cc0d74f634c97","7a9378d5613aae538cc60e2411a8add669f173e0834026372d8008617a18c1ac","19d347c34845c1b4261cd235b5c16768c43c6b17bdeec37275f1cff8d1a5786e","945e85f8d53d7014fa7ec59fa99f5be5a5873503865520bdcfb5370b52f2ae25","6449f2d34b57aaf4431f70cfb7af0f2bb42ed407331eccc3f12a455a6bfd129d","dc237ced72c225291d43b3a5de3720aeba11778de5a5907747fc007fc847ebee","33cc98c873babd2294dec2c361a5cc08ab876c37d3e78b4f33e468e6a6ae9b3c","4db97f1a8e9ff3eef8acc471ff3a0583c9f3ca4f9be0e49c9a1169ebfd585628","9381b39bfaddecfaa9021bf2cbf46b467a46a71d15095d29bb781633157e5289","57b5637168b3b7fdf0a4cb295bbb86077ee13eed315248b30241bdbca1d470b8","9628e7cdbe44c557bac57cca7c03bf903ae7fb60d25d9a617276dfbca82ca2fc","bc56a891af4c8d7449457ed3d0ded1a300c5040727af7f90608337d5efb38e15","2a64670b458a2b918143f2f6e93d009e972e76130ff8a080ae208ab818ecc56b","b43dd43257d0464c06765a94dd7a1e47d4cecc01b70159613afb3750e28bc44f","bad0f60378c38f18fe0e50061cb6aa910aa47965009cd1a8ab490de3bed2343f","d4d35a29c3f54ee4bd2056fe8255e7cc300b1a5ad9a38b20176560350e7a2658","91b51ab2465237c3880c375e9e2debc448bee79693ee4ff35418872921c47070","7d799dd4f0c77376b32dadfb07671fd2b873e8df12ad41c5197fe162eb64199d","7a3e516ede9d2afca52056dc90589c6306a85524c16922eb340b8b38f9400910","3157eae266fdaead780599d1b5f796961cf9201c5ec47f504a9bcb1b446a5122","9564a8f6c9c04bad02515729b0a924039df02f1de6941e203a7b26548d4a088a","cfcab9fbbed21cb6c3439ab5eb3613718720813f00fd68e3a4f98cca080f7f8d","9db8626f5abba55bcb810cf7da00ced42320832be3120afd3af347bcc4574f93","49588f777e2c4370023a20c5f9c8b94bffb8a9cd41b8e0894514195c4d0405a5","d2102f81cf5668f45daff8992ba4c978bc0e621b34ff4eb1e9df9b2243250d80","3184ed516f53bfde2ab35d3414c766af58042c6fdfabc5a61b01ee41694bb49f","89312da4a21d22bd651fe30ead5d45abddee6b318781fa9bd965315ada349787","a4ede488b7759a2635fe98b83d87c0bd6dd3c995a4cdbbde91c801c1aafadcf3"],"mods/loader_config.toml":["63bf253df21ebe24d6fe52e2baadaa2105c73bb7cf42ca466e5b410090018584"]}
'@ | ConvertFrom-Json

# In-world icon distance from mods/completionist-map/settings.json. Windows only.
# Writes indexed float fields of the mod's own MapCoords rows; stock rows stay.
$completionistProximityPath = 'exec/dc/pc_le/mapcoords.dcb'
$completionistProximityIndexSha256 = '36e1307bdf194c87253e3a15111641bf0d622a6fb7ed76bac6d70f6f9a9357fc'
$completionistProximityFamilies = @('artefact', 'cipher_chest', 'coffin', 'jotnar_shrine', 'legendary_chest', 'lore_marker', 'lore_scroll', 'nornir_bell', 'nornir_chest', 'nornir_mechanism', 'nornir_seal', 'raven', 'realm_tear', 'treasure_dig', 'treasure_map', 'wooden_chest')
$script:completionistProximityHashes = @()

function Read-CompletionistProximityRecord([string]$Game) {
    $path = Join-Path $Game 'completionist_backup/proximity.json'
    Assert-CompletionistCompatPath $Game $path
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $null }
    try { $record = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json } catch { $record = $null }
    $known = @($completionistKnownPayloads.PSObject.Properties[$completionistProximityPath].Value)
    if ($record -isnot [PSCustomObject] -or $record.schema -ne 1 -or
        $record.sha256 -notmatch '\A[0-9a-f]{64}\z' -or $record.base_sha256 -notin $known) {
        throw 'Invalid in-world distance record. No game files changed.'
    }
    $script:completionistProximityHashes += $record.sha256
    return $record
}

function Get-CompletionistProximityDistance($Value, [string]$Where, [Collections.ArrayList]$Problems) {
    # null -> mod default (100 m); 0 -> game default (20 m, row left at 0).
    if ($null -eq $Value) { return [double]100 }
    if ($Value -isnot [int] -and $Value -isnot [long] -and $Value -isnot [double] -and $Value -isnot [decimal]) {
        [void]$Problems.Add("$Where must be a number of metres, 0 or null")
        return $null
    }
    $number = [double]$Value
    if ($number -eq 0) { return $null }
    if ([double]::IsNaN($number) -or $number -lt 5 -or $number -gt 500) {
        [void]$Problems.Add("$Where must be 0 (game default), null (100 m) or 5-500")
        return $null
    }
    return $number
}

function Get-CompletionistProximitySettings([string]$Game) {
    $path = Join-Path $Game 'mods/completionist-map/settings.json'
    Assert-CompletionistCompatPath $Game $path
    $defaults = @{}
    foreach ($family in $completionistProximityFamilies) { $defaults[$family] = [double]100 }
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $defaults }
    $problems = New-Object Collections.ArrayList
    $distances = @{}
    try {
        if ((Get-Item -LiteralPath $path).Length -gt 65536) { throw 'settings file is larger than 64 KB' }
        $text = [IO.File]::ReadAllText($path, (New-Object Text.UTF8Encoding($false, $true)))
        $settings = $text | ConvertFrom-Json
        if ($settings -isnot [PSCustomObject]) { throw 'settings file must contain a JSON object' }
        $values = @{}
        foreach ($property in $settings.PSObject.Properties) {
            if ($property.Name -cnotin @('schema', 'in_world_icon_distance_m', 'family_in_world_icon_distance_m') -and
                -not $property.Name.StartsWith('_')) {
                [void]$problems.Add("unknown setting: $($property.Name)")
            }
            $values[$property.Name] = $property.Value
        }
        if ($values['schema'] -isnot [int] -or $values['schema'] -ne 1) { [void]$problems.Add('schema must be 1') }
        $default = Get-CompletionistProximityDistance $values['in_world_icon_distance_m'] 'in_world_icon_distance_m' $problems
        $overrides = @{}
        $families = $values['family_in_world_icon_distance_m']
        if ($null -ne $families -and $families -isnot [PSCustomObject]) {
            [void]$problems.Add('family_in_world_icon_distance_m must be an object')
        } elseif ($null -ne $families) {
            foreach ($property in $families.PSObject.Properties) {
                if ($property.Name -cnotin $completionistProximityFamilies) {
                    [void]$problems.Add("unknown family: $($property.Name)")
                    continue
                }
                $overrides[$property.Name] = Get-CompletionistProximityDistance $property.Value `
                    ('family_in_world_icon_distance_m.' + $property.Name) $problems
            }
        }
        foreach ($family in $completionistProximityFamilies) {
            $value = if ($overrides.ContainsKey($family)) { $overrides[$family] } else { $default }
            if ($null -ne $value) { $distances[$family] = $value }
        }
    } catch {
        [void]$problems.Add("$($_.Exception.Message)")
    }
    if ($problems.Count -gt 0) {
        Write-Host '[!] In-world icon distance settings ignored; default 100 m used:' -ForegroundColor Yellow
        foreach ($problem in $problems) { Write-Host "    - $problem" -ForegroundColor Yellow }
        return $defaults
    }
    return $distances
}

function Get-CompletionistProximityPlan([string]$Game, [string]$PackageRoot, $Package) {
    Read-CompletionistProximityRecord $Game | Out-Null
    $distances = Get-CompletionistProximitySettings $Game
    if ($distances.Count -eq 0) {
        Write-Host '[+] In-world icon distance: game default (20 m).' -ForegroundColor Green
        return $null
    }
    $indexPath = Join-Path $PackageRoot 'scripts/proximity-rows.json'
    if (-not (Test-Path -LiteralPath $indexPath -PathType Leaf) -or
        (Get-CompletionistCompatHash $indexPath) -ne $completionistProximityIndexSha256) {
        throw 'In-world distance row index missing or changed. Extract fresh ZIP; no game files changed.'
    }
    $index = Get-Content -LiteralPath $indexPath -Raw | ConvertFrom-Json
    $baseHash = $Package.files.PSObject.Properties[$completionistProximityPath].Value.sha256
    if ($index.mapcoords_sha256 -ne $baseHash) { throw 'Row index does not match mapcoords.dcb. No game files changed.' }
    $bytes = [IO.File]::ReadAllBytes((Join-Path $PackageRoot $completionistProximityPath))
    foreach ($row in $index.rows) {
        $offset = [int]$row.offset
        if ($offset -lt 0 -or $offset + 4 -gt $bytes.Length -or
            [BitConverter]::ToUInt32($bytes, $offset) -ne 0) {
            throw 'Unexpected mapcoords.dcb row. No game files changed.'
        }
        if ($distances.ContainsKey($row.family)) {
            [Array]::Copy([BitConverter]::GetBytes([single]$distances[$row.family]), 0, $bytes, $offset, 4)
        }
    }
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $hash = ([BitConverter]::ToString($sha.ComputeHash($bytes)) -replace '-', '').ToLowerInvariant() }
    finally { $sha.Dispose() }
    $script:completionistProximityHashes += $hash
    $summary = @($distances.Keys | Sort-Object | ForEach-Object { '{0} {1:0.#} m' -f $_, $distances[$_] }) -join ', '
    Write-Host "[+] In-world icon distance: $summary" -ForegroundColor Green
    return [PSCustomObject]@{ Bytes = $bytes; Hash = $hash; BaseHash = $baseHash; Distances = $distances }
}

function Install-CompletionistProximity([string]$Game, $Plan) {
    $record = [ordered]@{ schema = 1; base_sha256 = $Plan.BaseHash; sha256 = $Plan.Hash; distances_m = $Plan.Distances }
    $recordPath = Join-Path $Game 'completionist_backup/proximity.json'
    [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($recordPath)) | Out-Null
    # Ownership record first: an interrupted write never strands an unowned file.
    Write-CompletionistText $recordPath ($record | ConvertTo-Json -Depth 4)
    $target = Join-Path $Game $completionistProximityPath
    $temporary = $target + '.completionist-' + [Guid]::NewGuid().ToString('N') + '.tmp'
    try {
        [IO.File]::WriteAllBytes($temporary, $Plan.Bytes)
        if ((Get-CompletionistCompatHash $temporary) -ne $Plan.Hash) { throw 'mapcoords.dcb write mismatch.' }
        if (Test-Path -LiteralPath $target) { [IO.File]::Replace($temporary, $target, [NullString]::Value) }
        else { [IO.File]::Move($temporary, $target) }
    } finally {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force }
    }
}

function Remove-CompletionistProximityRecord([string]$Game, $Package) {
    $path = Join-Path $Game 'completionist_backup/proximity.json'
    Assert-CompletionistCompatPath $Game $path
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return }
    $target = Join-Path $Game $completionistProximityPath
    if ($Package -and (Test-Path -LiteralPath $target -PathType Leaf)) {
        $hash = Get-CompletionistCompatHash $target
        # Keep ownership while a configured file is still installed.
        if ($hash -in @($script:completionistProximityHashes) -and
            $hash -ne $Package.files.PSObject.Properties[$completionistProximityPath].Value.sha256) { return }
    }
    Remove-Item -LiteralPath $path -Force
}

function Test-CompletionistKnownPayload([string]$Relative, [string]$Hash, $Package) {
    if ($Relative -eq $completionistProximityPath -and $Hash -in @($script:completionistProximityHashes)) { return $true }
    $entry = $Package.files.PSObject.Properties[$Relative]
    if ($entry -and $Hash -eq $entry.Value.sha256) { return $true }
    $known = $completionistKnownPayloads.PSObject.Properties[$Relative]
    return $known -and $Hash -in @($known.Value)
}

function Assert-CompletionistInstallPaths([string]$Game, $Package, [bool]$CheckConflicts = $true) {
    foreach ($relative in @($Package.files.PSObject.Properties.Name) + @('exec/boot-options.json', 'version.dll')) {
        if (-not $relative) { continue }
        $target = Join-Path $Game $relative
        Assert-CompletionistCompatPath $Game $target
        Assert-CompletionistCompatPath $Game (Join-Path $Game ('completionist_backup/' + $relative))
        if ($relative -eq 'mods/loader_config.toml') { continue }
        if ($CheckConflicts -and ($relative.StartsWith('mods/') -or $relative.StartsWith('exec/patch/')) -and
            (Test-Path -LiteralPath $target -PathType Leaf) -and
            -not (Test-CompletionistKnownPayload $relative (Get-CompletionistCompatHash $target) $Package)) {
            throw "File conflict: $relative belongs to another mod or was edited. No game files changed."
        }
    }
    Assert-CompletionistCompatPath $Game (Join-Path $Game 'completionist_backup/backup_manifest.json')
}

function Get-CompletionistLoaderConfig([string]$Game, $Package) {
    if (-not $Package.files.PSObject.Properties['mods/loader_config.toml']) { return $null }
    $path = Join-Path $Game 'mods/loader_config.toml'
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $null }
    $text = [IO.File]::ReadAllText($path, (New-Object Text.UTF8Encoding($false, $true)))
    # Complex TOML needs manual merge; never guess inside multiline values.
    if ($text.Contains('"""') -or $text.Contains("'''")) { throw 'Multiline loader config cannot be merged safely. No game files changed.' }
    if ($text -match '(?m)^[ \t]*(?:Lua|["\x27]Lua["\x27])[ \t]*(?:=|\.)' -or
        $text -match '(?m)^[ \t]*(?:\[[^\r\n]*\\|["\x27][^\r\n]*\\[^\r\n]*[=.])') {
        throw 'Complex Lua config cannot be merged safely. No game files changed.'
    }
    $newline = if ($text.Contains("`r`n")) { "`r`n" } else { "`n" }
    $tables = [regex]::Matches($text, '(?m)^[ \t]*\[([^\r\n]+)\][ \t]*(?:#[^\r\n]*)?\r?$')
    $lua = @($tables | Where-Object { $_.Groups[1].Value.Trim() -cmatch '\A(?:Lua|"Lua"|\x27Lua\x27)\z' })
    if ($lua.Count -gt 1) {
        throw 'Ambiguous Lua config table. No game files changed.'
    }
    if ($lua.Count -eq 0) { return $text.TrimEnd("`r", "`n") + $newline + $newline + '[Lua]' + $newline + 'LoadScripts = true' + $newline }
    $start = $lua[0].Index + $lua[0].Length
    $end = $text.Length
    foreach ($table in $tables) { if ($table.Index -gt $lua[0].Index) { $end = $table.Index; break } }
    $body = $text.Substring($start, $end - $start)
    $keys = [regex]::Matches($body, '(?m)^[ \t]*(?:LoadScripts|["\x27]LoadScripts["\x27])[ \t]*=')
    $setting = [regex]::Matches($body, '(?m)^([ \t]*(?:LoadScripts|["\x27]LoadScripts["\x27])[ \t]*=[ \t]*)(true|false)([ \t]*(?:#[^\r\n]*)?\r?)$')
    if ($keys.Count -gt 1 -or $keys.Count -ne $setting.Count) { throw 'Invalid LoadScripts setting. No game files changed.' }
    if ($setting.Count -eq 0) {
        if (-not $body.EndsWith("`n")) { $body += $newline }
        $body += 'LoadScripts = true' + $newline
    } elseif ($setting[0].Groups[2].Value -eq 'true') { return $null }
    else {
        $value = $setting[0].Groups[2]
        $body = $body.Remove($value.Index, $value.Length).Insert($value.Index, 'true')
    }
    return $text.Substring(0, $start) + $body + $text.Substring($end)
}

function Write-CompletionistText([string]$Path, [string]$Text) {
    $temporary = $Path + '.completionist-' + [Guid]::NewGuid().ToString('N') + '.tmp'
    try {
        [IO.File]::WriteAllText($temporary, $Text, (New-Object Text.UTF8Encoding($false)))
        if (Test-Path -LiteralPath $Path) { [IO.File]::Replace($temporary, $Path, [NullString]::Value) }
        else { [IO.File]::Move($temporary, $Path) }
    } finally {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force }
    }
}

function Assert-CompletionistRestore([string]$Game, $OriginalFiles) {
    if ($OriginalFiles -isnot [PSCustomObject]) {
        throw 'Invalid or empty backup file list; no game files changed.'
    }
    foreach ($relative in @($completionistKnownPayloads.PSObject.Properties.Name) + @('exec/boot-options.json')) {
        $source = Join-Path $Game ('completionist_backup/' + $relative)
        Assert-CompletionistCompatPath $Game $source
        if ((Test-Path -LiteralPath $source -PathType Leaf) -and -not $OriginalFiles.PSObject.Properties[$relative]) {
            throw "Backup record missing: $relative. No game files changed."
        }
    }
    foreach ($property in $OriginalFiles.PSObject.Properties) {
        $relative = $property.Name
        if ($relative -ne 'exec/boot-options.json' -and -not $completionistKnownPayloads.PSObject.Properties[$relative]) {
            throw 'Unknown backup path; no game files changed.'
        }
        $source = Join-Path $Game ('completionist_backup/' + $relative)
        Assert-CompletionistCompatPath $Game $source
        Assert-CompletionistCompatPath $Game (Join-Path $Game $relative)
        if ($property.Value -notmatch '\A[0-9a-f]{64}\z' -or
            -not (Test-Path -LiteralPath $source -PathType Leaf) -or
            (Get-CompletionistCompatHash $source) -ne $property.Value) {
            throw "Backup hash mismatch: $relative. No game files changed."
        }
    }
}

function Assert-CompletionistExistingBackup([string]$Game, $Package) {
    $path = Join-Path $Game 'completionist_backup/backup_manifest.json'
    Assert-CompletionistCompatPath $Game $path
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return }
    $original = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
    Assert-CompletionistRestore $Game $original.files
    foreach ($relative in $Package.files.PSObject.Properties.Name) {
        if (-not $relative.StartsWith('exec/')) { continue }
        $entry = $original.files.PSObject.Properties[$relative]
        $target = Join-Path $Game $relative
        if (-not $entry -or -not (Test-Path -LiteralPath $target -PathType Leaf)) { continue }
        $hash = Get-CompletionistCompatHash $target
        if ($hash -ne $entry.Value -and -not (Test-CompletionistKnownPayload $relative $hash $Package)) {
            throw "File conflict: $relative changed since install. No game files changed."
        }
    }
}

function Remove-CompletionistVerifiedBackup([string]$Game, $OriginalFiles) {
    $paths = @($OriginalFiles.PSObject.Properties.Name | ForEach-Object { Join-Path $Game ('completionist_backup/' + $_) })
    $record = Read-CompletionistReShadeRecord $Game
    if ($record) {
        $saved = Join-Path $Game ('completionist_backup/reshade-compat/' + $record.sha256 + '.dll')
        Assert-CompletionistCompatPath $Game $saved
        if ((Test-Path -LiteralPath $saved -PathType Leaf) -and (Get-CompletionistCompatHash $saved) -eq $record.sha256) {
            $paths += $saved
        }
        $paths += Join-Path $Game 'completionist_backup/reshade-compat.json'
    }
    $paths += Join-Path $Game 'completionist_backup/backup_manifest.json'
    $directories = @{}
    $root = Join-Path $Game 'completionist_backup'
    foreach ($path in $paths) {
        Assert-CompletionistCompatPath $Game $path
        if (Test-Path -LiteralPath $path -PathType Leaf) { Remove-Item -LiteralPath $path -Force }
        $parent = [IO.Path]::GetDirectoryName($path)
        while ($parent.Length -ge $root.Length) {
            $directories[$parent] = $true
            $parent = [IO.Path]::GetDirectoryName($parent)
        }
    }
    foreach ($directory in @($directories.Keys | Sort-Object Length -Descending)) {
        try { [IO.Directory]::Delete($directory, $false) } catch { }
    }
    if (Test-Path -LiteralPath $root) { Write-Host '[!] Extra recovery files kept in completionist_backup.' -ForegroundColor Yellow }
}

function Restore-CompletionistPayloads([string]$Game, $OriginalFiles, $Package) {
    $keep = $false
    foreach ($property in $OriginalFiles.PSObject.Properties) {
        $relative = $property.Name
        if ($relative -in @('exec/boot-options.json', 'mods/loader_config.toml')) { continue }
        $source = Join-Path $Game ('completionist_backup/' + $relative)
        $target = Join-Path $Game $relative
        if ($relative -eq 'dxgi.dll' -and (Test-CompletionistKeepReShade $Game $source)) { continue }
        if ((Test-Path -LiteralPath $target -PathType Leaf) -and
            -not (Test-CompletionistKnownPayload $relative (Get-CompletionistCompatHash $target) $Package)) {
            if ((Get-CompletionistCompatHash $target) -eq $property.Value) { continue }
            Write-Host "[!] Changed file kept: $relative. Original backup kept." -ForegroundColor Yellow
            $keep = $true
            continue
        }
        [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target)) | Out-Null
        Copy-CompletionistDxgi $source $target
    }
    return $keep
}

# v1.1.0 (tools/v110_install_fixes.py): the game files the mod replaces; it adds the rest.
$completionistStockPaths = @('exec/dc/pc_le/mapcoords.dcb', 'exec/dc/pc_le/mapmaster.dcb', 'exec/dc/pc_le/wad_r_perm.dcb', 'exec/dc/pc_le/wad_r_ui.dcb', 'exec/wad/pc_le/r_ui.wad')

# A game file holding one of this mod's payloads is not the game's own.
function Test-CompletionistModFile([string]$Relative, [string]$Hash, $Package) {
    if ($Relative -in @('exec/boot-options.json', 'mods/loader_config.toml')) { return $false }
    return Test-CompletionistKnownPayload $Relative $Hash $Package
}

# Replaced game files that already held the mod's payload when the backup was
# made (not_stock) and still do: no copy of the game's own exists.
function Get-CompletionistUnrestorable([string]$Game, $Backup, $Package) {
    $paths = @()
    foreach ($relative in $completionistStockPaths) {
        if (-not ($Backup.not_stock -and $Backup.not_stock.PSObject.Properties[$relative])) { continue }
        if ($Backup.files -and $Backup.files.PSObject.Properties[$relative]) { continue }
        $target = Join-Path $Game $relative
        if ((Test-Path -LiteralPath $target -PathType Leaf) -and
            (Test-CompletionistModFile $relative (Get-CompletionistCompatHash $target) $Package)) {
            $paths += $relative
        }
    }
    return $paths
}

function Write-CompletionistStockWarning([string[]]$Paths) {
    if (@($Paths).Count -eq 0) { return }
    Write-Host "[!] No backup of the game's own copy of:" -ForegroundColor Yellow
    foreach ($path in $Paths) { Write-Host "      $path" -ForegroundColor Yellow }
    Write-Host "    An earlier Completionist install replaced them without one. After uninstalling," -ForegroundColor Yellow
    Write-Host "    restore them with Steam: God of War > Properties > Installed Files >" -ForegroundColor Yellow
    Write-Host "    Verify integrity of game files." -ForegroundColor Yellow
}

# Backup copies holding this mod's own payloads are not the game's files: they
# are dropped and listed under not_stock.
function Repair-CompletionistBackup([string]$Game, $Package) {
    $path = Join-Path $Game 'completionist_backup/backup_manifest.json'
    Assert-CompletionistCompatPath $Game $path
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return }
    $record = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
    $files = [ordered]@{}
    $notStock = [ordered]@{}
    if ($record.not_stock) {
        foreach ($property in $record.not_stock.PSObject.Properties) { $notStock[$property.Name] = $property.Value }
    }
    $dropped = 0
    foreach ($property in $record.files.PSObject.Properties) {
        if (Test-CompletionistModFile $property.Name $property.Value $Package) {
            $copy = Join-Path $Game ('completionist_backup/' + $property.Name)
            Assert-CompletionistCompatPath $Game $copy
            if (Test-Path -LiteralPath $copy -PathType Leaf) { Remove-Item -LiteralPath $copy -Force }
            $notStock[$property.Name] = $property.Value
            $dropped++
        } else {
            $files[$property.Name] = $property.Value
        }
    }
    if ($dropped -eq 0) { return }
    [ordered]@{ created_at = $record.created_at; files = $files; not_stock = $notStock } |
        ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $path -Encoding UTF8
    Write-Host "[i] Dropped $dropped backup copies that were this mod's own files, not the game's." -ForegroundColor Yellow
}

# Replaced game files with no backup that now hold the game's own copy (Steam's
# Verify put them back after the mod's copies were dropped) are backed up.
function Add-CompletionistStockBackups([string]$Game, $Package) {
    $path = Join-Path $Game 'completionist_backup/backup_manifest.json'
    $record = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
    $files = [ordered]@{}
    foreach ($property in $record.files.PSObject.Properties) { $files[$property.Name] = $property.Value }
    $notStock = [ordered]@{}
    if ($record.not_stock) {
        foreach ($property in $record.not_stock.PSObject.Properties) { $notStock[$property.Name] = $property.Value }
    }
    $added = 0
    foreach ($relative in $completionistStockPaths) {
        if ($files.Contains($relative)) { continue }
        $target = Join-Path $Game $relative
        if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { continue }
        $hash = Get-CompletionistCompatHash $target
        if (Test-CompletionistModFile $relative $hash $Package) { continue }
        $copy = Join-Path $Game ('completionist_backup/' + $relative)
        Assert-CompletionistCompatPath $Game $copy
        [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($copy)) | Out-Null
        Copy-Item -LiteralPath $target -Destination $copy -Force
        $files[$relative] = $hash
        $notStock.Remove($relative)
        $added++
    }
    if ($added -eq 0) { return }
    [ordered]@{ created_at = $record.created_at; files = $files; not_stock = $notStock } |
        ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $path -Encoding UTF8
    Write-Host "[+] Backed up $added game files that had no backup of the game's own copy." -ForegroundColor Green
}

# The mod's log (mods/loader_log.txt, the Script Loader's FileLogLevel) is on
# by default, so players can send it with a problem report. It is set once:
# completionist_backup/logging.json records it, and a level the player sets
# later ("off" included) is kept on every reinstall.
function Enable-CompletionistFileLog([string]$Game) {
    $record = Join-Path $Game 'completionist_backup/logging.json'
    $path = Join-Path $Game 'mods/loader_config.toml'
    Assert-CompletionistCompatPath $Game $record
    if ((Test-Path -LiteralPath $record) -or -not (Test-Path -LiteralPath $path -PathType Leaf)) { return }
    $text = [IO.File]::ReadAllText($path, (New-Object Text.UTF8Encoding($false, $true)))
    $setting = [regex]::Matches($text, '(?m)^[ \t]*FileLogLevel[ \t]*=[ \t]*"([a-z]+)"')
    if ($setting.Count -ne 1) { return }
    $previous = $setting[0].Groups[1].Value
    if ($previous -eq 'off') {
        $value = $setting[0].Groups[1]
        Write-CompletionistText $path ($text.Remove($value.Index, $value.Length).Insert($value.Index, 'info'))
        Write-Host '[+] Mod log on: mods\loader_log.txt (FileLogLevel = "info" in mods\loader_config.toml).' -ForegroundColor Green
    }
    [ordered]@{ previous = $previous; set = ($previous -eq 'off') } | ConvertTo-Json |
        Set-Content -LiteralPath $record -Encoding UTF8
}

# Uninstall: a log level the installer turned on goes back to "off" if the
# player left it at "info".
function Restore-CompletionistFileLog([string]$Game) {
    $record = Join-Path $Game 'completionist_backup/logging.json'
    $path = Join-Path $Game 'mods/loader_config.toml'
    Assert-CompletionistCompatPath $Game $record
    if (-not (Test-Path -LiteralPath $record -PathType Leaf)) { return }
    $info = Get-Content -LiteralPath $record -Raw | ConvertFrom-Json
    if ($info.set -eq $true -and (Test-Path -LiteralPath $path -PathType Leaf)) {
        $text = [IO.File]::ReadAllText($path, (New-Object Text.UTF8Encoding($false, $true)))
        $setting = [regex]::Matches($text, '(?m)^[ \t]*FileLogLevel[ \t]*=[ \t]*"(info)"')
        if ($setting.Count -eq 1) {
            $value = $setting[0].Groups[1]
            Write-CompletionistText $path ($text.Remove($value.Index, $value.Length).Insert($value.Index, 'off'))
        }
    }
    Remove-Item -LiteralPath $record -Force
}

# Every file this mod adds goes, whichever version put it there (its hash is
# one of the mod's payloads). Files restored from the backup stay, and so do
# replaced game files with no copy of the game's own (Steam restores those).
function Remove-CompletionistModPayloads([string]$Game, $Package, $Backup) {
    $paths = @($completionistKnownPayloads.PSObject.Properties.Name) + @($Package.files.PSObject.Properties.Name)
    foreach ($relative in @($paths | Sort-Object -Unique)) {
        if ($relative -eq 'mods/loader_config.toml') { continue }
        if ($Backup.files -and $Backup.files.PSObject.Properties[$relative]) { continue }
        if ($relative -in $completionistStockPaths -and $Backup.not_stock -and
            $Backup.not_stock.PSObject.Properties[$relative]) { continue }
        $target = Join-Path $Game $relative
        Assert-CompletionistCompatPath $Game $target
        if ((Test-Path -LiteralPath $target -PathType Leaf) -and
            (Test-CompletionistKnownPayload $relative (Get-CompletionistCompatHash $target) $Package)) {
            Remove-Item -LiteralPath $target -Force
            Write-Host "  Removed mod file: $relative" -ForegroundColor Gray
        }
    }
}

function Get-CompletionistCleanBoot([string]$Game) {
    $path = Join-Path $Game 'exec/boot-options.json'
    Assert-CompletionistCompatPath $Game $path
    $boot = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
    if ($boot -isnot [PSCustomObject]) { throw 'Invalid boot-options.json; no game files changed.' }
    $entry = '../../patch/pc_le/completionist_v105_family_art'
    $packs = @($boot.'patch-texpacks')
    if ($entry -notin $packs) { return $null }
    $boot.'patch-texpacks' = @($packs | Where-Object { $_ -ne $entry })
    return $boot | ConvertTo-Json -Depth 32
}


function Find-GodOfWar {
    # 1. TargetDir parameter
    if ($TargetDir -and (Test-Path (Join-Path $TargetDir "GoW.exe"))) {
        return (Resolve-Path $TargetDir).Path
    }
    # 2. Parent directory of script / current directory (if extracted directly into game folder)
    $scriptDir = Split-Path -Parent $PSScriptRoot
    if (Test-Path (Join-Path $scriptDir "GoW.exe")) {
        return $scriptDir
    }
    $currDir = (Get-Location).Path
    if (Test-Path (Join-Path $currDir "GoW.exe")) {
        return $currDir
    }
    # 3. Steam Registry (32-bit & 64-bit)
    $regPaths = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 1593500",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Steam App 1593500"
    )
    foreach ($reg in $regPaths) {
        if (Test-Path $reg) {
            $loc = (Get-ItemProperty $reg -ErrorAction SilentlyContinue).InstallLocation
            if ($loc -and (Test-Path (Join-Path $loc "GoW.exe"))) {
                return $loc
            }
        }
    }
    # 4. Steam libraryfolders.vdf parser
    $steamReg = Get-ItemProperty "HKCU:\SOFTWARE\Valve\Steam" -ErrorAction SilentlyContinue
    if ($steamReg -and $steamReg.SteamPath) {
        $vdf = Join-Path $steamReg.SteamPath "steamapps\libraryfolders.vdf"
        if (Test-Path $vdf) {
            $content = Get-Content $vdf -Raw -ErrorAction SilentlyContinue
            $matches = [regex]::Matches($content, '"path"\s+"([^"]+)"')
            foreach ($m in $matches) {
                $libPath = $m.Groups[1].Value.Replace('\\', '\')
                $testPath = Join-Path $libPath "steamapps\common\GodOfWar"
                if (Test-Path (Join-Path $testPath "GoW.exe")) {
                    return $testPath
                }
            }
        }
    }
    # 5. Epic Games Manifests
    $epicDir = "C:\ProgramData\Epic\EpicGamesLauncher\Data\Manifests"
    if (Test-Path $epicDir) {
        Get-ChildItem $epicDir -Filter "*.item" -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                $json = Get-Content $_.FullName -Raw | ConvertFrom-Json
                if ($json.DisplayName -match "God of War" -and (Test-Path (Join-Path $json.InstallLocation "GoW.exe"))) {
                    return $json.InstallLocation
                }
            } catch {}
        }
    }
    # 6. GOG Registry
    $gogRegs = @(
        "HKLM:\SOFTWARE\GOG.com\Games\1593500",
        "HKLM:\SOFTWARE\WOW6432Node\GOG.com\Games\1593500",
        "HKLM:\SOFTWARE\GOG.com\Games\God of War",
        "HKLM:\SOFTWARE\WOW6432Node\GOG.com\Games\God of War"
    )
    foreach ($reg in $gogRegs) {
        if (Test-Path $reg) {
            $loc = (Get-ItemProperty $reg -ErrorAction SilentlyContinue).PATH
            if ($loc -and (Test-Path (Join-Path $loc "GoW.exe"))) {
                return $loc
            }
        }
    }
    # 7. Common Library Paths across drives C: through H:
    $drives = Get-PSDrive -PSProvider FileSystem | Select-Object -ExpandProperty Root
    $subpaths = @(
        "Program Files (x86)\Steam\steamapps\common\GodOfWar",
        "Program Files\Steam\steamapps\common\GodOfWar",
        "SteamLibrary\steamapps\common\GodOfWar",
        "Steam\steamapps\common\GodOfWar",
        "Games\GodOfWar",
        "Epic Games\GodOfWar",
        "GOG Games\God of War",
        "GOG Galaxy\Games\God of War",
        "Games\God of War",
        "SteamLibrary\steamapps\common\God of War",
        "Program Files (x86)\GOG Galaxy\Games\God of War"
    )
    foreach ($d in $drives) {
        foreach ($sub in $subpaths) {
            $candidate = Join-Path $d $sub
            if (Test-Path (Join-Path $candidate "GoW.exe")) {
                return $candidate
            }
        }
    }
    # 8. Interactive Folder Browser fallback
    Write-Host "God of War installation directory not detected automatically." -ForegroundColor Yellow
    Write-Host "Please select your God of War game directory in the window (where GoW.exe is located)..." -ForegroundColor Cyan
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = "Select your God of War game folder (contains GoW.exe)"
    $dialog.ShowNewFolderButton = $false
    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        if (Test-Path (Join-Path $dialog.SelectedPath "GoW.exe")) {
            return $dialog.SelectedPath
        } else {
            Write-Host "ERROR: The selected folder does not contain GoW.exe!" -ForegroundColor Red
        }
    }
    return $null
}

Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "   God of War (2018) - Completionist Map Mod Installer  " -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host ""

# Check if GoW is running
$gowProc = Get-Process "GoW" -ErrorAction SilentlyContinue
if ($gowProc) {
    Write-Host "WARNING: God of War is currently running!" -ForegroundColor Red
    Write-Host "Please close the game before proceeding with installation." -ForegroundColor Yellow
    Write-Host "Press any key to retry after closing the game..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    $gowProc = Get-Process "GoW" -ErrorAction SilentlyContinue
    if ($gowProc) {
        Write-Host "God of War is still running. Aborting installation." -ForegroundColor Red
        exit 1
    }
}

$game = Find-GodOfWar
if (-not $game) {
    Write-Host "ERROR: God of War installation folder could not be found." -ForegroundColor Red
    Write-Host "Please place the installer folder directly inside your God of War game folder and run Install.bat again." -ForegroundColor Yellow
    exit 1
}

Write-Host "[+] Detected God of War at: $game" -ForegroundColor Green

# Verify write permission to God of War folder early (auto-elevate if needed)
$writeTestOk = $false
try {
    $testPerm = Join-Path $game ".__completionist_perm_test.tmp"
    [IO.File]::WriteAllText($testPerm, "perm_check")
    Remove-Item -LiteralPath $testPerm -Force -ErrorAction SilentlyContinue
    $writeTestOk = $true
} catch {
    $writeTestOk = $false
}

if (-not $writeTestOk) {
    $isAdmin = $false
    try {
        $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch {}

    if (-not $isAdmin) {
        Write-Host ""
        Write-Host "[!] Write access denied in God of War folder." -ForegroundColor Yellow
        Write-Host "[*] Requesting Windows Administrator elevation (UAC)..." -ForegroundColor Cyan
        try {
            $psi = New-Object System.Diagnostics.ProcessStartInfo
            $psi.FileName = "powershell.exe"
            $psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -TargetDir `"$game`""
            $psi.Verb = "runas"
            $elevatedProc = [System.Diagnostics.Process]::Start($psi)
            $elevatedProc.WaitForExit()
            exit $elevatedProc.ExitCode
        } catch {
            Write-Host "ERROR: Administrator elevation was denied or failed." -ForegroundColor Red
            Write-Host "If God of War is in 'Program Files', please right-click Install.bat and select 'Run as administrator'." -ForegroundColor Yellow
            exit 1
        }
    } else {
        Write-Host "ERROR: Write access denied in God of War folder even with Administrator rights." -ForegroundColor Red
        Write-Host "Please ensure the folder is not marked Read-Only or locked by another application." -ForegroundColor Yellow
        exit 1
    }
}

$sourceRoot = Split-Path -Parent $PSScriptRoot
$manifestPath = Join-Path $sourceRoot "manifest.json"
if (-not (Test-Path $manifestPath)) {
    Write-Host "ERROR: manifest.json missing from installer package." -ForegroundColor Red
    Write-Host "Please extract the full ZIP archive before running Install.bat." -ForegroundColor Yellow
    exit 1
}
$manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json
# v1.1.0: the package must sit outside the game folder. Extracted into it, its
# files have already replaced the game's, and no backup of those can be made.
$packageFull = [IO.Path]::GetFullPath($sourceRoot).TrimEnd([char[]]'\/') + '\'
$gameFull = [IO.Path]::GetFullPath($game).TrimEnd([char[]]'\/') + '\'
if ($packageFull.StartsWith($gameFull, [StringComparison]::OrdinalIgnoreCase)) {
    Write-Host "ERROR: The mod package is inside the God of War folder. No game files changed." -ForegroundColor Red
    Write-Host "Extract the ZIP to its own folder outside the game folder (for example" -ForegroundColor Yellow
    Write-Host "Downloads\CompletionistMap-v1.1.0) and run Install.bat from there." -ForegroundColor Yellow
    Write-Host "If the ZIP was extracted straight into the game folder, its files already replaced" -ForegroundColor Yellow
    Write-Host "game files: first use Steam > God of War > Properties > Installed Files >" -ForegroundColor Yellow
    Write-Host "Verify integrity of game files." -ForegroundColor Yellow
    exit 1
}

function Get-FileSha256([string]$filePath) {
    if (Get-Command Get-FileHash -ErrorAction SilentlyContinue) {
        return (Get-FileHash -LiteralPath $filePath -Algorithm SHA256).Hash.ToLowerInvariant()
    }
    $resolved = (Resolve-Path -LiteralPath $filePath).Path
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $fs = [System.IO.File]::OpenRead($resolved)
    try {
        $hash = $sha.ComputeHash($fs)
        return ([System.BitConverter]::ToString($hash) -replace '-','').ToLowerInvariant()
    } finally {
        $fs.Close()
        $sha.Dispose()
    }
}

# Check all inputs before game files change.
$exeHash = Get-FileSha256 (Join-Path $game "GoW.exe")
$supported = $manifest.supported_exe_sha256
if ($supported -and $supported -ne "*" -and $supported -ne "any") {
    $allowedHashes = @()
    if ($supported -is [System.Collections.IEnumerable] -and $supported -isnot [string]) {
        foreach ($h in $supported) { $allowedHashes += "$h".ToLowerInvariant() }
    } elseif ("$supported" -match '^[0-9a-f]{64}$') {
        $allowedHashes += "$supported".ToLowerInvariant()
    }
    if ($allowedHashes.Count -gt 0 -and $allowedHashes -notcontains $exeHash -and -not (Test-Path (Join-Path $game "allow_unofficial.txt")) -and -not $env:GOW_ALLOW_UNOFFICIAL) {
        Write-Host "ERROR: Unsupported GoW.exe. No game files changed." -ForegroundColor Red
        Write-Host "Supported: $($allowedHashes -join ', ')"
        Write-Host "Found SHA256: $exeHash"
        exit 1
    }
}
Write-Host "[+] Found GoW.exe (SHA256: $exeHash)" -ForegroundColor Green

# Prerequisite check: GoW Script Loader (version.dll) & Configuration
$scriptLoader = Join-Path $game "version.dll"
$prereqLoader = Join-Path $sourceRoot "prerequisites\version.dll"
$gameModsDir = Join-Path $game "mods"
$gameLoaderConfig = Join-Path $gameModsDir "loader_config.toml"
$pkgLoaderConfig = Join-Path $sourceRoot "mods\loader_config.toml"
if (-not (Test-Path -LiteralPath $pkgLoaderConfig)) {
    $pkgLoaderConfig = Join-Path $sourceRoot "prerequisites\loader_config.toml"
}
$pendingInstallLoader = $false

if (Test-Path -LiteralPath $scriptLoader) {
    Write-Host "[+] Found GoW Script Loader (version.dll)" -ForegroundColor Green
} elseif (Test-Path -LiteralPath $prereqLoader) {
    Write-Host "[*] GoW Script Loader (version.dll) not detected in game folder - will be installed automatically." -ForegroundColor Cyan
    $pendingInstallLoader = $true
} else {
    Write-Host ""
    Write-Host "========================================================" -ForegroundColor Yellow
    Write-Host "  WARNING: GoW Script Loader (version.dll) NOT DETECTED! " -ForegroundColor Yellow
    Write-Host "========================================================" -ForegroundColor Yellow
    Write-Host "God of War requires 'version.dll' (GoW Script Loader) to load" -ForegroundColor Yellow
    Write-Host "custom Lua scripts from mods/lua/." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "WITHOUT version.dll:" -ForegroundColor Yellow
    Write-Host "  * Map markers will show up, but will NOT disappear when items/chests are collected!" -ForegroundColor Yellow
    Write-Host "  * Category filters and show/hide marker toggle will not function." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Please download and install GoW Script Loader from Nexus Mods:" -ForegroundColor Cyan
    Write-Host "  https://www.nexusmods.com/godofwar/mods/15" -ForegroundColor Cyan
    Write-Host "Place 'version.dll' directly into your God of War game folder." -ForegroundColor Cyan
    Write-Host "========================================================" -ForegroundColor Yellow
    Write-Host ""
}

if (-not $manifest.files -or @($manifest.files.PSObject.Properties).Count -eq 0) {
    Write-Host "ERROR: Package file list empty." -ForegroundColor Red
    exit 1
}
foreach ($file in $manifest.files.PSObject.Properties) {
    $rel = $file.Name
    if ([IO.Path]::IsPathRooted($rel) -or $rel -match '(^|[\\/])\.\.([\\/]|$)|:') {
        Write-Host "ERROR: Invalid package path: $rel" -ForegroundColor Red
        exit 1
    }
    $src = Join-Path $sourceRoot $rel
    if (-not (Test-Path -LiteralPath $src -PathType Leaf)) {
        Write-Host "ERROR: Package file missing: $rel. No game files changed." -ForegroundColor Red
        exit 1
    }
    $expected = $file.Value.sha256
    $actual = Get-FileSha256 $src
    if ($expected -notmatch '^[0-9a-f]{64}$' -or $actual -ne $expected) {
        Write-Host "ERROR: Package hash mismatch: $rel. Extract fresh ZIP; no game files changed." -ForegroundColor Red
        exit 1
    }
}
Assert-CompletionistInstallPaths $game $manifest
$preparedLoaderConfig = Get-CompletionistLoaderConfig $game $manifest
$bootPath = Join-Path $game "exec\boot-options.json"
$preparedBoot = $null
try {
    $boot = Get-Content -LiteralPath $bootPath -Raw | ConvertFrom-Json
    if ($boot -isnot [PSCustomObject]) { throw "Expected JSON object." }
    $entry = "../../patch/pc_le/completionist_v105_family_art"
    $packs = @($boot.'patch-texpacks' | Where-Object { $_ })
    if ($entry -notin $packs) {
        $boot | Add-Member -MemberType NoteProperty -Name 'patch-texpacks' -Value @($packs + $entry) -Force
        $preparedBoot = $boot | ConvertTo-Json -Depth 32
    }
} catch {
    Write-Host "ERROR: Cannot read boot-options.json: $_. No game files changed." -ForegroundColor Red
    exit 1
}

$proximityPlan = Get-CompletionistProximityPlan $game $sourceRoot $manifest
$reshadePlan = Get-CompletionistReShadePlan $game $manifest
Repair-CompletionistBackup $game $manifest
Assert-CompletionistExistingBackup $game $manifest

# Keep stock backup.
$backupDir = Join-Path $game "completionist_backup"
$backupManifest = Join-Path $backupDir "backup_manifest.json"
if (-not (Test-Path $backupDir)) {
    New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
}

$backedUp = @{}
$notStock = @{}
if (Test-Path $backupManifest) {
    Write-Host "[i] Existing stock backup found in completionist_backup. Preserving original backup." -ForegroundColor Yellow
    Add-CompletionistStockBackups $game $manifest
} else {
    Write-Host "[*] Creating safe backup of stock game files..." -ForegroundColor Cyan
    foreach ($rel in $manifest.files.PSObject.Properties.Name) {
        $target = Join-Path $game $rel
        if ((Test-Path $target) -and (Test-CompletionistModFile $rel (Get-FileSha256 $target) $manifest)) {
            $notStock[$rel] = Get-FileSha256 $target
        } elseif (Test-Path $target) {
            $dest = Join-Path $backupDir $rel
            $destParent = Split-Path -Parent $dest
            if (-not (Test-Path $destParent)) {
                New-Item -ItemType Directory -Force -Path $destParent | Out-Null
            }
            Copy-CompletionistDxgi $target $dest
            $backedUp[$rel] = Get-FileSha256 $target
        }
    }
    # Also backup boot-options.json
    $bootPath = Join-Path $game "exec\boot-options.json"
    if (Test-Path $bootPath) {
        $destBoot = Join-Path $backupDir "exec\boot-options.json"
        $destBootParent = Split-Path -Parent $destBoot
        if (-not (Test-Path $destBootParent)) { New-Item -ItemType Directory -Force -Path $destBootParent | Out-Null }
        Copy-CompletionistDxgi $bootPath $destBoot
        $backedUp["exec/boot-options.json"] = Get-FileSha256 $bootPath
    }

    $backupInfo = @{
        "created_at" = (Get-Date).ToString("o")
        "files" = $backedUp
        "not_stock" = $notStock
    }
    $backupInfo | ConvertTo-Json -Depth 5 | Set-Content -Path $backupManifest -Encoding UTF8
    Write-Host "[+] Backed up $(($backedUp.Keys).Count) stock files to completionist_backup." -ForegroundColor Green
}

Save-CompletionistReShade $game $reshadePlan

# Copy mod files
Write-Host "[*] Installing Completionist Map mod files..." -ForegroundColor Cyan
$installCount = 0
foreach ($rel in $manifest.files.PSObject.Properties.Name) {
    $src = Join-Path $sourceRoot $rel
    if (-not (Test-Path $src)) {
        Write-Host "ERROR: Package file missing: $rel" -ForegroundColor Red
        exit 1
    }
    $dest = Join-Path $game $rel
    $destParent = Split-Path -Parent $dest
    if (-not (Test-Path $destParent)) {
        New-Item -ItemType Directory -Force -Path $destParent | Out-Null
    }
    if ($rel -eq 'mods/loader_config.toml' -and (Test-Path -LiteralPath $dest)) { continue }
    if ($rel -eq $completionistProximityPath -and $proximityPlan) {
        Install-CompletionistProximity $game $proximityPlan
        $installCount++
        continue
    }
    Copy-CompletionistDxgi $src $dest
    $installCount++
}

if ($null -eq $proximityPlan) { Remove-CompletionistProximityRecord $game $manifest }
# v1.1.0: what was installed, for Uninstall.bat from any package.
Copy-Item -LiteralPath $manifestPath -Destination (Join-Path $backupDir 'installed_manifest.json') -Force

# Install bundled prerequisite if needed
if ($pendingInstallLoader -and (Test-Path -LiteralPath $prereqLoader)) {
    Copy-Item -LiteralPath $prereqLoader -Destination $scriptLoader -Force
    Write-Host "[+] Installed bundled GoW Script Loader (version.dll) to game folder." -ForegroundColor Green
}

Enable-CompletionistReShade $game $reshadePlan
if ($null -ne $preparedLoaderConfig) {
    Write-CompletionistText $gameLoaderConfig $preparedLoaderConfig
}

# Ensure GoW Script Loader configuration is present in mods directory
if (-not (Test-Path -LiteralPath $gameLoaderConfig) -and (Test-Path -LiteralPath $pkgLoaderConfig)) {
    if (-not (Test-Path -LiteralPath $gameModsDir)) {
        New-Item -ItemType Directory -Force -Path $gameModsDir | Out-Null
    }
    Copy-Item -LiteralPath $pkgLoaderConfig -Destination $gameLoaderConfig -Force
    Write-Host "[+] Installed GoW Script Loader configuration (mods\loader_config.toml)." -ForegroundColor Green
} elseif (Test-Path -LiteralPath $gameLoaderConfig) {
    Write-Host "[+] Verified GoW Script Loader configuration (mods\loader_config.toml)." -ForegroundColor Green
}
Enable-CompletionistFileLog $game

# Add art pack with no UTF-8 BOM.
if ($null -ne $preparedBoot) {
    Write-CompletionistText $bootPath $preparedBoot
    Write-Host "[+] Artwork patch texpack registered in boot-options.json" -ForegroundColor Green
}
$installedBackup = Get-Content -LiteralPath $backupManifest -Raw | ConvertFrom-Json
Write-CompletionistStockWarning (Get-CompletionistUnrestorable $game $installedBackup $manifest)

Write-Host ""
Write-Host "========================================================" -ForegroundColor Green
Write-Host "           INSTALLATION COMPLETED SUCCESSFULLY!         " -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Green
Write-Host " Features active:" -ForegroundColor Cyan
Write-Host "  * 551 collectible marker records across 16 custom marker families"
Write-Host "  * GoW Script Loader (version.dll + loader_config.toml) verified & active" -ForegroundColor Green
Write-Host "  * Odin's Ravens with native authority & tracking"
Write-Host "  * Chest state persistence across restarts (wooden chests, etc.)"
Write-Host "  * Custom map markers & compass HUD icons with distance meters"
Write-Host "  * In-map [Down Arrow] toggle button (Hide / Show Markers)"
Write-Host "  * In-world icon distance: mods\completionist-map\settings.json (see settings.example.json)"
Write-Host "  * Original stock files backed up to: completionist_backup"
if (Test-Path -LiteralPath $scriptLoader) {
    Write-Host "  * GoW Script Loader (version.dll) verified / active" -ForegroundColor Green
}
Write-Host ""
Write-Host "You can now launch God of War!" -ForegroundColor Cyan
exit 0
